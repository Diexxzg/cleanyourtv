package com.gathin.tvhome;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import java.util.List;

/**
 * Follows whichever app is playing media (Spotify, YouTube Music...) and reports its title and state to the
 * header's "Now playing" pill. Needs notification access for {@link MediaListenerService}; without it
 * Android throws a SecurityException, which is treated as "nothing playing" so the pill stays hidden.
 */
final class NowPlaying {
    private static final String TAG = "TvHome.NowPlaying";

    interface Callback {
        /** Something is playing or paused. {@code line} is "Title - Artist". */
        void onNowPlaying(CharSequence line, boolean playing);

        /** Nothing to show (no session, or no notification access). */
        void onNothing();
    }

    private final Context ctx;
    private final Callback callback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ComponentName listener;
    private MediaSessionManager manager;
    private MediaController controller;
    private boolean started;

    private final MediaController.Callback controllerCallback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            publish();
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            publish();
        }

        @Override
        public void onSessionDestroyed() {
            refresh();
        }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsChanged = this::pick;

    NowPlaying(Context context, Callback callback) {
        this.ctx = context.getApplicationContext();
        this.callback = callback;
        this.listener = new ComponentName(ctx, MediaListenerService.class);
    }

    void start() {
        if (started) {
            refresh();
            return;
        }
        manager = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
        if (manager == null) {
            callback.onNothing();
            return;
        }
        try {
            manager.addOnActiveSessionsChangedListener(sessionsChanged, listener, handler);
            started = true;
            pick(manager.getActiveSessions(listener));
        } catch (SecurityException e) {
            // No notification access yet: the pill simply stays hidden.
            Log.i(TAG, "No notification access for the media pill");
            started = false;
            callback.onNothing();
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not follow media sessions", e);
            started = false;
            callback.onNothing();
        }
    }

    void stop() {
        if (controller != null) {
            controller.unregisterCallback(controllerCallback);
            controller = null;
        }
        if (started && manager != null) {
            try {
                manager.removeOnActiveSessionsChangedListener(sessionsChanged);
            } catch (RuntimeException ignored) {
                // Already gone with the service.
            }
        }
        started = false;
    }

    void previous() {
        if (controller != null) controller.getTransportControls().skipToPrevious();
    }

    void next() {
        if (controller != null) controller.getTransportControls().skipToNext();
    }

    void togglePlay() {
        if (controller == null) return;
        PlaybackState state = controller.getPlaybackState();
        if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
            controller.getTransportControls().pause();
        } else {
            controller.getTransportControls().play();
        }
    }

    private void refresh() {
        if (manager == null) return;
        try {
            pick(manager.getActiveSessions(listener));
        } catch (RuntimeException e) {
            callback.onNothing();
        }
    }

    /** Prefers a session that is playing now; otherwise the first one that has a title (paused). */
    private void pick(List<MediaController> sessions) {
        MediaController best = null;
        if (sessions != null) {
            for (MediaController c : sessions) {
                PlaybackState state = c.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
                    best = c;
                    break;
                }
                if (best == null && c.getMetadata() != null) best = c;
            }
        }
        if (best != null && controller != null && best.getSessionToken().equals(controller.getSessionToken())) {
            publish();
            return;
        }
        if (controller != null) controller.unregisterCallback(controllerCallback);
        controller = best;
        if (controller != null) controller.registerCallback(controllerCallback, handler);
        publish();
    }

    private void publish() {
        if (controller == null) {
            callback.onNothing();
            return;
        }
        MediaMetadata metadata = controller.getMetadata();
        CharSequence title = metadata == null ? null : metadata.getText(MediaMetadata.METADATA_KEY_TITLE);
        CharSequence artist = metadata == null ? null : metadata.getText(MediaMetadata.METADATA_KEY_ARTIST);
        if (TextUtils.isEmpty(title)) {
            callback.onNothing();
            return;
        }
        CharSequence line = TextUtils.isEmpty(artist) ? title : title + " - " + artist;
        PlaybackState state = controller.getPlaybackState();
        boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
        callback.onNowPlaying(line, playing);
    }
}
