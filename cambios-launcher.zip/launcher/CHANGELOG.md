## 3.28
- Dock en estilo iOS: placa gris oscuro neutra, sin degradado ni borde.

## 3.27
- Panel rediseñado apaisado estilo iOS: música, barras de brillo y volumen (arriba/abajo), conexiones en círculos, lista de accesos a la derecha, Biblioteca y Apagar abajo.

## 3.26
- Píldoras de la barra superior y de música al estilo iOS: gris oscuro neutro, sin tinte ni borde; botón play gris/blanco.

## 3.25
- Panel de control con estilo iOS: fondo negro translúcido, tarjetas gris oscuro muy redondeadas, iconos en círculo gris (negro al enfocar), sin colores ni bordes.
- Tarjeta de música oscura sin tinte.
