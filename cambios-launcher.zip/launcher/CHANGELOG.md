## 3.48
- Panel: el mismo boton que lo abre ahora lo cierra (antes abria otro encima); Home tambien lo quita, sobre las apps y en el Home.
- Modo musica estilo Apple Music: pie de caratula pequeno (titulo y artista) y letras grandes; manteniendo Abajo se pasa a la fila de portadas (ya sonadas | actual | cola de la app) con barra de progreso ancha. Atras o mantener Arriba/Abajo vuelve a las letras.
- La cola solo aparece si la app la publica (Spotify casi nunca); las anteriores salen de lo sonado en esta sesion.

## 3.47
- Nueva tarjeta "Proteccion" en el panel: un OK enciende o apaga el DNS privado (AdGuard por defecto) para cortar anuncios y rastreo en toda la TV.
- Proveedor elegible en Ajustes del lanzador (AdGuard / Mullvad); si cambias de proveedor con la proteccion activa, se aplica al instante.
- Necesita WRITE_SECURE_SETTINGS; sin el permiso muestra el comando adb. No quita los anuncios propios de YouTube.
- Limpieza visual: Proteccion comparte fila con Biblioteca (el panel no crece); losetas y circulos del panel mas opacos sobre la imagen; sliders con pista y borde visibles; el texto de la pildora de musica se desvanece en los bordes en vez de cortarse.

## 3.46
- Tarjetas recientes: al abrir una app vuelve a la pantalla exacta donde estabas (se recuerda la actividad en primer plano y se trae al frente), en vez de abrirla desde cero; si no se puede, abre la app como antes.
- El boton de apps recientes en 3D tambien funciona estando en Home (antes solo con una app abierta).
- Apps recientes en 3D con su propio boton, elegible en Ajustes del lanzador (Menu, Info, Rojo, Verde, Amarillo, Azul; sustituye al ajuste de ventanas flotantes). Se abren aunque el sistema no responda a la captura (espera maximo 0,8 s) y avisan si el sistema rechaza la ventana.
- Hora sobre las apps: solo la hora (sin fecha) con la tipografia del Home (layout overlay_clock, mismos atributos); ya no se corta.
- Pulsacion larga de la tecla del panel con temporizador (550 ms), porque muchos mandos no mandan eventos de repeticion. Las tarjetas recientes se cargan tambien desde las capturas guardadas.
- Panel sobre las apps: la ventana de la actividad se reduce a un pixel transparente (antes la pantalla se ponia negra).
- Accesibilidad que sobrevive a las actualizaciones: nuevo receptor (UpdateRevival) que reactiva los ayudantes al actualizar y al arrancar la TV; al desvincularse, el registro solo se borra si el usuario lo apago (si sigue en la lista, fue la actualizacion). Sigue necesitando WRITE_SECURE_SETTINGS.
- El panel sobre las apps ahora es el mismo panel del Home (PanelOverActivity, transparente): igual aspecto, botones y animaciones. Se quitan el panel propio, la pantalla dividida y la ventana flotante de ese panel.
- La hora sobre las apps es la del Home: hora ligera, AM/PM pequeno, separador y fecha, sin capsula (posicion en CLOCK_X_DP/CLOCK_Y_DP de OverlayHost).
- Apps recientes en 3D: pulsacion larga de la tecla del panel. Tarjetas de cristal con la ultima imagen de cada app (captura cada 30 s y al abrir), Izq/Der mover, OK abrir, Arriba quitar, Atras cerrar. Necesita android:canTakeScreenshot="true" en res/xml/home_key_service.xml; sin eso muestra el banner de la app.

## 3.45
- Sobre las apps (por el servicio de accesibilidad, todo apagado por defecto): panel de control de cristal con un boton elegible (musica, noche, reloj, pantalla dividida, volumen, brillo), isla de la cancion, reloj (apagado / al pulsar una tecla / siempre) y velo de noche en todas las apps.
- Ventanas flotantes experimentales: ajuste que activa el soporte del sistema y opcion "Abrir en ventana flotante" en el menu de los tiles.

## 3.44
- Modo zen (Ajustes del lanzador: apagado / 15 / 30 / 60 s): sin tocar nada, la interfaz se desvanece y queda solo el fondo; cualquier tecla la devuelve.

## 3.43
- Ajustes del lanzador: "La pildora de musica se expande como una isla" (apagado por defecto) y "Barras de visualizador en la pantalla de musica" (encendido por defecto).
- Pantalla de musica: espectro en barras con el color de la portada (audio real con permiso de microfono, simulado sin el).

## 3.42
- Ajustes del lanzador, cuatro efectos nuevos (todos apagados por defecto): fondo y tarjeta de musica que laten con la musica (audio real con permiso de microfono; sin el, ritmo simulado), halo animado (el fondo respira), aurora con los colores de la portada, y tarjetas 3D al enfocar.

## 3.41
- Panel: circulo de modo noche (un toque: encendido/apagado) junto a Wi-Fi y Bluetooth, y acceso a los ajustes del launcher; el panel es 60 dp mas ancho para el 3.er circulo de cada fila.
- Pildora de musica de la barra superior: el mismo destello al cambiar de cancion (misma opcion que la tarjeta del panel; funciona con el panel cerrado).
- Biblioteca: relieve de cristal en el panel y en las tarjetas de apps.

## 3.40
- Barra superior: las pildoras de musica y Wi-Fi llevan el mismo borde de cristal con relieve que la tarjeta de musica.
- Ajustes del lanzador: "Atenuar tiles blancos del dock" (0/30/50/70 %).
- Panel y biblioteca: tambien se cierran con una animacion corta (se omite con movimiento reducido).

## 3.39
- Modo noche (Ajustes del lanzador: apagado / auto 21-7 h / siempre): velo suave sobre Home, atenua mas los tiles claros y suaviza los blancos del panel y su fondo.
- Tarjeta de musica, dos opciones nuevas (apagadas por defecto): borde con el color de la portada y destello al cambiar de cancion.
- Foco de los tiles: aro y halo mas suaves.

## 3.38
- Dock y tiles: el arte casi blanco (Netflix, YouTube...) se atenua hasta un 30 % para que no deslumbre.
- Biblioteca: el resalte del tile enfocado es mas suave.
- Dock: borde de cristal con relieve, como la tarjeta de musica.
- Ajustes del lanzador: nuevo "Brillo del fondo del panel" (80/100/130/160 %).

## 3.37
- Panel: blanco suave (90 %) en el slider, los circulos y los iconos activos; deslumbra menos.
- Dialogos y aviso de tarjetas con desenfoque del fondo (Android 12+).
- QR del Wi-Fi mas pequeno, con esquinas redondeadas y blanco atenuado.

## 3.36
- Mismo estilo en todo: dialogos (QR, Bluetooth, elegir fondo...) con cristal oscuro, borde claro y foco con aro blanco; ajustes del launcher y biblioteca con el mismo cristal, activo en blanco.

## 3.35
- Panel: la imagen de fondo emite menos luz (brillo x1,3, velo algo mas oscuro).
- restore_key_services activado por defecto: Home vuelve a encender la accesibilidad tras actualizar (necesita pm grant WRITE_SECURE_SETTINGS una vez).

## 3.34
- Panel: relieve de cristal más marcado en la tarjeta de música (borde luminoso más ancho, centro negro).
- Panel: la imagen de fondo se aclara y los velos/tarjetas son más translúcidos para que se perciba.

## 3.33
- Tarjeta de musica con relieve de cristal (borde luminoso que se difumina hacia dentro).
- Con imagen de fondo en el panel, las tarjetas pasan a cristal translucido y la imagen se ve mucho mas.

## 3.32
- Fondo del panel: la imagen se elige desde los archivos de la TV (independiente del fondo de pantalla), con opcion de volver al cristal.

## 3.31
- Panel mas oscuro y compacto, por debajo de la barra superior.
- Opcion en ajustes: fondo del panel (cristal o una de tus imagenes de fondo).
- El modo musica se abre con su propio boton en la tarjeta de musica; el foco inicial queda en play/pausa.

## 3.30
- Panel estilo Centro de control de iOS, pequeno y a la derecha, con aperturas y foco animados; activo en blanco.
- Salvapantallas eliminado: el modo Ambiente (solo hora y fecha, mismo brillo) ocupa su lugar, tambien tras inactividad y con Atras.
- Wi-Fi en blanco, con el nombre de la red (pide permiso de ubicacion una vez); boton de pausa sin fondo gris; iconos nuevos para el boton del panel y para Biblioteca.

## 3.29
- Cristal translucido (panel, barra superior, dock) con desenfoque y borde de luz; azul iOS solo en lo activo; icono Wi-Fi estilo iOS; resalte de foco unico en el panel; icono de biblioteca nuevo; panel mas pequeno y centrado; salvapantallas de fotos sin zoom (opcion saver_zoom en ajustes).

## 3.28
- Dock en estilo iOS: placa gris oscuro neutra, sin degradado ni borde.

## 3.27
- Panel rediseñado apaisado estilo iOS: música, barras de brillo y volumen (arriba/abajo), conexiones en círculos, lista de accesos a la derecha, Biblioteca y Apagar abajo.

## 3.26
- Píldoras de la barra superior y de música al estilo iOS: gris oscuro neutro, sin tinte ni borde; botón play gris/blanco.

## 3.25
- Panel de control con estilo iOS: fondo negro translúcido, tarjetas gris oscuro muy redondeadas, iconos en círculo gris (negro al enfocar), sin colores ni bordes.
- Tarjeta de música oscura sin tinte.
