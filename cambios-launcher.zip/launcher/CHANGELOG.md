## 3.26
- Píldoras de la barra superior y de música al estilo iOS: gris oscuro neutro, sin tinte ni borde; botón play gris/blanco.

## 3.25
- Panel de control con estilo iOS: fondo negro translúcido, tarjetas gris oscuro muy redondeadas, iconos en círculo gris (negro al enfocar), sin colores ni bordes.
- Tarjeta de música oscura sin tinte.
