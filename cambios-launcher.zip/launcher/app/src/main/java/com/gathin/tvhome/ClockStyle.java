package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.widget.TextView;

/**
 * Custom: the iOS-style clock editor (Novedades > Reloj). Font, size, colour and fill (solid, liquid glass,
 * gradient, neon) for the time on Home, in Ambient mode and over other apps. Off by default; while it is off
 * nothing about the layout's own clock changes.
 */
final class ClockStyle {
    static final String ON = "clock_style_on", FONT = "clock_style_font", SCALE = "clock_style_scale",
            FILL = "clock_style_fill", COLOR = "clock_style_color";

    static final String[] FONTS = {"Original", "Outfit extrafina", "Outfit regular", "Outfit media",
            "Sistema fina", "Sistema gruesa", "Condensada", "Serif", "Monoespaciada", "Casual"};
    static final String[] FILLS = {"Solido", "Cristal liquido", "Degradado", "Neon"};
    static final String[] COLOR_NAMES = {"Blanco", "Azul iOS", "Calido", "Menta", "Rosa", "Violeta", "Dorado"};
    static final int[] COLORS = {0xFFFFFFFF, 0xFF0A84FF, 0xFFFFD6A5, 0xFF63E6BE, 0xFFFF8FAB, 0xFFB197FC, 0xFFFFC857};
    static final int[] SCALES = {70, 85, 100, 115, 130, 150, 180};

    private ClockStyle() { }

    static Typeface typeface(Context c, int font) {
        try {
            switch (font) {
                case 1: return c.getResources().getFont(R.font.outfit_extralight);
                case 2: return c.getResources().getFont(R.font.outfit_regular);
                case 3: return c.getResources().getFont(R.font.outfit_medium);
                case 4: return Typeface.create("sans-serif-thin", Typeface.NORMAL);
                case 5: return Typeface.create("sans-serif-black", Typeface.NORMAL);
                case 6: return Typeface.create("sans-serif-condensed", Typeface.NORMAL);
                case 7: return Typeface.create("serif", Typeface.NORMAL);
                case 8: return Typeface.create("monospace", Typeface.NORMAL);
                case 9: return Typeface.create("casual", Typeface.NORMAL);
                default: return null;
            }
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private static int clamp(int v, int max) {
        return Math.max(0, Math.min(max, v));
    }

    /** Applies the saved style to the time (and, lighter, to the AM/PM and the date). Any view may be null. */
    static void apply(Context ctx, TextView time, TextView ampm, TextView date) {
        SharedPreferences p = ctx.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        if (!p.getBoolean(ON, false) || time == null) return;
        int font = clamp(p.getInt(FONT, 0), FONTS.length - 1);
        int scale = p.getInt(SCALE, 100);
        int fill = clamp(p.getInt(FILL, 0), FILLS.length - 1);
        int tint = COLORS[clamp(p.getInt(COLOR, 0), COLORS.length - 1)];
        float density = ctx.getResources().getDisplayMetrics().density;
        Typeface tf = typeface(ctx, font);

        Object tag = time.getTag(R.id.clock_style_base);
        float base = tag instanceof Float ? (Float) tag : time.getTextSize();
        time.setTag(R.id.clock_style_base, base);
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * scale / 100f);
        if (tf != null) time.setTypeface(tf);
        time.setTextColor(tint);

        Paint paint = time.getPaint();
        paint.setShader(null);
        time.setShadowLayer(0f, 0f, 0f, 0);
        float h = time.getTextSize() * 1.2f;
        if (fill == 1) {
            // Liquid glass: bright at the top, see-through at the bottom, with a soft shadow under the letters.
            paint.setShader(new LinearGradient(0f, 0f, 0f, h,
                    new int[] {withAlpha(tint, 0xFF), withAlpha(tint, 0xC8), withAlpha(tint, 0x66)},
                    new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            time.setShadowLayer(10f * density, 0f, 3f * density, 0x55000000);
        } else if (fill == 2) {
            float[] hsv = new float[3];
            Color.colorToHSV(tint, hsv);
            hsv[0] = (hsv[0] + 55f) % 360f;
            hsv[1] = Math.max(hsv[1], 0.45f);
            int other = Color.HSVToColor(0xFF, hsv);
            paint.setShader(new LinearGradient(0f, 0f, time.getTextSize() * 2.6f, h * 0.4f,
                    tint, other, Shader.TileMode.CLAMP));
        } else if (fill == 3) {
            time.setShadowLayer(16f * density, 0f, 0f, withAlpha(tint, 0xDD));
        }
        time.invalidate();

        if (ampm != null) {
            Object t2 = ampm.getTag(R.id.clock_style_base);
            float b2 = t2 instanceof Float ? (Float) t2 : ampm.getTextSize();
            ampm.setTag(R.id.clock_style_base, b2);
            ampm.setTextSize(TypedValue.COMPLEX_UNIT_PX, b2 * Math.max(scale, 85) / 100f);
            ampm.setTextColor(withAlpha(tint, 0xB3));
            if (tf != null) ampm.setTypeface(tf);
        }
        if (date != null) {
            date.setTextColor(withAlpha(tint, 0xA6));
            if (tf != null) date.setTypeface(tf);
        }
    }
}
