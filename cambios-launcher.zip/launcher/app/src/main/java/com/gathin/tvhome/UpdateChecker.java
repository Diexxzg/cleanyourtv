package com.gathin.tvhome;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Custom: updates straight from GitHub (Novedades > Actualizaciones). The workflow publishes the build as the
 * release tagged "latest"; this compares that release's date with the moment the installed launcher was last
 * installed, downloads the APK and hands it to the system installer. Checking is automatic about twice a day;
 * installing is always started by the person from Novedades.
 */
final class UpdateChecker {
    static final String REPO = "Diexxzg/cleanyourtv";
    static final String AUTO = "update_auto";
    static final String LAST_CHECK = "update_last_check";
    static final String NOTIFIED = "update_notified";
    private static final long EVERY_MS = 12L * 60L * 60L * 1000L;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private UpdateChecker() { }

    static final class Info {
        final boolean newer;
        final String url;
        final long size;
        final String published;

        Info(boolean newer, String url, long size, String published) {
            this.newer = newer;
            this.url = url;
            this.size = size;
            this.published = published;
        }
    }

    interface Listener {
        /** On the main thread: info is null when err says what went wrong. */
        void onResult(Info info, String err);
    }

    interface Progress {
        void onProgress(int percent);
    }

    /** Looks for an update in the background; once per 12 hours, from Home, when the person allows it. */
    static void autoCheck(final Context ctx) {
        final SharedPreferences p = ctx.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        if (!p.getBoolean(AUTO, true)) return;
        long now = System.currentTimeMillis();
        if (now - p.getLong(LAST_CHECK, 0L) < EVERY_MS) return;
        p.edit().putLong(LAST_CHECK, now).apply();
        check(ctx, new Listener() {
            @Override public void onResult(Info info, String err) {
                if (info == null || !info.newer) return;
                if (info.published.equals(p.getString(NOTIFIED, ""))) return;
                p.edit().putString(NOTIFIED, info.published).apply();
                Island.message(ctx, Island.INFO, "Actualizacion disponible",
                        "Ajustes del launcher > Novedades > Actualizaciones", 9000);
            }
        });
    }

    static void check(final Context ctx, final Listener listener) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                Info info = null;
                String err = null;
                HttpURLConnection c = null;
                try {
                    URL u = new URL("https://api.github.com/repos/" + REPO + "/releases/tags/latest");
                    c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    c.setRequestProperty("User-Agent", "tvhome-updater");
                    int code = c.getResponseCode();
                    if (code != 200) throw new java.io.IOException("GitHub respondio " + code);
                    JSONObject o = new JSONObject(readAll(c.getInputStream()));
                    JSONArray assets = o.getJSONArray("assets");
                    String url = null;
                    long size = 0L;
                    String when = o.optString("published_at", "");
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.optString("name", "").endsWith(".apk")) {
                            url = a.getString("browser_download_url");
                            size = a.optLong("size", 0L);
                            String up = a.optString("updated_at", "");
                            if (!up.isEmpty()) when = up;
                            break;
                        }
                    }
                    if (url == null) throw new java.io.IOException("La publicacion no trae APK");
                    long released = parse(when);
                    long installed = app.getPackageManager().getPackageInfo(app.getPackageName(), 0).lastUpdateTime;
                    info = new Info(released > installed + 20000L, url, size, when);
                } catch (Exception e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                } finally {
                    if (c != null) c.disconnect();
                }
                final Info fi = info;
                final String fe = err;
                MAIN.post(new Runnable() {
                    @Override public void run() {
                        listener.onResult(fi, fe);
                    }
                });
            }
        }, "tvhome-update-check").start();
    }

    /** Downloads the APK (progress 0..100, or -1 if the size is unknown) and starts the system install. */
    static void install(final Context ctx, final Info info, final Progress progress, final Listener done) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                String err = null;
                HttpURLConnection c = null;
                try {
                    File apk = new File(app.getCacheDir(), "update.apk");
                    c = (HttpURLConnection) new URL(info.url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setRequestProperty("User-Agent", "tvhome-updater");
                    int code = c.getResponseCode();
                    if (code != 200) throw new java.io.IOException("La descarga respondio " + code);
                    long total = c.getContentLengthLong() > 0 ? c.getContentLengthLong() : info.size;
                    InputStream in = c.getInputStream();
                    OutputStream out = new FileOutputStream(apk);
                    try {
                        byte[] buf = new byte[64 * 1024];
                        long got = 0L;
                        int last = -2;
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            got += n;
                            final int pct = total > 0 ? (int) Math.min(100L, got * 100L / total) : -1;
                            if (pct != last) {
                                last = pct;
                                MAIN.post(new Runnable() {
                                    @Override public void run() {
                                        progress.onProgress(pct);
                                    }
                                });
                            }
                        }
                    } finally {
                        out.close();
                        in.close();
                    }
                    if (apk.length() < 100000L) throw new java.io.IOException("El archivo descargado es muy pequeno");
                    commit(app, apk);
                } catch (Exception e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                } finally {
                    if (c != null) c.disconnect();
                }
                final String fe = err;
                MAIN.post(new Runnable() {
                    @Override public void run() {
                        done.onResult(null, fe);
                    }
                });
            }
        }, "tvhome-update-install").start();
    }

    private static void commit(Context app, File apk) throws java.io.IOException {
        PackageInstaller installer = app.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params =
                new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(app.getPackageName());
        params.setSize(apk.length());
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        }
        int id = installer.createSession(params);
        PackageInstaller.Session session = installer.openSession(id);
        try {
            InputStream in = new FileInputStream(apk);
            OutputStream out = session.openWrite("update.apk", 0L, apk.length());
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            } finally {
                out.close();
                in.close();
            }
            Intent result = new Intent(app, UpdateResultReceiver.class).setAction(UpdateResultReceiver.ACTION);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pending = PendingIntent.getBroadcast(app, id, result, flags);
            session.commit(pending.getIntentSender());
        } finally {
            session.close();
        }
    }

    private static String readAll(InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        try {
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        } finally {
            in.close();
        }
        return b.toString("UTF-8");
    }

    private static long parse(String iso) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(iso).getTime();
        } catch (Exception e) {
            return 0L;
        }
    }
}
