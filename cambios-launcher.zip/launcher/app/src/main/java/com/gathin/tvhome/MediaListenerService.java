package com.gathin.tvhome;

import android.service.notification.NotificationListenerService;

/**
 * Does nothing itself. Android only lets an app read the active media sessions (what is playing, and the
 * previous / pause / next controls) once it holds notification access, and that access is granted to a
 * NotificationListenerService component, so the launcher declares this empty one for {@link NowPlaying}.
 */
public final class MediaListenerService extends NotificationListenerService {
}
