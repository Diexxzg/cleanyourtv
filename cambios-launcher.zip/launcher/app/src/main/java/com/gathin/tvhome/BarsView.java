package com.gathin.tvhome;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.function.IntSupplier;

/** Spectrum bars along the bottom of the music screen, in the cover's colour; animates only while attached. */
final class BarsView extends View {
    private final BeatSource source;
    private final IntSupplier color;
    private final float[] bands = new float[BeatSource.BANDS];
    private final float[] shown = new float[BeatSource.BANDS];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private ValueAnimator loop;
    private long lastFrame;
    private int shadedColor;

    BarsView(Context context, BeatSource source, IntSupplier color) {
        super(context);
        this.source = source;
        this.color = color;
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setAlpha(0.8f);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(1000);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setInterpolator(new LinearInterpolator());
        loop.addUpdateListener(a -> {
            long now = android.os.SystemClock.uptimeMillis();
            if (now - lastFrame < 33) return;
            lastFrame = now;
            source.bands(bands);
            for (int i = 0; i < shown.length; i++) shown[i] = Math.max(bands[i], shown[i] * 0.86f);
            invalidate();
        });
        loop.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (loop != null) loop.cancel();
        loop = null;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        int base = color.getAsInt();
        if (base != shadedColor) {
            shadedColor = base;
            paint.setShader(new LinearGradient(0, h, 0, 0, (base & 0x00FFFFFF) | 0xCC000000, base & 0x00FFFFFF, Shader.TileMode.CLAMP));
        }
        int n = shown.length;
        float slot = w / (float) n, bar = slot * 0.58f, radius = bar / 2f;
        for (int i = 0; i < n; i++) {
            float bh = Math.max(bar, shown[i] * h);
            float left = i * slot + (slot - bar) / 2f;
            rect.set(left, h - bh, left + bar, h);
            c.drawRoundRect(rect, radius, radius, paint);
        }
    }
}
