package com.gathin.tvhome;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Custom: the voice assistant (Novedades > Voz). One press of the chosen key listens (on the TV itself when the
 * system has an on-device recogniser, so no Internet is needed), shows the island and the light round the screen,
 * runs the command and answers on the island. A second press cancels.
 */
final class VoiceController {
    static final String KEY = "voice_key";
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static SpeechRecognizer recognizer;
    private static HomeKeyService host;
    private static boolean active;
    private static int mode;
    private static final Runnable TIMEOUT = new Runnable() {
        @Override public void run() {
            if (!active) return;
            teardown();
            Island.done(host, false, "No te escuche", "Pulsa el boton y habla");
        }
    };

    private VoiceController() { }

    static void toggle(HomeKeyService svc) {
        if (active) {
            teardown();
            Island.hide();
        } else {
            start(svc);
        }
    }

    static boolean hasPermission(Context ctx) {
        return ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private static void start(HomeKeyService svc) {
        host = svc;
        if (!hasPermission(svc)) {
            Island.message(svc, Island.WARN, "Falta el permiso del microfono",
                    "Ajustes del launcher > Novedades > Voz", 7000);
            return;
        }
        boolean onDevice = Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(svc);
        boolean standard = SpeechRecognizer.isRecognitionAvailable(svc);
        if (!onDevice && !standard) {
            Island.message(svc, Island.WARN, "Esta TV no trae reconocimiento de voz",
                    "Instala la app de Google o un servicio de voz", 7000);
            return;
        }
        active = true;
        Island.listening(svc);
        // Modes: 0 = on the TV, 1 = system recogniser preferring offline, 2 = system recogniser plain.
        // Error 5 (client) is common with the on-device one on some TVs, so a failure falls to the next mode.
        begin(svc, onDevice ? 0 : 1);
    }

    private static boolean nextMode(HomeKeyService svc) {
        if (mode >= 2) return false;
        if (mode == 0 && !SpeechRecognizer.isRecognitionAvailable(svc)) return false;
        mode = mode == 0 ? 1 : 2;
        return true;
    }

    private static void begin(final HomeKeyService svc, int m) {
        mode = m;
        H.removeCallbacks(TIMEOUT);
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (RuntimeException ignored) {
                // Already gone.
            }
            recognizer = null;
        }
        try {
            recognizer = m == 0 ? SpeechRecognizer.createOnDeviceSpeechRecognizer(svc)
                    : SpeechRecognizer.createSpeechRecognizer(svc);
        } catch (RuntimeException e) {
            if (nextMode(svc)) {
                begin(svc, mode);
                return;
            }
            teardown();
            Island.done(svc, false, "No pude iniciar la voz", "");
            return;
        }
        recognizer.setRecognitionListener(new Listener());
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        if (m != 2) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        try {
            recognizer.startListening(i);
        } catch (RuntimeException e) {
            if (nextMode(svc)) {
                begin(svc, mode);
                return;
            }
            teardown();
            Island.done(svc, false, "No pude escuchar", "");
            return;
        }
        H.postDelayed(TIMEOUT, 14000);
    }

    private static void teardown() {
        active = false;
        H.removeCallbacks(TIMEOUT);
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (RuntimeException ignored) {
                // Already gone.
            }
            recognizer = null;
        }
    }

    private static void finish(String text) {
        teardown();
        VoiceCommands.Result r = VoiceCommands.run(host, text);
        Island.done(host, r.ok, r.title, r.sub);
    }

    private static void failed(int error) {
        teardown();
        String title;
        String sub = "";
        switch (error) {
            case 6:
            case 7:
                title = "No te escuche";
                sub = "Pulsa el boton y habla";
                break;
            case 9:
                title = "Falta el permiso del microfono";
                sub = "Ajustes del launcher > Novedades > Voz";
                break;
            case 3:
                title = "No hay microfono disponible";
                sub = "Esta TV o su mando no lo entregan a las apps";
                break;
            case 8:
                title = "El reconocimiento esta ocupado";
                sub = "Intenta de nuevo";
                break;
            case 12:
            case 13:
                title = "Falta el idioma sin conexion";
                sub = "Descargalo en los ajustes de voz de la TV";
                break;
            case 1:
            case 2:
            case 4:
                title = "Sin conexion";
                sub = "No hay voz sin Internet en esta TV";
                break;
            default:
                title = "No pude escucharte";
                sub = "Codigo " + error + " (modo " + mode + ")";
                break;
        }
        Island.done(host, false, title, sub);
    }

    private static final class Listener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle params) { }

        @Override public void onBeginningOfSpeech() { }

        @Override public void onRmsChanged(float rms) {
            Island.level(Math.max(0f, Math.min(1f, (rms + 2f) / 12f)));
        }

        @Override public void onBufferReceived(byte[] buffer) { }

        @Override public void onEndOfSpeech() { }

        @Override public void onError(int error) {
            if (!active) return;
            if ((error == 5 || error == 1 || error == 2 || error == 4 || error == 12 || error == 13) && nextMode(host)) {
                final int m = mode;
                if (recognizer != null) {
                    try {
                        recognizer.destroy();
                    } catch (RuntimeException ignored) {
                        // Already gone.
                    }
                    recognizer = null;
                }
                H.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (active) begin(host, m);
                    }
                }, 300);
                return;
            }
            failed(error);
        }

        @Override public void onResults(Bundle results) {
            if (!active) return;
            ArrayList<String> list = results == null ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            finish(list == null || list.isEmpty() ? "" : list.get(0));
        }

        @Override public void onPartialResults(Bundle partial) {
            if (!active || partial == null) return;
            ArrayList<String> list = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty() && !list.get(0).isEmpty()) Island.heard(host, list.get(0));
        }

        @Override public void onEvent(int eventType, Bundle params) { }
    }
}
