package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.io.File;
import java.util.Calendar;

/**
 * Custom: a looping, muted video behind Home. The file is copied once into the app's private storage by
 * Launcher settings ("Video de fondo"); while it exists it plays under the tiles, centre-cropped.
 * With a second file for the night (Novedades) the video changes by itself at the chosen hours, with a fade.
 */
final class VideoWallpaper implements TextureView.SurfaceTextureListener {
    private static final String TAG = "TvHome.VideoWallpaper";
    static final String FILE_NAME = "video_wallpaper.mp4";
    static final String NIGHT_FILE_NAME = "video_wallpaper_night.mp4";
    static final String NIGHT_FROM = "video_night_from";
    static final String DAY_FROM = "video_day_from";

    private final Context ctx;
    private final FrameLayout root;
    private TextureView texture;
    private View shade;
    private Surface surface;
    private MediaPlayer player;
    private boolean wanted;
    private int videoWidth;
    private int videoHeight;
    private File playing;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable periodTick = new Runnable() {
        @Override public void run() {
            if (!wanted) return;
            if (texture != null && player != null && playing != null && !current(ctx).equals(playing)) swap();
            handler.postDelayed(this, 60000L);
        }
    };

    VideoWallpaper(Context context, FrameLayout root) {
        this.ctx = context;
        this.root = root;
    }

    static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    static File nightFile(Context context) {
        return new File(context.getFilesDir(), NIGHT_FILE_NAME);
    }

    private static boolean valid(File f) {
        return f.isFile() && f.length() > 0;
    }

    /** True when there is a video for the day, for the night, or both. */
    static boolean exists(Context context) {
        return valid(file(context)) || valid(nightFile(context));
    }

    /** True between the hour the night starts and the hour the day starts (19:00 and 07:00 unless changed). */
    static boolean isNight(Context context) {
        SharedPreferences p = context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        int night = p.getInt(NIGHT_FROM, 19);
        int day = p.getInt(DAY_FROM, 7);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return night > day ? (hour >= night || hour < day) : (hour >= night && hour < day);
    }

    /** The video for this moment: the night one after dark when both exist, otherwise whichever exists. */
    static File current(Context context) {
        File day = file(context);
        File night = nightFile(context);
        if (valid(day) && valid(night)) return isNight(context) ? night : day;
        return valid(day) ? day : night;
    }

    /** Removes both videos. */
    static void removeAll(Context context) {
        file(context).delete();
        nightFile(context).delete();
    }

    /** Shows and plays the video when the file exists; otherwise removes it so the normal wallpaper shows. */
    void start() {
        if (!exists(ctx)) {
            stop();
            hideViews();
            return;
        }
        wanted = true;
        ensureViews();
        texture.setAlpha(1f);
        texture.setVisibility(View.VISIBLE);
        shade.setVisibility(View.VISIBLE);
        handler.removeCallbacks(periodTick);
        handler.postDelayed(periodTick, 60000L);
        if (surface != null) prepare();
    }

    void stop() {
        wanted = false;
        handler.removeCallbacks(periodTick);
        releasePlayer();
    }

    void close() {
        stop();
        if (texture != null) root.removeView(texture);
        if (shade != null) root.removeView(shade);
        texture = null;
        shade = null;
        if (surface != null) {
            surface.release();
            surface = null;
        }
    }

    private void ensureViews() {
        if (texture != null) return;
        texture = new TextureView(ctx);
        texture.setSurfaceTextureListener(this);
        texture.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        shade = new View(ctx);
        shade.setBackgroundColor(0x59000000);
        shade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        // Above a still wallpaper (child 0, if there is one) and below everything else.
        int index = root.getChildCount() > 0 && root.getChildAt(0) instanceof android.widget.ImageView ? 1 : 0;
        FrameLayout.LayoutParams match = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(texture, index, match);
        root.addView(shade, index + 1, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void hideViews() {
        if (texture != null) texture.setVisibility(View.GONE);
        if (shade != null) shade.setVisibility(View.GONE);
    }

    private void prepare() {
        releasePlayer();
        if (!wanted || surface == null) return;
        try {
            MediaPlayer mp = new MediaPlayer();
            File f = current(ctx);
            mp.setDataSource(f.getAbsolutePath());
            playing = f;
            mp.setSurface(surface);
            mp.setLooping(true);
            mp.setVolume(0f, 0f);
            mp.setOnVideoSizeChangedListener((m, w, h) -> {
                videoWidth = w;
                videoHeight = h;
                fit();
            });
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.setOnInfoListener((m, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && texture != null) {
                    texture.animate().cancel();
                    texture.animate().alpha(1f).setDuration(900).start();   // the fade-in after a day/night swap
                }
                return false;
            });
            mp.setOnErrorListener((m, what, extra) -> {
                Log.w(TAG, "Video error " + what + "/" + extra);
                releasePlayer();
                hideViews();
                return true;
            });
            player = mp;
            mp.prepareAsync();
        } catch (Exception e) {
            Log.w(TAG, "Could not play the video wallpaper", e);
            releasePlayer();
            hideViews();
        }
    }

    /** Day to night (or back): fade the picture out, load the other video, and it fades in as it starts. */
    private void swap() {
        if (texture == null) return;
        texture.animate().cancel();
        texture.animate().alpha(0f).setDuration(700).withEndAction(() -> {
            if (wanted) prepare();
        }).start();
    }

    private void releasePlayer() {
        if (player == null) return;
        try {
            player.release();
        } catch (RuntimeException ignored) {
            // Already released.
        }
        player = null;
    }

    /** TextureView stretches the video to its size; this scales it up so it covers the screen (centre-crop). */
    private void fit() {
        if (texture == null || videoWidth <= 0 || videoHeight <= 0) return;
        float vw = texture.getWidth();
        float vh = texture.getHeight();
        if (vw <= 0 || vh <= 0) return;
        float contentAspect = (float) videoWidth / videoHeight;
        float viewAspect = vw / vh;
        float sx = 1f;
        float sy = 1f;
        if (contentAspect > viewAspect) sx = contentAspect / viewAspect;
        else sy = viewAspect / contentAspect;
        Matrix matrix = new Matrix();
        matrix.setScale(sx, sy, vw / 2f, vh / 2f);
        texture.setTransform(matrix);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
        surface = new Surface(st);
        if (wanted) prepare();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {
        fit();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        releasePlayer();
        if (surface != null) {
            surface.release();
            surface = null;
        }
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
    }
}
