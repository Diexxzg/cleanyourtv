package com.gathin.tvhome;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ChangedPackages;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.SoundEffectConstants;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * tvOS style home: black, a pinned dock row, an app grid, and one glass highlight that springs between tiles.
 */
public class MainActivity extends Activity implements AppAdapter.TileListener {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(LauncherLocale.wrap(base));   // locale
    }


    private static final int LAUNCHER_SETTINGS_REQUEST = 42;
    /** Sent by QuickSettingsActivity: open Launcher settings from here so Home rebuilds when they close. */
    static final String ACTION_LAUNCHER_SETTINGS = "com.gathin.tvhome.action.LAUNCHER_SETTINGS";
    /** Sent by the "library" action word of app_keys: open the App library over Home (needs app_library). */
    static final String ACTION_APP_LIBRARY = "com.gathin.tvhome.action.APP_LIBRARY";
    /** The system input switcher, forwarded here by InputsRequestActivity while handle_view_inputs is on. */
    static final String ACTION_VIEW_INPUTS = "com.android.tv.action.VIEW_INPUTS";
    /** Tiles per row and dock slots (res/values/config.xml, columns). Set in onCreate. */
    static int COLUMNS = 4;
    private boolean rtlAppGrid;
    private static final long MINUTE_MS = 60_000L;
    private static final long STATS_MS = 10_000L;
    /**
     * 2025-01-01. TVs without a clock battery boot at the epoch (08:00 in China) and keep it until network
     * time arrives; the clock, date and greeting stay hidden before then.
     */
    private static final long TIME_VALID_AFTER_MS = 1_735_689_600_000L;
    private String liveTvPkg;
    private boolean homeIgnoreChannelKeys;
    /** Launcher settings' change count this Home was built with (see onResume). */
    private long settingsRevision;
    /** Idle time on Home before ClockActivity; 0 is off (config.xml, home_idle_clock_minutes). */
    private long idleClockMs;
    /** Back on Home opens ClockActivity (config.xml, back_opens_clock). */
    private boolean backOpensClock;
    private final Runnable showIdleClock = this::onIdleTimeout;

    /** Idle on Home: with music playing go to the music screen (lyrics, cover); otherwise the screensaver. */
    private void onIdleTimeout() {
        boolean music = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean("idle_music", true)
                && nowPlaying != null && cpPlaying && !TextUtils.isEmpty(cpTitle) && !musicModeOpen;
        if (music) showMusicMode(); else if (!ambientMode) enterAmbientMode();
    }
    private String liveTvAction;
    private String liveTvInputId;
    /** The app library is on (config.xml, app_library): only then can the tile menu take an app off Home. */
    private boolean appLibraryEnabled;
    /** The same opt-in menu is available from either hold-OK or the remote's Menu key. */
    private boolean tileMenuEnabled;
    private String inputAction;
    private List<String> inputSources;
    private String inputUriScheme;
    private String sourcePanelService;
    private String sourcePanelAction;
    private String sourcePanelExtra;
    private boolean coocaaSources;

    private AppAdapter adapter;
    private RecyclerView grid;
    private FrameLayout root;
    private WallpaperPlayer wallpaperPlayer;
    private VideoWallpaper videoWallpaper;
    private GlassView glass;
    private View ambient;
    private TextView heroName;
    /** The top shelf: heroName, plus the cinematic shelf's "Last opened" line and dock position dots. */
    private View hero;
    private TextView heroMeta;
    private LinearLayout heroDots;
    /** Cinematic top shelf (config.xml, cinematic_home): the focused dock app's artwork behind a larger shelf. */
    private boolean cinematic;
    /** config.xml ambient_glow, overridable by a theme. Off: the glow view is gone and no fade or colour animator
     *  is started for it, so a focus move costs nothing extra on a launcher that runs all day. */
    private boolean ambientGlow;
    /** config.xml app_glow: the highlight takes the focused app's colour on every tile. */
    private boolean appGlow;
    /** config.xml glow_style: the shape setAmbient paints the glow mask in. */
    private String glowStyle;
    /** config.xml cinematic_white_focus: the cinematic shelf keeps the white highlight. */
    private boolean cinematicWhiteFocus;
    private ImageView heroArt;
    /** config.xml cinematic_dots: false leaves the dock position dots out of the cinematic shelf. */
    private boolean heroDotsShown = true;
    /** The artwork's opacity behind the cinematic shelf (config.xml cinematic_art); 0 leaves it out. */
    private float heroArtAlpha = 0.5f;
    /** Softened artwork per app (HeroArt, about 5 KB each), made the first time its dock tile is focused. */
    private final Map<String, Bitmap> heroArtCache = new HashMap<>();
    /** The app whose artwork heroArt shows, so focusing it again only fades it back in. */
    private String heroArtKey;
    /** The focus glow's colour while the cinematic shelf tints it, 0 for plain white glass. */
    private int glassAccent;
    private int ambientColor = -1;
    private ValueAnimator ambientAnimator;
    /** config.xml glow_snap: the glow takes a new colour in one frame instead of the dip-and-fade. */
    private boolean glowSnap;
    private boolean heroShown;
    private boolean animations;
    private boolean advancedEffects;
    private TextView greeting;
    private View clockBlock;
    private View btnInputs;
    /** config show_inputs_pill: false keeps the Inputs pill hidden even when the TV has inputs. */
    private boolean showInputsPill = true;
    private TextView btnWifi;
    /** The network pill's icon as last set, so a refresh that changes nothing does not lay the top bar out again. */
    private int wifiIcon;
    /** The pills have been filled in once; later resumes refresh them after the first frame. */
    private boolean pillsShown;
    private TextView shamsiDate;
    /** lunar_date: the lunisolar date under the date line, and the time zone it is computed for. */
    private TextView lunarDate;
    private boolean lunar;
    private int lunarOffset;
    private TextView stats;
    private List<RaceWeekend.Race> raceCalendar;
    private View racePanel;
    private TextView raceKicker, raceHeadline, raceSessions;
    /** game_day: each team's next game from an add-on, rotating in the race panel; null when the key is off. */
    private GameDay gameDay;
    private View raceBar;
    private LinearLayout racePager;
    private long rotationStart;
    private long lastEndedRead;
    private final Runnable turnTick = this::updatePanel;
    /** config.xml show_stats, overridable by a theme. Off: the line is gone and nothing is read. */
    private boolean showStats;
    /** config.xml inputs_connected_only: the Inputs menu lists only connected inputs, the rest behind "More inputs". */
    private boolean inputsConnectedOnly;
    /** config.xml inputs_cec_state_only: only CEC device rows show a connection state, bare HDMI ports none. */
    private boolean inputsCecStateOnly;
    private boolean shamsi;
    /** greeting_name: said after the greeting, which is shown in capitals. */
    private String greetingName = "";
    /** Optional time-of-day backdrop (config.xml, sky_intensity); 0 keeps it hidden. */
    private SkyView sky;
    private String vpnApp;
    /** vpn_pill: the VPN shown as its own pill (btnVpn) instead of a badge in the network pill. Off with top_menu. */
    private boolean vpnPill;
    private TextView btnVpn;
    /** The VpnBadge pill state btnVpn shows, so a refresh that changes nothing does not restyle it. */
    private int vpnPillState = VpnBadge.PILL_HIDDEN;
    /** icon_only_vpn: the VPN pill is a round lock button; off, it keeps the plain glass look saved here. */
    private boolean iconOnlyVpn;
    private Drawable.ConstantState vpnPlainBackground;
    private ColorStateList vpnPlainInk;
    private SpringAnimation springX, springY;
    private float glassTargetX, glassTargetY;
    // How far the grid has scrolled the glass. springY works without it, in grid content space, so a
    // scroll moves the glass in lockstep with its tile instead of becoming a moving spring target.
    private float glassScrollShift;
    /** The same for springX, when single_row scrolls the grid sideways. */
    private float glassScrollShiftX;
    private int glassCardW;   // width of the tile the glass was last fitted to
    /**
     * The focused tile's rect in root coordinates as {@link #onTileFocused} last fitted the glass to it. The size
     * alone cannot say whether the glass is on its tile: a cold start can run onTileFocused once the tile has its
     * final width but before the grid has its top padding, which leaves the right size at the old Y.
     */
    private final Rect glassCardRect = new Rect();
    private boolean glassShown;
    private final Rect tileRect = new Rect();
    private final Rect revealRect = new Rect();
    // Static so they survive the activity being destroyed while another app is open (low-memory TVs,
    // or Developer options → "Don't keep activities"); they only reset when the process dies.
    private static int lastFocused = 0;
    /** App of the last focused tile, so focus follows it when the app list changes. */
    private static String lastFocusedKey;
    private float density;
    /** Module cards (res/values/config.xml, module_cards): discovered on resume, shown only after the owner's Show. */
    private boolean moduleCards;
    /** config settings_key_keycodes / settings_key_panel, so the Settings button works on Home without HomeKeyService. */
    private int[] settingsKeycodes = new int[0];
    private boolean settingsKeyPanel;
    private boolean settingsKeyClearTask;
    /** Calmer motion for weak GPUs (config.xml, reduced_motion): stiff spring, short fades, no replay. */
    private boolean reducedMotion;
    /** config.xml dock_row: the first row is a separate dock (band, parked low, top shelf) rather than plain grid. */
    private boolean dockRow;
    /** config single_row: every app in the dock's row, scrolling sideways, no grid below. */
    private boolean singleRow;
    /** The highlight springs past its target (config.xml, focus_overshoot); false goes straight there. */
    private boolean focusOvershoot;
    /** Festive skin from the theme (see Festival); applied while it is active today. */
    private Festival festival = Festival.NONE;
    private boolean festive;
    /** The network pill's festive light: the diya, or the jack-o'-lantern for Halloween. */
    private FestiveLamp lamp;
    private BellDrawable bell;
    private MarigoldDrawable marigold;
    private int greetingColor;
    /** The day the petal shower last played, so it greets the first Home of each day only. */
    private static LocalDate lastPetalShower;
    /** boot_to_live_tv: open the Live TV app on the first Home of each boot. */
    private boolean bootToLiveTv;
    /** The input in the Live TV tile's launch_actions ("input:<id>"), opened at power-on instead of the Live TV app. */
    private String bootInputId;
    /** open_on_start_choice: the app picked in Launcher settings may open on the first Home of each boot. */
    private boolean openOnStartChoice;
    /** open_on_start_network_wait, in ms; the boot's app while it waits for the network, and until when. */
    private long openOnStartWaitMs;
    /** open_on_start_on_wake: wakeReceiver is registered for this activity's life. */
    private boolean openOnStartOnWake;
    private volatile Intent startPending;
    private long startDeadline;
    /** Opens the boot's app once the network is validated (networkCallback posts this) or the wait is over. */
    private final Runnable openWhenOnline = new Runnable() {
        @Override
        public void run() {
            if (startPending == null) return;
            if (!OpenOnStart.opensNow(OpenOnStart.online(MainActivity.this), SystemClock.elapsedRealtime(),
                    startDeadline)) return;
            handler.removeCallbacks(this);   // the deadline's run, when the network came first
            Intent i = startPending;
            startPending = null;
            open(i);
        }
    };
    private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            openStartAppOnWake();
        }
    };
    /** hidden_apps as the adapter sees them (config.xml or a theme's config.json): a hidden app gets no card either. */
    private Set<String> hiddenApps = Collections.emptySet();
    /** library_excluded_apps: packages the App library catalogue never offers. */
    private Set<String> libraryExcludedApps = Collections.emptySet();
    private List<Cards.Card> cards = Collections.emptyList();
    /** The grid has been laid out and focused since the last resume; the card prompt waits for this. */
    private boolean tilesReady;
    private boolean settingsRecreationPending;
    private Dialog cardPrompt;
    /** Set when a decision could not be saved: no more prompts until the next resume, instead of asking in a loop. */
    private boolean promptsPaused;
    /** Between onStop and onStart: Home was fully covered by an app, not just by the translucent quick panel. */
    private boolean stopped;
    /** Between onStart and onStop: Home is (at least partly) on screen. */
    private boolean started;
    /**
     * Between onResume and onPause: Home is in front. The idle clock only runs then; a key's ACTION_UP can still
     * reach Home after onPause, when that key opened another app, and must not start the clock over the app.
     */
    private boolean resumed;
    /** Rebuild the tiles on the way back to Home only when apps changed meanwhile (TileRefresh). */
    private final TileRefresh tileRefresh = new TileRefresh();
    /** PackageManager's change counter at the last rebuild, to catch a package broadcast that never arrived. */
    private int packageSequence;
    /** The Inputs or Module cards dropdown while one is open, so onPause can close it. */
    private PopupWindow openPopup;
    /** Reorder mode is on (top-bar button). */
    private boolean reordering;
    /** Key of the tile being carried in reorder mode, or null. */
    private String movingKey;
    /** Tile order when reorder mode started, to save only when something moved. */
    private List<String> orderAtStart;
    /**
     * fill_dock false: tiles in the dock when reorder mode started, plus those carried or swapped into it since
     * (#499). A grid app that only slid into a free slot, which reorder mode does not show, is not one of them.
     */
    private Set<String> dockInSession;
    /** fill_dock false: how many dock slots held an app when reorder mode started. */
    private int dockedAtStart;
    private View btnReorder;
    /** dock_apps as loaded (config.xml or a theme): a saved Order only applies while these are unchanged. */
    private List<String> dockApps;
    /** fill_dock false: the dock can have empty slots, which reorder mode leaves out and restores afterwards. */
    private boolean fillDockLeavesSlots;
    /** Edit-dock mode (Settings menu): a reorder session that swaps one chosen app into one dock place. */
    private boolean dockEditing;
    /** Dock place being changed in edit-dock mode, or -1 while the place is still being chosen. */
    private int dockEditSlot = -1;
    /** Tile menu's "Add to dock": the app waiting for a dock place in edit-dock mode, or null. */
    private String dockEditAppKey;
    private AppLibraryDialog appLibrary;
    private boolean appLibrarySelection;
    private boolean libraryOkOpens;
    private boolean libraryFocusPending;
    private RecyclerView.OnScrollListener pendingFocusScroll;

    private final Handler handler = new Handler(Looper.getMainLooper());
    /** Refreshes the network pill when the connection changes: at boot Wi-Fi often connects after Home is shown. */
    private final ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        @Override
        public void onLost(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        /** wifi_status_warnings follows validation; signal-strength updates also land here, so skip those. */
        private boolean lastValidated;

        @Override
        public void onCapabilitiesChanged(@NonNull Network network, @NonNull NetworkCapabilities caps) {
            boolean validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            // open_on_start_network_wait: the boot's app opens on the first validated network.
            if (validated && startPending != null) handler.post(openWhenOnline);
            if (validated == lastValidated) return;
            lastValidated = validated;
            if (wifiNoInternetTint != null) handler.post(MainActivity.this::updateWifiLabel);
        }
    };
    /** Shows the Inputs pill once the TV registers an input: at boot HDMI inputs can appear after Home is shown. */
    private final TvInputManager.TvInputCallback inputCallback = new TvInputManager.TvInputCallback() {
        @Override
        public void onInputAdded(String inputId) {
            updateInputsButton();
        }

        @Override
        public void onInputRemoved(String inputId) {
            updateInputsButton();
        }
    };
    /** Listens for any VPN coming up or going down, even one this app's traffic is excluded from. */
    private final ConnectivityManager.NetworkCallback vpnCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        @Override
        public void onLost(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }
    };
    private final IntentFilter packageFilter = new IntentFilter();
    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Updates send REMOVED followed by ADDED; keep the tile until the new APK is ready.
            if (Intent.ACTION_PACKAGE_REMOVED.equals(intent.getAction())
                    && intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return;
            // In the background this only marks the tiles stale; onResume rebuilds them once.
            if (!tileRefresh.onPackagesChanged()) return;
            reloadApps(false);
            if (appLibrary != null) appLibrary.refresh();
        }
    };
    // Right after boot the clock is often wrong until network time arrives; don't wait a minute to catch up.
    private final IntentFilter timeFilter = new IntentFilter(Intent.ACTION_TIME_CHANGED);
    private final BroadcastReceiver timeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateClockVisibility();
            clockRefresh.start();   // the wall clock was set: line the redraw up with the new minute
        }
    };
    /** Keeps the Home clocks moving on Android before 12 when the firmware stops ACTION_TIME_TICK (see ClockRefresh). */
    private ClockRefresh clockRefresh;
    private final Runnable minuteTick = new Runnable() {
        @Override
        public void run() {
            updateGreeting();
            updatePanel();
            // The pill follows the network callbacks and each return to Home; only the festive light follows the
            // signal level, so only it needs this minute's binder calls (about 7 ms on the UI thread).
            if (festive) updateWifiLabel();
            sky.update();
            wallpaperPlayer.update();
            handler.postDelayed(this, MINUTE_MS);
        }
    };

    private java.util.Map<Integer, String> homeAppKeys = java.util.Collections.emptyMap();
    /** clock_format, for the race panel's session times (the TextClocks take it in onCreate). */
    private String clockFormat = "system";
    private java.util.Map<Integer, String> homeHoldAppKeys = java.util.Collections.emptyMap();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        density = getResources().getDisplayMetrics().density;
        // config.xml, overlaid by config.json from a pushed theme (see Config and tools/theme.sh).
        Config cfg = Config.load(this);
        homeAppKeys = RemoteKeys.parseAppKeys(cfg.appKeys);
        clockFormat = cfg.clockFormat;
        ClockFormat.apply(getWindow().getDecorView(), clockFormat);
        homeHoldAppKeys = RemoteKeys.parseHoldAppKeys(cfg.appKeys);
        appLibrarySelection = cfg.appLibrarySelection;
        libraryOkOpens = cfg.libraryOkOpens;
        // restore_key_services: after a force stop, put back the remote's accessibility helpers that Android took
        // off the list (needs WRITE_SECURE_SETTINGS, granted by build-and-install with RESTORE_KEY_SERVICES=1).
        if (cfg.restoreKeyServices) ServiceRepair.restore(this);
        settingsRevision = settingsRevision();
        applyViewInputsHandler(cfg.handleViewInputs);
        settingsKeycodes = cfg.settingsKeycodes;
        settingsKeyPanel = cfg.settingsKeyPanel;
        settingsKeyClearTask = cfg.settingsKeyClearTask;
        COLUMNS = cfg.columns;
        animations = cfg.animations;
        advancedEffects = cfg.animations && cfg.advancedEffects;
        reducedMotion = cfg.reducedMotion;
        dockRow = cfg.dockRow;
        singleRow = cfg.singleRow;
        focusOvershoot = cfg.focusOvershoot;
        festival = cfg.festival;
        festive = festival.active(LocalDate.now());
        liveTvPkg = cfg.liveTvPackage;
        homeIgnoreChannelKeys = cfg.homeIgnoreChannelKeys;
        idleClockMs = cfg.homeIdleClockMinutes * MINUTE_MS;
        backOpensClock = cfg.backOpensClock;
        bootToLiveTv = cfg.bootToLiveTv;
        bootInputId = LaunchActions.inputId(cfg.launchActions.get(cfg.liveTvPackage));
        openOnStartChoice = cfg.openOnStartChoice;
        openOnStartWaitMs = cfg.openOnStartNetworkWait * 1000L;
        openOnStartOnWake = OpenOnStart.onWake(cfg.openOnStartChoice, cfg.openOnStartOnWake);
        liveTvAction = cfg.liveTvAction;
        liveTvInputId = cfg.liveTvInputId;
        appLibraryEnabled = cfg.appLibrary;
        tileMenuEnabled = cfg.tileMenu;
        inputAction = cfg.inputAction;
        inputSources = cfg.inputSources;
        inputUriScheme = cfg.inputUriScheme;
        sourcePanelService = cfg.sourcePanelService;
        sourcePanelAction = cfg.sourcePanelAction;
        sourcePanelExtra = cfg.sourcePanelExtra;
        coocaaSources = cfg.coocaaSources;

        root = findViewById(R.id.root);
        root.setBackgroundColor(cfg.backgroundColor);
        // root fills the window with an opaque colour (Config keeps background_color opaque), so the window's own
        // black under it is a second full-screen fill on every frame for nothing. The starting window still uses
        // the theme's background, so launch looks the same.
        getWindow().setBackgroundDrawable(null);
        wallpaperPlayer = new WallpaperPlayer(this, root, cfg);
        videoWallpaper = new VideoWallpaper(this, root);
        bluetoothPill = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE)
                .getBoolean(LauncherSettingsActivity.BLUETOOTH_PILL_KEY, true);
        View wallpaperDim = findViewById(R.id.wallpaperDim);
        int shade = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE)
                .getInt(LauncherSettingsActivity.WALLPAPER_SHADE_KEY, 0);
        if (shade > 0 && shade <= 90) {
            wallpaperDim.setBackgroundColor(Math.round(shade * 2.55f) << 24);
            wallpaperDim.setVisibility(View.VISIBLE);
        } else {
            wallpaperDim.setVisibility(View.GONE);
        }
        sky = findViewById(R.id.sky);
        sky.setIntensity(cfg.skyIntensity);
        glass = findViewById(R.id.glass);
        setupLiquidGlass();
        glass.setStyle(cfg.glassStyle);
        if (festive) glass.setAccent(festival.accentColor());
        ambient = findViewById(R.id.ambient);
        // The glow is one bitmap, so its alpha can be applied while drawing it. Otherwise every frame of
        // a fade renders it into a full-screen offscreen buffer first.
        ambient.forceHasOverlappingRendering(false);
        ambientGlow = cfg.ambientGlow;
        glowSnap = cfg.glowSnap;
        appGlow = cfg.appGlow;
        if (!ambientGlow) ambient.setVisibility(View.GONE);
        heroName = findViewById(R.id.heroName);
        hero = findViewById(R.id.hero);
        // The hero is now a group (name, and the cinematic lines): without this every fade of the default
        // shelf would render it through an offscreen buffer first, as the glow above notes.
        hero.forceHasOverlappingRendering(false);
        heroMeta = findViewById(R.id.heroMeta);
        heroDots = findViewById(R.id.heroDots);
        heroArt = findViewById(R.id.heroArt);
        cinematic = cfg.cinematicHome;
        glowStyle = cfg.glowStyle;
        heroDotsShown = cfg.cinematicDots;
        cinematicWhiteFocus = cfg.cinematicWhiteFocus;
        heroArtAlpha = cfg.cinematicArt / 100f;
        if (cinematic) setUpCinematicShelf(cfg.cinematicScrim);
        // dock_title false: the name above the dock (and the cinematic lines under it) never shows; the glow
        // still follows the dock.
        if (!cfg.dockTitle) hero.setVisibility(View.GONE);
        greeting = findViewById(R.id.greeting);
        clockBlock = findViewById(R.id.leftBlock);
        clockRefresh = new ClockRefresh(clockBlock);
        greetingColor = greeting.getCurrentTextColor();
        if (!cfg.showGreeting) greeting.setVisibility(View.GONE);
        // Keep the other header layouts as designed: their extra lines change the block's centre.
        if (!cfg.showGreeting && !cfg.dateBelowClock && !cfg.shamsiDate && !cfg.lunarDate
                && !cfg.topMenu && !getResources().getBoolean(R.bool.rtl_menu_bar)) {
            centerCompactHeader();
        }
        if (cfg.headerWhite) {
            // The clock's own white for the date and the line before it, instead of their dimmed whites.
            ((TextView) findViewById(R.id.date)).setTextColor(Color.WHITE);
            findViewById(R.id.clockDivider).setBackgroundColor(Color.WHITE);
        }
        if (getResources().getBoolean(R.bool.rtl_menu_bar)) {
            // Center Hebrew greetings over the numeric time, independent of a visible AM/PM label. The clock's row
            // is watched too: date_below_clock can move the whole row right under a wider date.
            View clock = findViewById(R.id.clock);
            View clockRow = (View) clock.getParent();
            View.OnLayoutChangeListener centerGreeting = (v, l, t, right, bottom, ol, ot, or, ob) -> {
                ViewGroup.LayoutParams params = greeting.getLayoutParams();
                if (params.width != clock.getWidth()) {
                    params.width = clock.getWidth();
                    greeting.setLayoutParams(params);
                }
                greeting.setTranslationX(clockRow.getLeft() + clock.getLeft());
            };
            clock.addOnLayoutChangeListener(centerGreeting);
            clockRow.addOnLayoutChangeListener(centerGreeting);
        }
        btnWifi = findViewById(R.id.btnWifi);
        shamsiDate = findViewById(R.id.shamsiDate);
        stats = findViewById(R.id.stats);
        raceCalendar = cfg.raceCalendar;
        racePanel = findViewById(R.id.racePanel);
        raceKicker = findViewById(R.id.raceKicker);
        raceHeadline = findViewById(R.id.raceHeadline);
        raceSessions = findViewById(R.id.raceSessions);
        raceBar = findViewById(R.id.raceBar);
        racePager = findViewById(R.id.racePager);
        gameDay = GameDay.create(this, cfg.gameDay, handler, this::updatePanel);
        // The rotation runs on the clock that never jumps: setting the TV's time must not stall or stretch a turn.
        rotationStart = SystemClock.elapsedRealtime();
        showStats = cfg.showStats;
        inputsConnectedOnly = cfg.inputsConnectedOnly;
        inputsCecStateOnly = cfg.inputsCecStateOnly;
        shamsi = cfg.shamsiDate;
        lunarDate = findViewById(R.id.lunarDate);
        lunar = cfg.lunarDate;
        lunarOffset = Lunar.offsetFor(cfg.lunarUtcOffset, Locale.getDefault());
        if (lunar) lunarDate.setVisibility(View.VISIBLE);
        greetingName = cfg.greetingName;
        if (cfg.dateBelowClock) moveDateBelowClock();
        if (cfg.dateBelowClock && cfg.iconOnlyButtons && !cfg.topMenu
                && !getResources().getBoolean(R.bool.rtl_menu_bar)) {
            alignDateBelowIconsWithClock();
        }
        if (shamsi) {
            shamsiDate.setVisibility(View.VISIBLE);
            TextView date = findViewById(R.id.date);
            date.setTextSize(11f);
            lunarDate.setTextSize(11f);
            date.setPadding(0, (int) (4 * density), 0, 0);
        }
        vpnApp = cfg.vpnApp;
        vpnPill = cfg.vpnPill && !cfg.topMenu;
        btnVpn = findViewById(R.id.btnVpn);
        moduleCards = cfg.moduleCards;
        hiddenApps = new HashSet<>(cfg.hiddenApps);
        libraryExcludedApps = new HashSet<>(cfg.libraryExcludedApps);

        grid = findViewById(R.id.grid);
        glowEnabled = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean("color_glow", true);
        setupIconGlow();
        SoftSounds.init(this);
        rtlAppGrid = getResources().getBoolean(R.bool.rtl_app_grid);
        // Mirror only the app grid; the header and other locales keep their own layouts.
        // single_row: one span laid out sideways, so the same adapter, glass and dock band serve a scrolling row.
        grid.setLayoutManager(new GridLayoutManager(this, singleRow ? 1 : COLUMNS,
                singleRow ? RecyclerView.HORIZONTAL : RecyclerView.VERTICAL, false) {
            @Override
            protected boolean isLayoutRTL() {
                return rtlAppGrid;
            }

            /**
             * Every "bring this tile on screen" scroll lands here, both RecyclerView's own on focus and
             * onTileFocused's. The stock version treats the grid's top padding as the visible top, but that
             * padding only pushes the dock down the screen: grid rows scroll up into it. With the stock rule,
             * Up into a row above the padding dragged that row down to the padding line, cut it off at the
             * bottom of the screen and could scroll the focused tile out entirely, dropping focus into the
             * top bar. Grid tiles now scroll just enough to show the rect between the grid's top edge and its
             * bottom; dock tiles are left to onTileFocused, which parks the dock row on the padding line.
             */
            @Override
            public boolean requestChildRectangleOnScreen(@NonNull RecyclerView parent, @NonNull View child,
                                                         @NonNull Rect rect, boolean immediate,
                                                         boolean focusedChildVisible) {
                if (singleRow) {
                    // Sideways: scroll just enough to bring the tile's cell inside the padding. Cells are a
                    // column wide, so the row moves a whole tile at a time and the tiles stay on the columns.
                    // The whole cell, not the card rect passed in: the card is narrower and centred in it.
                    int left = child.getLeft();
                    int right = child.getRight();
                    int dx;
                    if (left < getPaddingLeft()) dx = left - getPaddingLeft();
                    else if (right > getWidth() - getPaddingRight()) dx = right - (getWidth() - getPaddingRight());
                    else dx = 0;
                    if (dx == 0) return false;
                    if (immediate || reducedMotion || !animations) parent.scrollBy(dx, 0);
                    else parent.smoothScrollBy(dx, 0);
                    return true;
                }
                if (dockRow && getPosition(child) < COLUMNS) return false;
                int top = child.getTop() + rect.top;
                int bottom = top + rect.height();
                // A row already fully on screen stays put, even inside the bottom padding (the last row
                // rows_below_dock leaves visible ends there; nudging it up was the bug). A row that has to scroll
                // in still stops at the padding line, clear of the screen edge, as before.
                int limitBottom = getHeight() - getPaddingBottom();
                int dy;
                if (top < 0) dy = top;
                else if (bottom <= getHeight()) dy = 0;
                else dy = Math.min(top, bottom - limitBottom);
                if (dy == 0) return false;
                if (immediate || reducedMotion || !animations) parent.scrollBy(0, dy);
                else parent.smoothScrollBy(0, dy);
                return true;
            }
        });
        ((GridLayoutManager) grid.getLayoutManager()).setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) { return !singleRow && adapter != null && adapter.isLibraryAt(position) ? COLUMNS : 1; }
        });
        grid.setHasFixedSize(true);
        grid.setItemAnimator(null);
        // Tiles that scroll out while reordering come back from the view cache without a rebind; set their
        // dimming again whenever one attaches, so alpha matches the current mode.
        grid.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View v) {
                v.setAlpha(tileAlpha(grid.getChildAdapterPosition(v)));
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View v) {
            }
        });
        if (dockRow) grid.addItemDecoration(new DockDecoration(COLUMNS, density, cinematic, cfg.alwaysShowNames, cfg.dockOpacity, cfg.dockGlass, cfg.dockEvenPadding, cfg.dockBand,
                singleRow, cfg.dockBandAll));
        if (cfg.fadeRows) TopFade.attach(grid, 48 * density);
        // Reduced motion: the tiles are simply there, with no entrance (reloadApps skips it there too).
        if (animations && !reducedMotion) {
            grid.setLayoutAnimation(new LayoutAnimationController(
                    AnimationUtils.loadAnimation(this, R.anim.tile_enter), 0.06f));
        }
        adapter = new AppAdapter(this, this, COLUMNS, cfg);
        dockApps = cfg.dockApps;
        fillDockLeavesSlots = !cfg.fillDock;
        Order savedOrder = Order.load(Order.file(this));
        adapter.setSavedOrder(Order.ranks(savedOrder, dockApps), Order.docked(savedOrder, dockApps));
        grid.setAdapter(adapter);

        // tvOS layout: push the dock row towards the bottom of the screen, leaving room for
        // rows_below_dock grid rows under it; the rest of the grid stays below until you press Down.
        int rowsBelowDock = cfg.rowsBelowDock;
        grid.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int h = b - t;
            // Item height follows the tile size, which follows the columns and the rows that must fit (AppAdapter.tileWidthPx).
            int inner = (r - l) - grid.getPaddingLeft() - grid.getPaddingRight();
            int tileW = AppAdapter.tileWidthPx(inner, h, COLUMNS, rowsBelowDock, cfg.dockTitle, cfg.dockRow, density);
            int itemH = AppAdapter.itemHeightPx(AppAdapter.tileHeightPx(tileW), density);
            int dockRow = itemH + (int) (AppAdapter.DOCK_EXTRA_DP * density);   // item height plus DockDecoration offsets
            int gridRows = itemH * rowsBelowDock;
            // Keep the hero below the header when the library is enabled on a short screen,
            // even when the theme requests an extra visible row below the dock.
            int shelfClearance = cfg.appLibrary ? hero.getMeasuredHeight() + (int) (40 * density) : 0;
            int want = Math.max(shelfClearance, h - dockRow - gridRows - (int) (AppAdapter.BOTTOM_ROOM_DP * density));
            // Where the rows cannot fit even at the smallest tile (3 rows with the title on), the title keeps its
            // room above the dock and the last rows run off the bottom instead of the title drawing over the clock.
            if (MainActivity.this.dockRow && cfg.dockTitle && rowsBelowDock > 0) want = Math.max(want, (int) (AppAdapter.TITLE_ROOM_DP * density));
            // No dock to push down: the grid starts at the top, with room for the first row's zoom and glass.
            if (!MainActivity.this.dockRow) want = (int) (AppAdapter.TOP_ROOM_DP * density);
            // A single row never shows the names under its tiles (the title above the row names the app), so the
            // 7dp gap and 22dp label item_app.xml keeps for them would only lift the row: sit it that much lower.
            if (singleRow && !cfg.alwaysShowNames) want += (int) (29 * density);
            if (grid.getPaddingTop() != want) {
                grid.setPadding(grid.getPaddingLeft(), want, grid.getPaddingRight(), grid.getPaddingBottom());
                // A vertical grid parks the dock on the new padding line by scrolling (onTileFocused); a sideways
                // row cannot scroll vertically, and the layout request made from inside this layout pass is
                // dropped, so lay the row out again on the next frame. The glass and the title were placed for the
                // old position, so fit them again once it has moved.
                if (singleRow) grid.post(() -> {
                    grid.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            grid.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            int pos = Math.max(0, Math.min(lastFocused, adapter.appCount() - 1));
                            RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(pos);
                            View card = vh == null ? null : vh.itemView.findViewById(R.id.card);
                            if (card != null && card.isFocused()) onTileFocused(pos, card);
                        }
                    });
                    grid.requestLayout();
                });
            }
            // Cold start or column count > 4: the first focus can run before the grid has its final width or
            // padding, leaving the glass at the XML design size until a key is pressed.
            grid.post(this::refitGlass);
        });

        // Keep the glass glued to its tile while the grid scrolls.
        grid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                if (!glassShown) return;
                glassTargetY -= dy;
                glassScrollShift -= dy;
                glass.setTranslationY(glass.getTranslationY() - dy);
                // single_row scrolls sideways: the same bookkeeping on the other axis.
                if (dx != 0) {
                    glassTargetX -= dx;
                    glassScrollShiftX -= dx;
                    glass.setTranslationX(glass.getTranslationX() - dx);
                }
            }
        });

        // game_day: the panel above the dock rides up with the cards instead of being covered by them, and fades
        // out by the time it reaches the clock. The grid's own offset is read, so a jump (Home, a restored focus)
        // lands right too.
        if (gameDay != null) {
            View clockBlock = findViewById(R.id.leftBlock);
            grid.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                    int shift = rv.canScrollVertically(-1) ? rv.computeVerticalScrollOffset() : 0;
                    racePanel.setTranslationY(-shift);
                    int room = Math.max(1, racePanel.getTop() - clockBlock.getBottom());
                    racePanel.setAlpha(Math.max(0f, 1f - shift / (float) room));
                }
            });
        }

        // Liquid feel: soft springs on the highlight's position.
        springX = new SpringAnimation(glass, new FloatPropertyCompat<View>("glassContentX") {
            @Override
            public float getValue(View v) {
                return v.getTranslationX() - glassScrollShiftX;
            }

            @Override
            public void setValue(View v, float value) {
                v.setTranslationX(value + glassScrollShiftX);
            }
        });
        springY = new SpringAnimation(glass, new FloatPropertyCompat<View>("glassContentY") {
            @Override
            public float getValue(View v) {
                return v.getTranslationY() - glassScrollShift;
            }

            @Override
            public void setValue(View v, float value) {
                v.setTranslationY(value + glassScrollShift);
            }
        });
        for (SpringAnimation s : new SpringAnimation[]{springX, springY}) {
            if (reducedMotion) {
                Motion.reduce(s);
            } else if (!focusOvershoot) {
                // Critically damped: glides straight onto the tile without swinging past it.
                s.setSpring(new SpringForce().setStiffness(advancedEffects ? 520f : 440f).setDampingRatio(1f));
            } else {
                s.setSpring(new SpringForce().setStiffness(advancedEffects ? 320f : 260f)
                        .setDampingRatio(advancedEffects ? 0.76f : 0.58f));
            }
        }

        btnInputs = findViewById(R.id.btnInputs);
        View btnSettings = findViewById(R.id.btnSettings);
        btnInputs.setOnClickListener(v -> showInputs());
        btnWifi.setOnClickListener(v -> openNetworkPill());
        btnVpn.setOnClickListener(v -> openVpnPill());
        btnWifi.setOnLongClickListener(v -> {
            open(systemIntent(Settings.ACTION_WIFI_SETTINGS));
            return true;
        });
        launcherSettingsButton = cfg.launcherSettingsButton;
        if (launcherSettingsButton) {
            ((TextView) btnSettings).setText(R.string.launcher_settings);
            ((TextView) btnSettings).setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_home_settings_pill, 0, 0, 0);
        }
        btnSettings.setOnClickListener(v -> {
            if (getResources().getBoolean(R.bool.gear_two_menu)) showGearMenu();
            else if (launcherSettingsButton) startActivityForResult(
                    new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST);
            else open(systemIntent(Settings.ACTION_SETTINGS));
        });
        btnReorder = findViewById(R.id.btnReorder);
        btnReorder.setOnClickListener(v -> toggleReorder());
        btnReorder.setVisibility(cfg.reorderButton ? View.VISIBLE : View.GONE);
        if (!cfg.showNetworkPill) btnWifi.setVisibility(View.GONE);
        showInputsPill = cfg.showInputsPill;
        showInputsMenuRow = cfg.showInputsPill;
        btnLibraryTop = findViewById(R.id.btnLibraryTop);
        btnLibraryTop.setOnClickListener(v -> showControlPanel());
        btnLibraryTop.setVisibility(cfg.libraryButton && cfg.appLibrary ? View.VISIBLE : View.GONE);
        addTopBarApps(cfg.topBarApps, cfg.launchActions);
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalFocusChangeListener((o, n) -> { if (n != null && insideTopBar(n)) showTopBar(); });
        setupMediaPill();
        iconOnlyButtons = cfg.iconOnlyButtons;
        topMenu = cfg.topMenu;
        wifiIconOnly = iconOnlyButtons && cfg.wifiLabelWidth <= 0;
        if (cfg.wifiStatusColor) {
            wifiPlainTint = btnWifi.getCompoundDrawableTintList();
            wifiOnlineTint = wifiPlainTint != null ? wifiPlainTint : getColorStateList(R.color.pill_icon_online);
            if (cfg.wifiStatusWarnings) {
                wifiNoInternetTint = getColorStateList(R.color.pill_icon_no_internet);
                wifiOfflineTint = getColorStateList(R.color.pill_icon_offline);
            }
        }
        if (cfg.topMenu) {
            // One gear: Inputs and Wi-Fi move into its dropdown. The Wi-Fi pill stays hidden but keeps its
            // label up to date, which the menu's Wi-Fi row shows.
            showInputsPill = false;
            btnInputs.setVisibility(View.GONE);
            btnWifi.setVisibility(View.GONE);
            ((TextView) btnSettings).setText(R.string.settings);
            ((TextView) btnSettings).setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_settings, 0, 0, 0);
            if (!iconOnlyButtons) makeIconOnly((TextView) btnSettings);
            btnSettings.setOnClickListener(v -> showTopMenu());
            // The lone gear sits at the header's middle, not on its bottom line like the row of pills.
            LinearLayout topButtons = findViewById(R.id.topButtons);
            RelativeLayout.LayoutParams tlp = (RelativeLayout.LayoutParams) topButtons.getLayoutParams();
            tlp.addRule(RelativeLayout.ALIGN_TOP, R.id.leftBlock);
            tlp.bottomMargin = 0;
            topButtons.setLayoutParams(tlp);
            topButtons.setGravity(Gravity.CENTER_VERTICAL);
        }
        if (iconOnlyButtons) {
            if (cfg.wifiLabelWidth > 0) btnWifi.setMaxWidth(Math.round(cfg.wifiLabelWidth * density));
            else makeIconOnly(btnWifi);
            makeIconOnly((TextView) btnSettings);
        }
        if (cfg.iconOnlyInputs) makeIconOnly((TextView) btnInputs);
        iconOnlyVpn = vpnPill && cfg.iconOnlyVpn;
        if (iconOnlyVpn) {
            vpnPlainBackground = btnVpn.getBackground().getConstantState();
            vpnPlainInk = btnVpn.getCompoundDrawableTintList();
            makeIconOnly(btnVpn);
        }
        btnSettings.setOnLongClickListener(v -> {
            showSettingsMenu();
            return true;
        });

        // Keep focus on the top bar at its ends and at the top: Android's focus finder would otherwise
        // jump to a tile far below when there is nothing in that direction.
        boolean rtlMenuBar = getResources().getBoolean(R.bool.rtl_menu_bar);
        View.OnKeyListener pillKeys = (v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return true;
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                // Back to the dock tile Up came from, not wherever the focus finder lands.
                focusTile(singleRow ? lastFocused : lastFocused % COLUMNS);
                return true;
            }
            int firstButton = btnInputs.getVisibility() == View.VISIBLE ? R.id.btnInputs : firstTopButton().getId();
            int leftButton = rtlMenuBar ? R.id.btnSettings : firstButton;
            int rightButton = rtlMenuBar ? firstButton : R.id.btnSettings;
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) return v.getId() == leftButton;
            return keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && v.getId() == rightButton;
        };
        btnInputs.setOnKeyListener(pillKeys);
        btnWifi.setOnKeyListener(pillKeys);
        btnVpn.setOnKeyListener(pillKeys);
        btnSettings.setOnKeyListener(pillKeys);
        btnReorder.setOnKeyListener(pillKeys);
        btnLibraryTop.setOnKeyListener(pillKeys);
        for (View button : topAppButtons) button.setOnKeyListener(pillKeys);
        if (advancedEffects) {
            List<View> pills = new ArrayList<>(Arrays.asList(btnInputs, btnWifi, btnVpn, btnReorder, btnLibraryTop, btnSettings));
            pills.addAll(topAppButtons);
            for (View button : pills) {
                button.setOnFocusChangeListener((view, focused) -> view.animate()
                        .scaleX(focused ? 1.04f : 1f).scaleY(focused ? 1.04f : 1f)
                        .setDuration(reducedMotion ? Motion.REDUCED_MS : 160).start());
            }
        }
        if (festive) applyFestiveSkin((TextView) btnInputs, (TextView) btnSettings);

        // Hide the glass when focus leaves the tiles.
        // Taken off in onDestroy: recreate() keeps the window, and a listener left on it held every earlier Home.
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalFocusChangeListener(glassFocusListener);

        packageFilter.addAction(Intent.ACTION_PACKAGE_ADDED);
        packageFilter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        packageFilter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        packageFilter.addDataScheme("package");
        timeFilter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        // Registered for the activity's whole life, not only while it is started: an app installed or updated while
        // another app is in front must still mark the tiles stale, or Home would have to rebuild on every return.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(packageReceiver, packageFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(packageReceiver, packageFilter);
        }
        if (openOnStartOnWake) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(wakeReceiver, new IntentFilter(Intent.ACTION_SCREEN_ON), Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(wakeReceiver, new IntentFilter(Intent.ACTION_SCREEN_ON));
            }
        }

        // From the application, not this activity: on Android 12 a ConnectivityManager keeps the context it was
        // made with (its static sInstance, and the callback Messenger the system holds), so every recreate() left
        // the previous Home and its bitmaps behind.
        ConnectivityManager cm = getApplicationContext().getSystemService(ConnectivityManager.class);
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (tim != null) tim.registerCallback(inputCallback, handler);
        if (cm != null) {
            cm.registerDefaultNetworkCallback(networkCallback);
            cm.registerNetworkCallback(new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(), vpnCallback);
        }
        // Not after recreate(): the launch intent survives it and would open the settings again.
        if (savedInstanceState == null && !openLauncherSettingsIfAsked(getIntent()) && !openLibraryIfAsked(getIntent())) {
            openInputsIfAsked(getIntent());
        }
    }

    /**
     * handle_view_inputs: switch InputsRequestActivity, the VIEW_INPUTS handler, on or off. It is disabled in the
     * manifest, so a TV with its own input picker never sees it; only the sets that need it turn it on. Written
     * only when the state differs, so an ordinary start does not touch the package manager.
     */
    private void applyViewInputsHandler(boolean on) {
        ComponentName handler = new ComponentName(this, InputsRequestActivity.class);
        PackageManager pm = getPackageManager();
        int want = on ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DEFAULT;
        if (pm.getComponentEnabledSetting(handler) != want) {
            pm.setComponentEnabledSetting(handler, want, PackageManager.DONT_KILL_APP);
        }
    }

    /**
     * VIEW_INPUTS, forwarded by InputsRequestActivity while handle_view_inputs is on: open the Inputs menu once
     * the pill is on screen. The intent is replaced so a later recreate() does not
     * open it again. Nothing to do when the TV has no inputs to list (the pill is hidden then).
     * top_menu hides the pill, so the list hangs under the gear there, as in showInputs().
     */
    private boolean openInputsIfAsked(Intent intent) {
        if (intent == null || !ACTION_VIEW_INPUTS.equals(intent.getAction())) return false;
        setIntent(new Intent(Intent.ACTION_MAIN));
        View anchor = topMenu || !showInputsPill ? findViewById(R.id.btnSettings) : btnInputs;
        if (anchor.getVisibility() != View.VISIBLE || !tvHasInputs()) return true;
        if (anchor.isLaidOut()) {
            // Android 9 delivers a new intent to a paused activity with a brief resume and pause around it, and
            // onPause() closes popups, so open the menu once that has run (HiSmartTV A4, Android TV 9).
            anchor.post(() -> {
                if (isFinishing() || anchor.getVisibility() != View.VISIBLE) return;
                anchor.requestFocus();
                showInputs();
            });
            return true;
        }
        // Cold start: the popup anchors to the pill (or the gear), so wait for the first layout.
        anchor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                anchor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                anchor.post(() -> {
                    if (isFinishing() || anchor.getVisibility() != View.VISIBLE) return;
                    anchor.requestFocus();
                    showInputs();
                });
            }
        });
        return true;
    }

    /**
     * ACTION_APP_LIBRARY, sent by the "library" action word: open the App library once Home is on screen. The intent
     * is replaced so a later recreate() does not open it again. With app_library off there is no library, so the
     * press only brings Home forward.
     */
    private boolean openLibraryIfAsked(Intent intent) {
        if (intent == null || !ACTION_APP_LIBRARY.equals(intent.getAction())) return false;
        setIntent(new Intent(Intent.ACTION_MAIN));
        if (!appLibraryEnabled) return true;
        getWindow().getDecorView().post(() -> {
            if (!isFinishing() && !isDestroyed()) onLibraryRequested();
        });
        return true;
    }

    private boolean openLauncherSettingsIfAsked(Intent intent) {
        if (intent == null || !ACTION_LAUNCHER_SETTINGS.equals(intent.getAction())) return false;
        setIntent(new Intent(Intent.ACTION_MAIN));
        startActivityForResult(new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST);
        return true;
    }

    /**
     * Home pressed while Home is already in front: singleTask delivers it here, then onResume runs.
     * Back to the top with the first dock tile focused, like the stock launcher. Back from an app
     * never comes this way, so returning to the app you left from is unchanged (#118).
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (openLauncherSettingsIfAsked(intent)) return;
        if (openLibraryIfAsked(intent)) return;
        if (openInputsIfAsked(intent)) return;
        if (intent == null || !intent.hasCategory(Intent.CATEGORY_HOME)) return;
        if (gameDay != null && !stopped) gameDay.read();
        grid.scrollToPosition(0);
        lastFocused = 0;
        lastFocusedKey = adapter.getItemCount() > 0 ? adapter.keyAt(0) : null;
        if (stopped) {
            tileRefresh.onHomeAgain();
        } else {
            // Still on screen (the quick panel was over it, or Home was already in front): the tiles are current,
            // so only go back to the first one; rebuilding would replay the entrance animation for nothing.
            grid.post(() -> focusTile(0));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        stopped = false;
        started = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(timeReceiver, timeFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(timeReceiver, timeFilter);
        }
        IntentFilter bluetoothFilter = new IntentFilter(android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED);
        bluetoothFilter.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED);
        bluetoothFilter.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(bluetoothReceiver, bluetoothFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(bluetoothReceiver, bluetoothFilter);
        }
        updateWifiLabel();
        updateClockVisibility();
        clockRefresh.start();   // with timeReceiver: while Home is visible, paused or not
        tileRefresh.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        askLocationOnce();
        applySafeMargin();
        applyNight();
        if (ambientMode) exitAmbientMode();
        if (mediaPillView != null) applyPillAccent(mediaPillView);
        topHideMs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getInt("topbar_hide_s", 6) * 1000L;
        showTopBar();
        if (nowPlaying != null) nowPlaying.start();
        if (mediaTick != null) {
            mediaPillView.removeCallbacks(mediaTick);
            mediaPillView.post(mediaTick);
        }
        // A festival that started or ended while Home was in the background: rebuild with or without it.
        if (festive != festival.active(LocalDate.now())) {
            recreate();
            return;
        }
        // Something changed in Launcher settings: rebuild with it, however the settings were left. Only Back
        // delivered their RESULT_OK; Home (the remote's button) clears them off this task and the result comes
        // back cancelled, so a new wallpaper or layout waited for the next process start.
        if (Config.settingsChanged(settingsRevision, settingsRevision())) {
            recreate();
            return;
        }
        restartIdleClock();
        promptsPaused = false;
        if (grid.getAdapter() == null) grid.setAdapter(adapter);   // dropped by onTrimMemory
        switch (tileRefresh.onResume(packagesChangedSinceRebuild())) {
            case REBUILD:
                tilesReady = false;
                reloadApps(true);
                break;
            case REFOCUS:
                // The same tiles: only the focus goes back, as after a rebuild, without replaying the entrance.
                tilesReady = false;
                reloadApps(true, false, false);
                break;
            default:
                break;
        }
        if (openLiveTvAfterBoot()) return;
        updateGreeting();
        updatePanel();
        // Back from an app opened from its tile, focus is still on that tile, so the cinematic "Last opened" line kept
        // the time from before this launch ("2 days ago" right after opening it). Refresh it.
        if (cinematic && heroMeta != null && lastFocused >= 0 && lastFocused < adapter.appCount()) updateHeroMeta(lastFocused);
        // The network and Inputs pills keep their state while Home is in the background, and callbacks update them
        // when the network or the inputs change, so this refresh only catches anything missed. Its binder calls
        // (about 7 ms on a TCL C755, most of it WifiManager.getConnectionInfo) would hold up the first frame back
        // on Home, so after the first resume it runs once that frame is drawn.
        if (pillsShown) {
            refreshPillsAfterNextDraw();
        } else {
            updateWifiLabel();
            updateInputsButton();
            pillsShown = true;
        }
        if (showStats) startStats();
        if (gameDay != null) gameDay.start();
        sky.update();
        wallpaperPlayer.start();
        videoWallpaper.start();
        handler.postDelayed(minuteTick, MINUTE_MS);
        if (festive && lamp != null) {
            lamp.start();
            LocalDate today = LocalDate.now();
            if (!reducedMotion && !today.equals(lastPetalShower)) {
                lastPetalShower = today;
                handler.postDelayed(this::playPetalShower, 450);
            }
        }
    }

    /** Launcher settings' change count (Config.SETTINGS_REVISION_KEY); onResume rebuilds Home when it moved. */
    private long settingsRevision() {
        return getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getLong(Config.SETTINGS_REVISION_KEY, 0);
    }

    /**
     * Only "Reorder tiles" in Launcher settings still answers with a result: Home rebuilds (the saved choices are
     * reloaded) and then enters reorder mode. Every other change is picked up in onResume through the change count.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LAUNCHER_SETTINGS_REQUEST && resultCode == RESULT_OK
                && data != null && data.getBooleanExtra(LauncherSettingsActivity.EXTRA_REORDER, false)) {
            getIntent().putExtra(LauncherSettingsActivity.EXTRA_REORDER, true);
            // The old activity must not consume the pending action, or rebuild a second time in onResume.
            settingsRecreationPending = true;
            settingsRevision = settingsRevision();
            recreate();
        }
    }

    private void startPendingSettingsReorder() {
        if (settingsRecreationPending || !tilesReady || !hasWindowFocus() || isFinishing()
                || !getIntent().getBooleanExtra(LauncherSettingsActivity.EXTRA_REORDER, false)) return;
        getIntent().removeExtra(LauncherSettingsActivity.EXTRA_REORDER);
        toggleReorder();
    }

    /** Rebuilds the tiles (and the module cards), then puts focus back where it was. */
    private void reloadApps(boolean animate) {
        reloadApps(animate, true);
    }

    /** @param rebuild false keeps the tiles as they are and only puts focus back (TileRefresh.Action.REFOCUS). */
    private void reloadApps(boolean animate, boolean rebuild) {
        reloadApps(animate, rebuild, true);
    }

    /**
     * @param entrance false puts focus back as an animated reload would, without replaying the tiles' entrance:
     *                 on a return to the same tiles it would only mark a change that didn't happen.
     */
    private void reloadApps(boolean animate, boolean rebuild, boolean entrance) {
        cancelPendingFocusScroll();
        RecyclerView.ViewHolder footer = grid.findViewHolderForAdapterPosition(adapter.appCount());
        final boolean restoreLibrary = adapter.isLibraryAt(adapter.appCount()) && footer != null
                && footer.itemView.findViewById(R.id.btnLibrary) != null
                && footer.itemView.findViewById(R.id.btnLibrary).hasFocus();
        // Capture the app before rebinding can move focus and overwrite its key.
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        final boolean restoreFocus = appLibrary == null && (animate || grid.hasFocus());
        if (restoreFocus) {
            glassShown = false;
            glass.setAlpha(0f);
            heroShown = false;
            hero.setAlpha(0f);
            ambient.setAlpha(0f);
            heroArt.animate().cancel();
            heroArt.setAlpha(0f);
        }
        if (rebuild) reloadTiles();
        if (animate && entrance && animations && !reducedMotion) {
            grid.scheduleLayoutAnimation();
            // A rebuild redraws the grid anyway; without one the entrance needs a draw to start.
            if (!rebuild) grid.invalidate();
        }

        if (restoreFocus) {
            // Keep a focused footer at the end even when the app count changes.
            if (restoreLibrary) grid.post(this::focusLibrary);
            else restoreFocus();
        } else {
            // A package change must not steal focus from a top button or the Inputs popup.
            int pos = adapter.positionOf(returnKey);
            lastFocused = Math.max(0, Math.min(pos >= 0 ? pos : returnSlot, adapter.appCount() - 1));
            lastFocusedKey = adapter.keyAt(lastFocused);
            if (pos < 0) hideHero();
            // A newly installed app may have brought a card with it.
            tilesReady = true;
            startPendingSettingsReorder();
            showCardPrompt();
        }
    }

    /** True when PackageManager reports apps changed since the last rebuild (one binder call). */
    private boolean packagesChangedSinceRebuild() {
        ChangedPackages changed = getPackageManager().getChangedPackages(packageSequence);
        return changed != null && !changed.getPackageNames().isEmpty();
    }

    private int currentPackageSequence(int since) {
        ChangedPackages changed = getPackageManager().getChangedPackages(since);
        return changed != null ? changed.getSequenceNumber() : since;
    }

    /**
     * Rebuilds the tiles; the module cards the owner chose to show stand in for their app's tile.
     * Every step into the card code runs under CardFeature: if it fails, the tiles are the ordinary
     * ones and cards stay off for this process.
     */
    private void reloadTiles() {
        if (reordering) endReorder();   // an app installed or removed while reordering: keep the order so far
        // Read these before reload(): rebinding can move focus to the first tile and overwrite them.
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        final List<Cards.Card> none = Collections.emptyList();
        // An updated app may bring new artwork; the backdrop is cheap to make again.
        heroArtCache.clear();
        heroArtKey = null;
        // One LEANBACK query for both the tiles and the card checks.
        final List<ResolveInfo> leanback = getPackageManager().queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0);
        cards = moduleCards ? CardFeature.run(() -> Cards.discover(this, hiddenApps,
                () -> Cards.load(Cards.storeFile(this)), leanback), none) : none;
        adapter.reload(cards.isEmpty() ? none : CardFeature.run(() -> Cards.shown(cards), none), leanback);
        lastFocusedKey = returnKey;
        lastFocused = returnSlot;
        packageSequence = currentPackageSequence(packageSequence);
    }

    /**
     * Return to the app we left from, or the same slot if that app is gone. Always refocus: after
     * reload() the view that holds focus may no longer show the app it had.
     */
    private void restoreFocus() {
        final boolean returnToLibrary = libraryFocusPending;
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        grid.post(() -> {
            int pos = adapter.positionOf(returnKey);
            if (returnToLibrary || libraryFocusPending) focusLibrary();
            else focusTile(pos >= 0 ? pos : returnSlot);
            tilesReady = true;
            startPendingSettingsReorder();
            showCardPrompt();
        });
    }

    /** Any key on Home restarts the countdown to the idle clock. */
    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        restartIdleClock();
        armTopBarHide();
    }

    // ---- top bar that hides itself -------------------------------------------------------------------

    private long topHideMs = 6000;   // 0 = the bar stays; set in Settings
    private final Rect topBarRect = new Rect();
    private boolean topBarHidden;
    private final Runnable hideTopBar = new Runnable() {
        @Override public void run() {
            View bar = findViewById(R.id.topButtons);
            if (bar == null || !resumed) return;
            if (insideTopBar(getCurrentFocus()) || reordering || openPopup != null || appLibrary != null || !hasWindowFocus()) {
                armTopBarHide();
                return;
            }
            topBarHidden = true;
            bar.animate().alpha(0f).setDuration(reducedMotion ? 0 : 300).start();
        }
    };

    /** A touch or air-mouse click on the faded bar only brings it back; it never presses a hidden button. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ambientMode) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) exitAmbientMode();
            return true;
        }
        if (topBarHidden) {
            View bar = findViewById(R.id.topButtons);
            boolean onBar = bar != null && bar.getGlobalVisibleRect(topBarRect)
                    && topBarRect.contains((int) ev.getRawX(), (int) ev.getRawY());
            showTopBar();
            if (onBar) return true;
        }
        return super.dispatchTouchEvent(ev);
    }

    private boolean insideTopBar(View v) {
        View bar = findViewById(R.id.topButtons);
        if (v == null) return false;
        if (v == bar) return true;
        for (android.view.ViewParent p = v.getParent(); p != null; p = p.getParent()) if (p == bar) return true;
        return false;
    }

    private void armTopBarHide() {
        root.removeCallbacks(hideTopBar);
        if (topHideMs > 0) root.postDelayed(hideTopBar, topHideMs);
    }

    /** The pills fade out after a few quiet seconds; focus reaching them (Up from the dock) brings them back. */
    private void showTopBar() {
        View bar = findViewById(R.id.topButtons);
        if (bar != null && topBarHidden) {
            topBarHidden = false;
            bar.animate().alpha(1f).setDuration(reducedMotion ? 0 : 200).start();
        }
        armTopBarHide();
    }

    private void restartIdleClock() {
        root.removeCallbacks(showIdleClock);
        if (musicModeOpen) return;   // music mode keeps the screen: no screensaver while it is open
        if (resumed && idleClockMs > 0) root.postDelayed(showIdleClock, idleClockMs);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        if (nowPlaying != null) nowPlaying.stop();
        if (mediaTick != null) mediaPillView.removeCallbacks(mediaTick);
        // No UP reaches a paused Home, so a vendor-key hold it saw go down would still open its app later.
        // Only Home's own share is dropped: a key service that saw the same DOWN keeps its hold.
        RemoteKeys.release(this);
        cancelHoldOk();
        root.removeCallbacks(showIdleClock);
        endReorder();   // Home or another app while reordering keeps the order so far
        wallpaperPlayer.stop();
        videoWallpaper.stop();
        stopAmbientAnimation();
        hero.animate().cancel();
        ambient.animate().cancel();
        heroArt.animate().cancel();
        handler.removeCallbacks(minuteTick);
        handler.removeCallbacks(openWhenOnline);
        startPending = null;   // leaving Home before the network came back: the boot's app stays closed
        stopStats();
        if (gameDay != null) gameDay.stop();
        handler.removeCallbacks(turnTick);
        if (lamp != null) lamp.stop();
        cancelPendingFocusScroll();
        // Nothing of ours stays on screen over another app; an undecided prompt simply returns next time.
        if (cardPrompt != null) cardPrompt.dismiss();
        if (appLibrary != null) appLibrary.close();
        if (openPopup != null) openPopup.dismiss();
    }

    @Override
    protected void onStop() {
        super.onStop();
        started = false;
        unregisterReceiver(timeReceiver);
        unregisterReceiver(bluetoothReceiver);
        clockRefresh.stop();
        handler.removeCallbacks(clockCheck);
        stopped = true;
        tileRefresh.onStop();
    }

    /**
     * Another app needs the memory while Home is in the background: let go of every tile's artwork, and
     * rebuild it when Home comes back. Not at UI_HIDDEN, the ordinary trip to an app, where keeping the
     * tiles is what makes the return instant.
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // RUNNING_LOW and CRITICAL also arrive while Home is visible when an accessibility service keeps the
        // process in the foreground; never blank the screen the owner is looking at.
        if (!MemoryTrimPolicy.shouldRelease(level, started)) return;
        adapter.clear();
        // Detach the adapter too: with Home stopped no layout pass runs, so the tile views (and the bitmaps
        // they hold) would stay attached until Home comes back. setAdapter(null) recycles them now.
        grid.setAdapter(null);
        grid.getRecycledViewPool().clear();
        heroArtCache.clear();
        heroArtKey = null;
        wallpaperPlayer.releaseForMemoryPressure();
        tileRefresh.invalidate();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            startPendingSettingsReorder();
            if (libraryFocusPending && appLibrary == null) focusLibrary();
            showCardPrompt();
        } else {
            cancelHoldOk();   // a dialog or another window took the remote while OK was held
        }
    }

    /** Hides the glass when focus leaves the tiles (added in onCreate, removed in onDestroy). */
    private final ViewTreeObserver.OnGlobalFocusChangeListener glassFocusListener = (oldF, newF) -> {
        boolean onTile = newF != null && newF.getId() == R.id.card;
        if (!onTile) hideGlass();
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ViewTreeObserver tree = getWindow().getDecorView().getViewTreeObserver();
        if (tree.isAlive()) tree.removeOnGlobalFocusChangeListener(glassFocusListener);
        if (liquid != null) {
            root.getViewTreeObserver().removeOnPreDrawListener(liquidPreDraw);
            liquid.clear();
            liquid = null;
        }
        RemoteKeys.release(this);
        cancelHoldOk();
        if (gameDay != null) gameDay.shutdown();
        unregisterReceiver(packageReceiver);
        if (openOnStartOnWake) unregisterReceiver(wakeReceiver);
        wallpaperPlayer.close();
        videoWallpaper.close();
        ConnectivityManager cm = getApplicationContext().getSystemService(ConnectivityManager.class);   // as registered
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (tim != null) tim.unregisterCallback(inputCallback);
        if (cm != null) {
            cm.unregisterNetworkCallback(networkCallback);
            cm.unregisterNetworkCallback(vpnCallback);
        }
    }

    /**
     * A Settings button sent as a keycode (settings_key_keycodes, e.g. 83 on TCL Google TV remotes) opens the same
     * thing HomeKeyService would. While that service runs it consumes the key first; without it (not enabled,
     * or switched off by a force-stop) the stock launcher that used to handle the key is gone, and the button did
     * nothing even on Home.
     */
    private boolean handleSettingsKey(KeyEvent event) {
        for (int code : settingsKeycodes) {
            if (event.getKeyCode() != code) continue;
            if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) {
                Intent settings = settingsKeyPanel ? new Intent(this, QuickSettingsActivity.class)
                        : systemIntent(Settings.ACTION_SETTINGS);
                // settings_key_clear_task, as in HomeKeyService: Back from Settings goes Home, not to a vendor page.
                if (settingsKeyClearTask && !settingsKeyPanel) settings.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                open(settings);
            }
            return true;
        }
        return false;
    }

    // ---- reorder ---------------------------------------------------------------------------------

    /** Blue the glass turns while reorder mode is on. */
    private static final int REORDER_ACCENT = 0xFF6EC1FF;

    /**
     * Reorder mode (top-bar button). While it is on, every key comes here first:
     * - nothing carried: arrows move focus as usual; OK on a tile picks it up instead of opening the app;
     *   Back ends the mode and saves the order.
     * - a tile carried: arrows move it; Back (or OK) puts it down and the mode stays on for the next one.
     * Other keys (volume, Home) pass through; leaving the launcher ends the mode and saves.
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // Ambient mode shows only the wallpaper: any key but volume and media keys brings the interface back.
        if (ambientMode && !HomeKeyService.keepsAudioOnly(event.getKeyCode())) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) exitAmbientMode();
            return true;
        }
        if (homeIgnoreChannelKeys && RemoteKeys.isChannelKey(event.getKeyCode())) return true;
        // Vendor keys (TCL Netflix button, 4062) never reach the key services, only the focused window, so their
        // "hold:" entries run here too or nowhere. Only while resumed: onPause releases Home's holds, and a DOWN
        // taken after that would arm one nothing releases.
        if (resumed && event.getKeyCode() >= 1000 && RemoteKeys.handle(this, event, homeAppKeys.get(event.getKeyCode()),
                homeHoldAppKeys.get(event.getKeyCode()))) return true;
        if (handleSettingsKey(event)) return true;
        if (holdOk(event)) return true;
        if (tileMenuEnabled && !reordering && openPopup == null && cardPrompt == null
                && event.getKeyCode() == KeyEvent.KEYCODE_MENU) {
            int position = focusedTilePosition();
            if (position >= 0 && position < adapter.appCount()
                    && !getPackageName().equals(adapter.packageAt(position))) {
                if (RemoteKeys.menuReleased(event.getAction(), event.getFlags())) {
                    onTileLongPress(position, getCurrentFocus());
                }
                return true;
            }
        }
        if (!reordering && resumed && openPopup == null && cardPrompt == null && appLibrary == null && colorKeys(event)) return true;
        if (!reordering) return super.dispatchKeyEvent(event);
        if (dockEditing) return dispatchDockEdit(event);
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        int code = event.getKeyCode();
        boolean ok = code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        boolean back = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE;
        if (movingKey != null) {
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    if (down) moveBy(code);
                    return true;
                default:
                    if (ok || back) {
                        if (!down) drop();
                        return true;
                    }
                    return super.dispatchKeyEvent(event);
            }
        }
        if (back) {
            if (!down) endReorder();
            return true;
        }
        int pos = focusedTilePosition();
        View focus = getCurrentFocus();
        if (ok && focus != null && focus.getId() == R.id.btnLibrary) {
            // The App library pill sits in the grid but is no tile: OK ends the mode (saving the order) and opens it.
            if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) {
                endReorder();
                onLibraryRequested();
            }
            return true;
        }
        if (ok && grid.hasFocus()) {
            // RecyclerView can briefly report NO_POSITION during a move or rebind. Still consume
            // OK on the grid: falling through would let the focused card open its app in reorder mode.
            if (!down && pos >= 0) pickUp(pos);
            return true;
        }
        return super.dispatchKeyEvent(event);   // arrows navigate; OK on a top-bar pill works as usual
    }

    /** Adapter position of the focused tile, or -1 when focus is not on a tile. */
    private int focusedTilePosition() {
        View f = getCurrentFocus();
        if (f == null || f.getId() != R.id.card || !(f.getParent() instanceof View)) return -1;
        return grid.getChildAdapterPosition((View) f.getParent());
    }

    /** The reorder button: turns the mode on (focus goes back to the last tile), or off again. */
    private void toggleReorder() {
        if (reordering) {
            endReorder();
            return;
        }
        if (!beginReorder()) return;
        focusTile(Math.max(0, Math.min(lastFocused, adapter.movableCount() - 1)));
        Toast.makeText(this, R.string.reorder_hint, Toast.LENGTH_LONG).show();
    }

    /** The start shared by reorder and edit-dock mode. False when there is nothing to move. */
    private boolean beginReorder() {
        if (adapter.movableCount() < 2) return false;
        // Before the reload below: once it has dropped the empty slots, the dock row also shows grid apps.
        dockInSession = new HashSet<>();
        dockedAtStart = adapter.dockFilled();
        for (int i = 0; i < Math.min(dockedAtStart, adapter.movableCount()); i++) dockInSession.add(adapter.keyAt(i));
        adapter.setReordering(true);
        if (adapter.hasEmptySlots()) reloadTiles();   // every position must hold a tile that can move
        reordering = true;
        orderAtStart = adapter.movableKeys();
        glass.setAccent(REORDER_ACCENT);
        btnReorder.setActivated(true);
        return true;
    }

    /** Edit dock (Settings menu): focus goes to the first dock place, which OK then chooses. */
    private void startDockEdit() {
        if (reordering) endReorder();
        if (!beginReorder()) return;
        dockEditing = true;
        dockEditSlot = -1;
        focusTile(0);
        Toast.makeText(this, R.string.dock_edit_hint, Toast.LENGTH_LONG).show();
    }

    /**
     * Keys in edit-dock mode. First OK on a dock tile chooses that place (the other dock tiles dim) and focus moves
     * to the grid; then OK on any tile swaps that app into the place, saves the order and ends the mode. Back goes
     * one step back: from choosing the app to choosing the place, and from there out of the mode.
     */
    private boolean dispatchDockEdit(KeyEvent event) {
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        int code = event.getKeyCode();
        boolean ok = code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        boolean back = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE;
        if (back) {
            if (!down) {
                if (dockEditAppKey != null) {
                    endReorder();   // "Add to dock" cancelled before a place was chosen
                } else if (dockEditSlot >= 0) {
                    int slot = dockEditSlot;
                    dockEditSlot = -1;
                    dimOthers();
                    focusTile(slot);
                } else {
                    endReorder();
                }
            }
            return true;
        }
        int pos = focusedTilePosition();
        if (ok && pos >= 0) {
            if (!down) {
                int n = adapter.movableCount();
                if (dockEditAppKey != null) {
                    if (pos < Math.min(COLUMNS, n)) {
                        int from = adapter.positionOf(dockEditAppKey);
                        if (from >= 0) swapIntoDock(pos, from);
                        else endReorder();
                    }
                } else if (dockEditSlot < 0) {
                    if (pos < Math.min(COLUMNS, n)) {
                        dockEditSlot = pos;
                        dimOthers();
                        focusTile(Math.min(COLUMNS, n - 1));
                        Toast.makeText(this, R.string.dock_edit_pick_app, Toast.LENGTH_LONG).show();
                    }
                } else if (pos < n) {
                    swapIntoDock(dockEditSlot, pos);
                }
            }
            return true;   // never opens the app while editing
        }
        return super.dispatchKeyEvent(event);   // arrows navigate as usual
    }

    /**
     * Edit-dock mode started from the tile menu. A dock app: its place is already chosen, so focus goes to the grid
     * for the app to put there. A grid app: it is already chosen, so focus goes to the dock for the place.
     */
    private void startDockEditFor(String key, boolean inDock) {
        if (reordering) endReorder();
        if (!beginReorder()) return;
        dockEditing = true;
        int pos = adapter.positionOf(key);   // beginReorder can rebuild the tiles
        int n = adapter.movableCount();
        if (pos < 0) {
            endReorder();
        } else if (inDock) {
            dockEditSlot = pos;
            dimOthers();
            focusTile(Math.min(COLUMNS, n - 1));
            Toast.makeText(this, R.string.dock_edit_pick_app, Toast.LENGTH_LONG).show();
        } else {
            dockEditAppKey = key;
            focusTile(0);
            Toast.makeText(this, R.string.dock_edit_pick_place, Toast.LENGTH_LONG).show();
        }
    }

    /** Puts the app at pos into dock place slot, and the app that was there where the chosen one was; then saves. */
    private void swapIntoDock(int slot, int pos) {
        String slotKey = adapter.keyAt(slot);
        if (pos != slot) {
            keepScroll(() -> {
                adapter.move(pos, slot);
                adapter.move(adapter.positionOf(slotKey), pos);
            });
            if (pos >= COLUMNS) dockInSession.remove(slotKey);
        }
        // Outside the check: with no empty slots shown, the chosen app may already sit in the free place.
        dockInSession.add(adapter.keyAt(slot));
        endReorder();
        refocusAfterLayout(slot);
    }

    private void pickUp(int pos) {
        if (pos >= adapter.movableCount()) return;   // the "Default home" tile stays put
        movingKey = adapter.keyAt(pos);
        dimOthers();
    }

    /** Puts the carried tile down where it is; the mode stays on. */
    private void drop() {
        movingKey = null;
        dimOthers();
    }

    /** Applies tileAlpha to every attached tile (carried tile bright; the rest dim while reordering). */
    private void dimOthers() {
        for (int i = 0; i < grid.getChildCount(); i++) {
            View item = grid.getChildAt(i);
            item.setAlpha(tileAlpha(grid.getChildAdapterPosition(item)));
        }
    }

    /** A tile's alpha: the carried tile stays bright; every other tile is dim while reordering, including after a
     * drop, until Back ends the mode. In edit-dock mode, dock tiles other than the chosen place are dimmed. */
    private float tileAlpha(int pos) {
        if (movingKey != null) {
            return pos != RecyclerView.NO_POSITION && movingKey.equals(adapter.keyAt(pos)) ? 1f : 0.45f;
        }
        if (dockEditSlot >= 0 && pos >= 0 && pos < COLUMNS && pos != dockEditSlot) return 0.45f;
        if (reordering) return 0.45f;
        return 1f;
    }

    /** Ends the mode and saves the order if it changed since the mode started. */
    private void endReorder() {
        if (!reordering) return;
        dockEditing = false;
        dockEditSlot = -1;
        dockEditAppKey = null;
        drop();
        reordering = false;
        dimOthers();   // drop() ran while reordering was still on; restore full brightness now the mode is off
        adapter.setReordering(false);
        glass.setAccent(festive ? festival.accentColor() : 0);
        btnReorder.setActivated(false);
        List<String> keys = adapter.movableKeys();
        List<String> before = orderAtStart;
        orderAtStart = null;
        // fill_dock false: the dock is what the owner put there, saved with its size, so the empty slots that
        // come back after the mode go after it (#499). With fill_dock true every dock slot holds an app anyway.
        int docked = -1;
        if (fillDockLeavesSlots) {
            docked = DockSlots.dockCount(keys, COLUMNS, dockInSession);
            keys = DockSlots.dockFirst(keys, COLUMNS, dockInSession);
        }
        dockInSession = null;
        if (!keys.equals(before) || (fillDockLeavesSlots && docked != dockedAtStart)) {
            Order order = new Order(Order.dockKey(dockApps), keys, docked);
            if (Order.save(Order.file(this), order)) {
                adapter.setSavedOrder(Order.ranks(order, dockApps), Order.docked(order, dockApps));
            } else {
                Toast.makeText(this, R.string.reorder_not_saved, Toast.LENGTH_SHORT).show();
            }
        }
        if (fillDockLeavesSlots) reloadTiles();   // the empty dock slots left out while reordering come back
    }

    /**
     * Moves the carried tile one step. Left and Right wrap across rows, like a list; Up and Down move a whole row,
     * and Down into a short last row lands on its last tile. Nothing moves past either end or up into the top bar.
     */
    private void moveBy(int keyCode) {
        int from = adapter.positionOf(movingKey);
        int n = adapter.movableCount();
        if (from < 0 || from >= n) {
            drop();
            return;
        }
        // A single row has no rows to move between: Up and Down leave the carried tile where it is.
        if (singleRow && (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN)) return;
        int to;
        // rtl_app_grid (Hebrew) mirrors the grid: position 0 is on the right, so Left moves towards the end.
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) to = rtlAppGrid ? from + 1 : from - 1;
        else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) to = rtlAppGrid ? from - 1 : from + 1;
        else if (keyCode == KeyEvent.KEYCODE_DPAD_UP) to = from - COLUMNS;
        else if (from + COLUMNS < n) to = from + COLUMNS;
        else to = from / COLUMNS < (n - 1) / COLUMNS ? n - 1 : from;
        if (to < 0 || to >= n || to == from) return;
        keepScroll(() -> adapter.move(from, to));
        // The owner carries this tile: where it lands decides whether it is in the dock, not dock_apps (#499).
        if (to < COLUMNS) dockInSession.add(movingKey);
        else dockInSession.remove(movingKey);
        refocusAfterLayout(to);
    }

    /**
     * Applies an adapter change without the grid jumping. After a move the layout manager anchors on the focused
     * tile, keeping it at its old place on screen and shifting every other row; pinning the first visible row at its
     * current offset as the next layout's anchor keeps the scroll where it was. onTileFocused still scrolls
     * afterwards if the moved tile itself ends up off screen.
     */
    private void keepScroll(Runnable change) {
        GridLayoutManager lm = (GridLayoutManager) grid.getLayoutManager();
        int first = lm.findFirstVisibleItemPosition();
        View firstView = first != RecyclerView.NO_POSITION ? lm.findViewByPosition(first) : null;
        // single_row scrolls sideways, so its first visible tile is pinned by its left edge instead; mirrored by
        // rtl_app_grid, the row is laid out from the right, and the offset counts from the right edge.
        int offset = firstView == null ? 0
                : singleRow && rtlAppGrid ? grid.getWidth() - grid.getPaddingRight() - lm.getDecoratedRight(firstView)
                : singleRow ? lm.getDecoratedLeft(firstView) - grid.getPaddingLeft()
                : lm.getDecoratedTop(firstView) - grid.getPaddingTop();
        change.run();
        if (firstView != null) lm.scrollToPositionWithOffset(first, offset);
    }

    /**
     * Once the grid has applied the change, put the glass (and focus, if the move dropped it) on the tile at pos.
     * The grid has a fixed size, so it applies adapter changes on the next animation frame rather than in a layout
     * pass; until then it cannot find the tile by position. Wait frame by frame (at most 10) for that. No focus
     * change fires for a moved tile, so focusTile's already-focused path calls onTileFocused itself.
     */
    private void refocusAfterLayout(int pos) {
        grid.postOnAnimation(new Runnable() {
            int frames;

            @Override
            public void run() {
                if ((grid.hasPendingAdapterUpdates() || grid.isLayoutRequested()) && ++frames < 10) {
                    grid.postOnAnimation(this);
                    return;
                }
                focusTile(pos);
                dimOthers();   // views that came into view or were rebound during the move
            }
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Home screen: Back goes nowhere, unless back_opens_clock is on.
        if (backOpensClock) enterAmbientMode();
    }

    // ---- glass highlight -------------------------------------------------------------------------

    @Override
    public void onLibraryRequested() {
        if (appLibrary != null) appLibrary.close();
        if (openPopup != null) openPopup.dismiss();
        libraryFocusPending = false;
        libraryFromTopBar = false;
        libraryFromVpnPill = false;
        appLibrary = new AppLibraryDialog(this, animations, reducedMotion, appLibrarySelection, libraryOkOpens, adapter::containsPackage, () -> reloadApps(false), () -> {
            appLibrary = null;
            openPopup = null;
            if (libraryFromTopBar) {
                libraryFromTopBar = false;
                btnLibraryTop.requestFocus();
                return;
            }
            boolean fromVpnPill = libraryFromVpnPill;
            libraryFromVpnPill = false;
            // The VPN pill can hide while the library is open (its VPN dropped): then focus goes as from the grid.
            if (fromVpnPill && btnVpn.getVisibility() == View.VISIBLE) {
                btnVpn.requestFocus();
                return;
            }
            libraryFocusPending = true;
            grid.post(() -> {
                if (libraryFocusPending && appLibrary == null && hasWindowFocus() && !isFinishing()) focusLibrary();
            });
        }, libraryExcludedApps);
        openPopup = appLibrary.popup;
        appLibrary.show();
    }

    @Override
    public void onTileFocused(int position, View card) {
        lastFocused = position;
        lastFocusedKey = adapter.keyAt(position);
        // Focus restored before the first layout (cold start): the tile has no size yet, and the glass
        // would be sized to 2*pad. Run again once the tile is laid out.
        if (card.getWidth() == 0) {
            card.post(() -> {
                if (card.isFocused() && card.getWidth() > 0) onTileFocused(position, card);
            });
            return;
        }
        // Tile rect in root coordinates, using layout positions (ignores the scale animation).
        Rect r = tileRect;
        r.set(0, 0, card.getWidth(), card.getHeight());
        root.offsetDescendantRectToMyCoords(card, r);
        tileFocusEffects(position, card, r);
        float pad = 6f * density;        // matches GlassView's glow inset
        float scale = adapter.focusScale();
        float w = card.getWidth() * scale + 2 * pad;
        float h = card.getHeight() * scale + 2 * pad;
        float x = r.exactCenterX() - w / 2f;
        // advanced_effects lifts a focused grid tile by 4dp and the glass follows it; dock tiles stay put (#2135).
        boolean lifted = advancedEffects && !DockSlots.inDockRow(dockRow, singleRow, position, COLUMNS);
        float y = r.exactCenterY() - h / 2f - (lifted ? 4f * density : 0f);

        ViewGroup.LayoutParams lp = glass.getLayoutParams();
        if (lp.width != (int) w || lp.height != (int) h || card.getWidth() != glassCardW) {
            lp.width = (int) w;
            lp.height = (int) h;
            glass.setLayoutParams(lp);
            // GlassView draws its slab inset by pad, i.e. exactly over the zoomed tile: same corners as the tile.
            glass.setRadius(AppAdapter.cornerRadius(card.getWidth(), density) * scale);
        }
        glassCardW = card.getWidth();
        glassCardRect.set(r);
        glassTargetX = x;
        glassTargetY = y;
        // Cinematic shelf: the highlight glows in the dock app's colour, plain white in the grid (and on the dock with
        // cinematic_white_focus). app_glow: every tile. In a single row every tile is the dock's kind.
        boolean coloured = (appGlow || cinematic && !cinematicWhiteFocus && (singleRow || position < COLUMNS)) && !festive;
        int accent = coloured ? adapter.ambientColorAt(position) : 0;
        if ((cinematic || appGlow) && !festive && accent != glassAccent) {
            glassAccent = accent;
            glass.setAccent(accent);
        }
        if (!glassShown) {
            springX.cancel();
            springY.cancel();
            glass.setTranslationX(x);
            glass.setTranslationY(y);
            if (animations && !reducedMotion) glass.animate().alpha(1f).setDuration(180).start();
            else glass.setAlpha(1f);
            glassShown = true;
        } else if (!animations) {
            springX.cancel();
            springY.cancel();
            glass.setTranslationX(x);
            glass.setTranslationY(y);
        } else {
            springX.animateToFinalPosition(x - glassScrollShiftX);
            springY.animateToFinalPosition(y - glassScrollShift);
        }
        View item = (View) card.getParent();
        if (dockRow && (singleRow || position < COLUMNS)) {
            // Dock: park it at the bottom of the screen and show the top shelf for this app. In a single row
            // every tile is in the dock's row, which never scrolls vertically.
            int decoratedTop = item.getTop() - (int) (6 * density);
            int dy = decoratedTop - grid.getPaddingTop();
            // A 1px mismatch used to start a scroll on every dock move. Only scroll when the row is
            // actually off; reduced motion does it in one jump so it does not fight the highlight.
            boolean scroll = !singleRow && Math.abs(dy) > (int) (8 * density);
            if (scroll) {
                if (!animations || reducedMotion) grid.scrollBy(0, dy);
                else grid.smoothScrollBy(0, dy);
            }
            float dockTop = scroll ? r.top - dy : r.top;
            showHero(position, dockTop);
        } else {
            // Below the dock (or in a plain grid) the glow follows the tile without the big name; letting it
            // fade out left the grid on plain black.
            showGlowOnly(position);
            // Scroll just enough so the whole glass (not only the tile) is visible.
            revealRect.set(0, -(int) pad * 2, item.getWidth(), item.getHeight() + (int) pad);
            grid.requestChildRectangleOnScreen(item, revealRect, reducedMotion);
        }
    }

    /** Refits the glass to the focused holder once the grid layout and tile dimensions settle. */
    private void refitGlass() {
        if (isDestroyed() || adapter.appCount() == 0 || libraryFocusPending) return;
        int pos = Math.max(0, Math.min(lastFocused, adapter.appCount() - 1));
        RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(pos);
        View card = vh == null ? null : vh.itemView.findViewById(R.id.card);
        if (card == null || card.getWidth() <= 0 || !card.isFocused()) return;
        float pad = 6f * density;
        float scale = adapter.focusScale();
        int w = (int) (card.getWidth() * scale + 2 * pad);
        int h = (int) (card.getHeight() * scale + 2 * pad);
        // The tile's rect, not only its width: the grid's top padding lands after the tile has its width, so a
        // cold start can leave the glass at the right size and the wrong place. Comparing the rect catches that.
        Rect r = tileRect;
        r.set(0, 0, card.getWidth(), card.getHeight());
        root.offsetDescendantRectToMyCoords(card, r);
        if (!glassShown || card.getWidth() != glassCardW || glass.getWidth() != w || glass.getHeight() != h
                || !glassCardRect.equals(r)) {
            onTileFocused(pos, card);
        }
    }

    // ---- top shelf -------------------------------------------------------------------------------

    private void showHero(int position, float dockTopInRoot) {
        String label = adapter.labelAt(position);
        int color = adapter.ambientColorAt(position);
        float y = dockTopInRoot - 14 * density - 26 * density - hero.getHeight();
        boolean changed = !label.contentEquals(heroName.getText());
        if (cinematic && heroArtAlpha > 0f) showHeroArt(position);

        if (!animations || reducedMotion) {
            // Snap the shelf instead of sliding and fading it: each of those frames repaints the
            // full-screen panel, and this switch exists for the GPUs that cannot afford it.
            hero.animate().cancel();
            ambient.animate().cancel();
            fillHero(position, label);
            hero.setY(y);
            hero.setTranslationX(0f);
            hero.setAlpha(1f);
            if (ambientGlow) {
                setAmbient(color);
                ambient.setAlpha(1f);
            }
            heroShown = true;
            return;
        }

        if (!heroShown) {
            stopAmbientAnimation();
            hero.animate().cancel();
            ambient.animate().cancel();
            fillHero(position, label);
            hero.setY(y);
            hero.setTranslationX(0f);
            hero.animate().alpha(1f).setDuration(260).start();
            if (ambientGlow) {
                setAmbient(color);
                ambient.animate().alpha(1f).setDuration(600).start();
            }
            heroShown = true;
        } else if (changed) {
            if (advancedEffects) hero.animate().cancel();
            hero.animate().alpha(0f).translationX(-12 * density).setDuration(120).withEndAction(() -> {
                fillHero(position, label);
                hero.setY(y);
                hero.setTranslationX(12 * density);
                hero.animate().alpha(1f).translationX(0f).setDuration(200).start();
            }).start();
            if (ambientGlow && advancedEffects) {
                transitionAmbient(color);
            } else if (ambientGlow && color != ambientColor && glowSnap) {
                ambient.animate().cancel();
                setAmbient(color);
                ambient.setAlpha(1f);
            } else if (ambientGlow && color != ambientColor) {
                ambient.animate().alpha(0.35f).setDuration(200).withEndAction(() -> {
                    setAmbient(color);
                    ambient.animate().alpha(1f).setDuration(500).start();
                }).start();
            }
        } else {
            hero.setY(y);
            // onPause cancels the fade-ins, and a second Home during one lands on the same tile, which starts none:
            // finish them, or the shelf and the glow stay dim until focus moves to another app.
            if (hero.getAlpha() < 1f) hero.animate().alpha(1f).setDuration(260).start();
            if (ambientGlow && color == ambientColor && ambient.getAlpha() < 1f) {
                ambient.animate().alpha(1f).setDuration(600).start();
            }
        }
    }

    /** The shelf's text for this dock app: its name and, on the cinematic shelf, "Last opened" and the dots. */
    private void fillHero(int position, String label) {
        heroName.setText(label);
        if (!cinematic) return;
        updateHeroMeta(position);
        updateHeroDots(position);
    }

    // ---- cinematic shelf -------------------------------------------------------------------------

    /**
     * The parts that never change: a larger name, the meta line and the dots, the artwork and the scrim, at
     * scrimPercent of its strength (cinematic_scrim). cinematic_art 0 leaves the artwork out, 0 percent the scrim.
     */
    private void setUpCinematicShelf(int scrimPercent) {
        heroName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 68f);
        heroName.setLetterSpacing(-0.025f);
        heroMeta.setVisibility(View.INVISIBLE);   // keeps its height, so the name does not jump when it fills in
        heroDots.setVisibility(heroDotsShown ? View.VISIBLE : View.GONE);
        heroArt.setVisibility(heroArtAlpha > 0f ? View.VISIBLE : View.GONE);
        // One stretched bitmap: apply its alpha while drawing instead of through an offscreen buffer.
        heroArt.forceHasOverlappingRendering(false);
        if (scrimPercent <= 0) return;   // cinematic_scrim 0: no scrim at all
        View scrim = findViewById(R.id.heroScrim);
        Drawable shade = scrimDrawable();
        // On the bitmap's paint, not the view: a view's alpha would draw the full screen through an offscreen buffer.
        shade.setAlpha(scrimPercent * 255 / 100);
        scrim.setBackground(shade);
        scrim.setVisibility(View.VISIBLE);
    }

    /**
     * Darkens the side the shelf's text is on and the lower part of the screen, so the name, the dock and
     * the grid stay readable over the artwork. One small bitmap stretched over the screen, like the glow.
     */
    private Drawable scrimDrawable() {
        int w = 480, h = 270;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        boolean rtl = getResources().getBoolean(R.bool.rtl_menu_bar);
        Paint paint = new Paint();
        paint.setShader(new LinearGradient(rtl ? w : 0, 0, rtl ? 0 : w, 0,
                new int[]{0xD1060406, 0x59060406, 0x00060406}, new float[]{0f, 0.42f, 0.7f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);
        paint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x00060406, 0x00060406, 0xDB060406, 0xFF060406}, new float[]{0f, 0.28f, 0.58f, 0.76f},
                Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);
        BitmapDrawable scrim = new BitmapDrawable(getResources(), bmp);
        scrim.setGravity(Gravity.FILL);
        return scrim;
    }

    /** Swaps the backdrop to this app's artwork: fade out, swap, fade in, the way the shelf's name changes. */
    private void showHeroArt(int position) {
        String key = adapter.keyAt(position);
        if (key == null) return;
        heroArt.animate().cancel();
        if (key.equals(heroArtKey)) {
            fadeHeroArt(420);
            return;
        }
        Bitmap art = heroArtCache.get(key);
        if (art == null) {
            art = HeroArt.from(adapter.artworkAt(position));
            if (art != null) heroArtCache.put(key, art);
        }
        heroArtKey = key;
        final Bitmap next = art;
        if (!animations || reducedMotion || heroArt.getAlpha() == 0f) {
            heroArt.setImageBitmap(next);
            fadeHeroArt(600);
            return;
        }
        heroArt.animate().alpha(0f).setDuration(140).withEndAction(() -> {
            heroArt.setImageBitmap(next);
            heroArt.animate().alpha(heroArtAlpha).setDuration(420).start();
        }).start();
    }

    private void fadeHeroArt(int ms) {
        if (!animations) heroArt.setAlpha(heroArtAlpha);
        else heroArt.animate().alpha(heroArtAlpha).setDuration(reducedMotion ? Math.min(ms, Motion.REDUCED_MS) : ms).start();
    }

    /** "Last opened yesterday, 9:40 PM", the time in white; nothing (but the same height) when it was never seen. */
    private void updateHeroMeta(int position) {
        long when = LastOpened.get(this, adapter.packageAt(position));
        if (when <= 0) {
            heroMeta.setVisibility(View.INVISIBLE);
            return;
        }
        String rel = LastOpened.describe(this, when);
        String text = getString(R.string.last_opened, rel);
        SpannableString line = new SpannableString(text);
        int at = text.indexOf(rel);
        if (at >= 0) line.setSpan(new ForegroundColorSpan(0xFFFFFFFF), at, at + rel.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        heroMeta.setText(line);
        heroMeta.setVisibility(View.VISIBLE);
    }

    /** One dot per dock app, the focused one drawn long and white. Hebrew docks start on the right, so do the dots. */
    private void updateHeroDots(int position) {
        if (!heroDotsShown) return;
        int count = Math.min(adapter.dockFilled(), COLUMNS);
        heroDots.setVisibility(count > 1 ? View.VISIBLE : View.INVISIBLE);
        if (heroDots.getChildCount() != count) {
            heroDots.removeAllViews();
            for (int i = 0; i < count; i++) {
                View dot = new View(this);
                GradientDrawable bg = new GradientDrawable();
                bg.setCornerRadius(3 * density);
                dot.setBackground(bg);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (6 * density), (int) (6 * density));
                if (i > 0) lp.leftMargin = (int) (6 * density);
                heroDots.addView(dot, lp);
            }
        }
        for (int i = 0; i < count; i++) {
            View dot = heroDots.getChildAt(rtlAppGrid ? count - 1 - i : i);
            boolean on = i == position;
            ((GradientDrawable) dot.getBackground()).setColor(on ? 0xFFFFFFFF : 0x4DFFFFFF);
            ViewGroup.LayoutParams lp = dot.getLayoutParams();
            int w = (int) ((on ? 20 : 6) * density);
            if (lp.width != w) {
                lp.width = w;
                dot.setLayoutParams(lp);
            }
        }
    }

    /**
     * The glow used to be a full-screen radial GradientDrawable. On Android 10 that drawable is
     * drawn on the CPU, so fading it for half a second redrew 1920×1080 every frame and the
     * highlight looked like it was running at a few frames per second. A small bitmap stretched
     * over the screen is one texture. It is painted once in white and tinted with the app's colour,
     * so changing apps neither repaints it on the CPU (about 11 ms) nor uploads it again.
     */
    private void setAmbient(int color) {
        if (color == ambientColor && ambient.getBackground() != null) return;
        ambientColor = color;
        BitmapDrawable glow = (BitmapDrawable) ambient.getBackground();
        if (glow == null) {
            int w = 480;
            int h = 270;
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (cinematic) {
                // Higher and stronger, from the corner away from the shelf's text: the app's colour floods
                // the top of the screen over its artwork, and the scrim keeps the text side dark.
                boolean rtl = getResources().getBoolean(R.bool.rtl_menu_bar);
                paint.setShader(new RadialGradient(
                        w * (rtl ? 0.20f : 0.80f), h * 0.06f, w * 0.78f,
                        new int[]{0xA6FFFFFF, 0x47FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.5f, 1f},
                        Shader.TileMode.CLAMP));
            } else if (Config.GLOW_HORIZON.equals(glowStyle)) {
                // The colour washes down from the top edge and fades out three quarters of the way down,
                // with a brighter band along the top like light over a horizon.
                paint.setShader(new LinearGradient(0, 0, 0, h * 0.75f,
                        new int[]{0x66FFFFFF, 0x24FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.4f, 1f},
                        Shader.TileMode.CLAMP));
                canvas.drawRect(0, 0, w, h, paint);
                paint.setShader(new RadialGradient(
                        w * 0.5f, -h * 0.25f, w * 0.55f,
                        new int[]{0x40FFFFFF, 0x00FFFFFF},
                        null,
                        Shader.TileMode.CLAMP));
            } else {
                paint.setShader(new RadialGradient(
                        w * 0.32f, h * 0.42f, w * 0.62f,
                        new int[]{0x5CFFFFFF, 0x26FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.45f, 1f},
                        Shader.TileMode.CLAMP));
            }
            canvas.drawRect(0, 0, w, h, paint);
            glow = new BitmapDrawable(getResources(), bmp);
            glow.setGravity(Gravity.FILL);
            ambient.setBackground(glow);
        }
        // The default tint mode, SRC_IN, keeps the mask's alpha and takes the colour from the tint.
        glow.setTint(0xFF000000 | color);
    }

    private void transitionAmbient(int color) {
        // A rapid focus change continues from the colour actually displayed on screen.
        stopAmbientAnimation();
        ambient.animate().cancel();
        if (color == ambientColor) {
            ambient.animate().alpha(1f).setDuration(180).start();
            return;
        }
        ambient.animate().alpha(1f).setDuration(180).start();
        ambientAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), ambientColor, color);
        ambientAnimator.setDuration(360);
        ambientAnimator.addUpdateListener(animation -> setAmbient((int) animation.getAnimatedValue()));
        ambientAnimator.start();
    }

    private void stopAmbientAnimation() {
        if (ambientAnimator != null) {
            ambientAnimator.cancel();
            ambientAnimator = null;
        }
    }

    /**
     * Grid tiles (every tile with dock_row false): the glow behind the grid takes the focused tile's colour; the big
     * name above the dock does not show (every grid tile has its name underneath).
     */
    private void showGlowOnly(int position) {
        int color = adapter.ambientColorAt(position);
        stopAmbientAnimation();
        hero.animate().cancel();
        ambient.animate().cancel();
        hero.setAlpha(0f);
        heroArt.animate().cancel();
        heroArt.setAlpha(0f);
        heroShown = false;
        if (!ambientGlow) return;
        if (!animations || reducedMotion) {
            setAmbient(color);
            ambient.setAlpha(1f);
            return;
        }
        if (color == ambientColor && ambient.getBackground() != null) {
            ambient.animate().alpha(1f).setDuration(300).start();
            return;
        }
        if (glowSnap) {
            setAmbient(color);
            ambient.setAlpha(1f);
            return;
        }
        // The same dip-and-swap as the dock's top shelf.
        ambient.animate().alpha(0.35f).setDuration(ambient.getAlpha() > 0.35f ? 200 : 0).withEndAction(() -> {
            setAmbient(color);
            ambient.animate().alpha(1f).setDuration(500).start();
        }).start();
    }

    private void hideHero() {
        if (!heroShown) return;
        stopAmbientAnimation();
        hero.animate().cancel();
        ambient.animate().cancel();
        heroArt.animate().cancel();
        heroShown = false;
        if (animations && !reducedMotion) {
            hero.animate().alpha(0f).setDuration(160).start();
            if (ambientGlow) ambient.animate().alpha(0f).setDuration(300).start();
            heroArt.animate().alpha(0f).setDuration(300).start();
        } else {
            hero.setAlpha(0f);
            ambient.setAlpha(0f);
            heroArt.setAlpha(0f);
        }
    }

    private void hideGlass() {
        if (!glassShown) return;
        glassShown = false;
        glass.animate().cancel();
        if (animations && !reducedMotion) glass.animate().alpha(0f).setDuration(160).start();
        else glass.setAlpha(0f);
    }

    // ---- optional system stats (config.xml show_stats) --------------------------------------------

    /** Background reader. Started only while Home is resumed and show_stats is on. */
    private HandlerThread statsThread;
    /** The current run's handler; a run whose handler is no longer this one stops (volatile: read off-thread). */
    private volatile Handler statsBg;

    private void startStats() {
        if (statsThread != null) return;
        stats.setVisibility(View.VISIBLE);
        cpuTotalPrev = -1;
        idlePrev = -1;
        procStatDead = false;
        statsThread = new HandlerThread("stats");
        statsThread.start();
        // Each start gets its own handler, held by its task: stopStats on the main thread can clear the field
        // at any moment without the reader tripping over it.
        Handler bg = new Handler(statsThread.getLooper());
        statsBg = bg;
        bg.post(new Runnable() {
            @Override
            public void run() {
                if (statsBg != bg) return;
                String line = readStatsLine();
                handler.post(() -> {
                    if (showStats && stats != null && statsBg == bg) stats.setText(line);
                });
                if (statsBg == bg) bg.postDelayed(this, STATS_MS);
            }
        });
    }

    private void stopStats() {
        if (statsThread == null) return;
        statsBg.removeCallbacksAndMessages(null);
        statsThread.quit();
        statsThread = null;
        statsBg = null;
        // Paused (the quick panel or an app on top): keep the last line on screen. Taking it away moved the grid up
        // under a glass highlight that stayed put.
        if (!showStats) stats.setVisibility(View.GONE);
    }

    /** One quiet line, e.g. "CPU 8%  ·  Memory 430 MB free  ·  Storage 3.1 GB free". Runs off the main thread. */
    private static void appendStat(StringBuilder line, String part) {
        if (line.length() > 0) line.append("  ·  ");
        line.append(part);
    }

    private String readStatsLine() {
        int cpu = cpuPercent();
        if (cpu < 0) {
            try {
                Thread.sleep(200);             // second sample, so the first line already has a CPU figure
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return "";
            }
            cpu = cpuPercent();
        }
        // Android 8 and later hide /proc/stat from apps on many TVs: then the line leaves CPU out rather than
        // showing a dash that never fills in.
        StringBuilder line = new StringBuilder();
        if (cpu >= 0) line.append(getString(R.string.stats_cpu, cpu));
        long[] mem = memUsedOfTotalMb();
        if (mem != null) appendStat(line, getString(R.string.stats_memory, mem[0], mem[1]));
        String free = formatGb(getResources(), Environment.getDataDirectory().getFreeSpace());
        if (!free.isEmpty()) appendStat(line, getString(R.string.stats_storage, free));
        return StatsText.forLocale(line.toString(), getResources().getConfiguration().getLocales().get(0));
    }

    // -1: need another sample. -2: this source cannot be read (Android 9 hides /proc/stat from apps).
    private static final int CPU_UNREADABLE = -2;
    private long cpuTotalPrev = -1, cpuIdlePrev = -1;
    private boolean procStatDead;
    private long idlePrev = -1, wallPrev = -1;

    private int cpuPercent() {
        if (!procStatDead) {
            int fromStat = cpuFromProcStat();
            if (fromStat != CPU_UNREADABLE) return fromStat;
            procStatDead = true;
            idlePrev = -1;
        }
        return cpuFromIdle();
    }

    private int cpuFromProcStat() {
        String s = readFirstLine("/proc/stat");
        if (s == null || !s.startsWith("cpu")) return CPU_UNREADABLE;
        String[] t = s.trim().split("\\s+");
        if (t.length < 5) return CPU_UNREADABLE;
        try {
            long user = Long.parseLong(t[1]), nice = Long.parseLong(t[2]), sys = Long.parseLong(t[3]);
            long idle = Long.parseLong(t[4]);
            long iowait = t.length > 5 ? Long.parseLong(t[5]) : 0;
            long irq = t.length > 6 ? Long.parseLong(t[6]) : 0;
            long soft = t.length > 7 ? Long.parseLong(t[7]) : 0;
            long total = user + nice + sys + idle + iowait + irq + soft;
            long idleAll = idle + iowait;
            if (cpuTotalPrev < 0) {
                cpuTotalPrev = total;
                cpuIdlePrev = idleAll;
                return -1;
            }
            long dt = total - cpuTotalPrev, di = idleAll - cpuIdlePrev;
            cpuTotalPrev = total;
            cpuIdlePrev = idleAll;
            if (dt <= 0) return -1;
            int busy = (int) Math.round((dt - di) * 100.0 / dt);
            return Math.max(0, Math.min(100, busy));
        } catch (NumberFormatException e) {
            return CPU_UNREADABLE;
        }
    }

    /** Busy percent from cpuidle time (microseconds) across the cores. -1 until the second sample. */
    private int cpuFromIdle() {
        long idle = 0;
        int cores = 0;
        for (int i = 0; i < 8; i++) {
            boolean any = false;
            for (int state = 0; state < 8; state++) {
                String t = readFirstLine("/sys/devices/system/cpu/cpu" + i
                        + "/cpuidle/state" + state + "/time");
                if (t == null) break;
                try {
                    idle += Long.parseLong(t.trim());
                    any = true;
                } catch (NumberFormatException e) {
                    break;
                }
            }
            if (!any) break;
            cores++;
        }
        if (cores == 0) return -1;
        long wall = SystemClock.elapsedRealtime() * 1000L;
        if (idlePrev < 0) {
            idlePrev = idle;
            wallPrev = wall;
            return -1;
        }
        long di = idle - idlePrev;
        long dw = (wall - wallPrev) * cores;
        idlePrev = idle;
        wallPrev = wall;
        if (dw <= 0) return -1;
        int busy = (int) Math.round((dw - di) * 100.0 / dw);
        return Math.max(0, Math.min(100, busy));
    }

    /** RAM usage as {used, total} in MB (MemInfo.usedOfTotalMb); null when /proc/meminfo cannot be read. */
    private long[] memUsedOfTotalMb() {
        java.util.List<String> lines = new java.util.ArrayList<>();
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/proc/meminfo"))) {
            for (String line; (line = r.readLine()) != null;) lines.add(line);
        } catch (IOException ignored) {
            return null;
        }
        return MemInfo.usedOfTotalMb(lines);
    }

    private static String readFirstLine(String path) {
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(path))) {
            return r.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    private static String formatGb(Resources res, long bytes) {
        if (bytes <= 0) return "";
        double gb = bytes / (1024.0 * 1024 * 1024);
        return gb >= 10 ? res.getString(R.string.storage_gb_whole, gb)
                : res.getString(R.string.storage_gb_decimal, gb);
    }

    // ---- navigation ------------------------------------------------------------------------------

    @Override
    public boolean onTileVerticalKey(int position, int keyCode) {
        int count = adapter.appCount();
        int target;
        if (singleRow) {
            // One row: Up leaves for the top bar, Down has nowhere to go, and Left/Right walk the whole row,
            // stopping at its two ends (the default focus search scrolls the row to the next tile).
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) return true;
            boolean forward = rtlAppGrid ? keyCode == KeyEvent.KEYCODE_DPAD_LEFT : keyCode == KeyEvent.KEYCODE_DPAD_RIGHT;
            int last = adapter.focusablePosition(count - 1);
            if (forward && position >= last) {
                if (adapter.isLibraryAt(count)) focusLibrary();
                return true;
            }
            return !forward && position == 0;
        }
        // Horizontal: swallow the key at a row's ends so focus never wraps to the next row or
        // escapes up into the top bar. Mid-row moves fall through to the default focus search.
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            boolean forward = rtlAppGrid ? keyCode == KeyEvent.KEYCODE_DPAD_LEFT : keyCode == KeyEvent.KEYCODE_DPAD_RIGHT;
            if (forward && position == adapter.focusablePosition(count - 1) && adapter.isLibraryAt(count)) {
                focusLibrary();
                return true;
            }
            // In the dock, the last app is the row's end: the empty slots after it take no focus.
            int rowCount = position < COLUMNS ? Math.min(count, adapter.dockFilled()) : count;
            return GridNavigation.atHorizontalEdge(position, rowCount, COLUMNS,
                    rtlAppGrid, keyCode == KeyEvent.KEYCODE_DPAD_LEFT);
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            if (position < COLUMNS) return false;          // dock row: let focus move to the top bar
            target = position - COLUMNS;
        } else {
            int lastRowStart = ((count - 1) / COLUMNS) * COLUMNS;
            if (position >= lastRowStart) {
                if (adapter.isLibraryAt(count)) focusLibrary();
                return true;
            }
            target = Math.min(position + COLUMNS, count - 1);
        }
        focusTile(target);
        // The default focus search clicks for Left/Right; Up/Down are handled here, so click for them too.
        grid.playSoundEffect(keyCode == KeyEvent.KEYCODE_DPAD_UP
                ? SoundEffectConstants.NAVIGATION_UP : SoundEffectConstants.NAVIGATION_DOWN);
        return true;
    }

    @Override public void onLibraryFocused() {
        libraryFocusPending = false;
        hideGlass();
        hideHero();
    }

    /**
     * date_below_clock: the date column moves to its own line under the clock, in the vertical LinearLayout that holds
     * the clock's row, and the line between them goes. In Hebrew (rtl_menu_bar) the date and the clock's row sit right.
     */
    private void moveDateBelowClock() {
        View column = (View) findViewById(R.id.date).getParent();
        View clockRow = (View) findViewById(R.id.clock).getParent();
        LinearLayout clockColumn = (LinearLayout) clockRow.getParent();
        ((ViewGroup) column.getParent()).removeView(column);
        findViewById(R.id.clockDivider).setVisibility(View.GONE);
        // Its own width, not the column's: in Hebrew the column is only as wide as the clock.
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Math.round(4 * density);
        if (getResources().getBoolean(R.bool.rtl_menu_bar)) {
            // Date and clock flush right; the greeting stays left and follows the clock by translation.
            lp.gravity = Gravity.RIGHT;
            ((LinearLayout.LayoutParams) clockRow.getLayoutParams()).gravity = Gravity.RIGHT;
        }
        clockColumn.addView(column, clockColumn.indexOfChild(clockRow) + 1, lp);
        // The column now wraps its texts, so they must wrap too: a match_parent TextView does not ask for a new
        // layout when its text gets longer, and the column kept the width of the day before ("TUESDAY 27 OCTOB…").
        ViewGroup texts = (ViewGroup) column;
        for (int i = 0; i < texts.getChildCount(); i++) {
            View text = texts.getChildAt(i);
            LinearLayout.LayoutParams textLp = (LinearLayout.LayoutParams) text.getLayoutParams();
            textLp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            // Keep each line where its own gravity put it (right in Hebrew) now that it no longer fills the column.
            textLp.gravity = ((TextView) text).getGravity() & Gravity.HORIZONTAL_GRAVITY_MASK;
            text.setLayoutParams(textLp);
        }
    }

    /** Centre the one-row header when the greeting and extra date lines are absent (#2265). */
    private void centerCompactHeader() {
        LinearLayout clockRow = (LinearLayout) findViewById(R.id.clock).getParent();
        clockRow.setGravity(Gravity.CENTER_VERTICAL);
        clockRow.setBaselineAligned(false);
        View[] columns = {findViewById(R.id.clockDivider), (View) findViewById(R.id.date).getParent()};
        for (View column : columns) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) column.getLayoutParams();
            lp.gravity = Gravity.CENTER_VERTICAL;
            lp.bottomMargin = 0;
            column.setLayoutParams(lp);
        }
        LinearLayout buttons = findViewById(R.id.topButtons);
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) buttons.getLayoutParams();
        lp.addRule(RelativeLayout.ALIGN_TOP, R.id.leftBlock);
        lp.bottomMargin = 0;
        buttons.setLayoutParams(lp);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
    }

    /** With the date below, keep the icons beside the clock rather than beside the last date line. */
    private void alignDateBelowIconsWithClock() {
        View clock = findViewById(R.id.clock);
        View clockRow = (View) clock.getParent();
        LinearLayout buttons = findViewById(R.id.topButtons);
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) buttons.getLayoutParams();
        lp.addRule(RelativeLayout.ALIGN_TOP, R.id.leftBlock);
        lp.removeRule(RelativeLayout.ALIGN_BOTTOM);
        lp.topMargin = 0;
        lp.bottomMargin = 0;
        buttons.setLayoutParams(lp);
        // Either side can be laid out first; update after both without requesting another layout mid-pass.
        Runnable align = () -> buttons.setTranslationY(clockRow.getTop() + clock.getTop()
                + (clock.getHeight() - buttons.getHeight()) / 2f);
        clockRow.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> align.run());
        buttons.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> align.run());
    }

    /** The first top-bar button after Inputs that is shown, in bar order (top_bar_apps, the network pill, ...); Settings is always there. */
    private View firstTopButton() {
        ViewGroup bar = findViewById(R.id.topButtons);
        // The Hebrew layout (layout-iw) lists the bar mirrored, Settings first and Inputs last, so bar order
        // runs from the end there. Walking it forwards returned Settings, and the pill key guard then treated
        // Settings as both ends of the bar: Right from Settings was swallowed and never reached Wi-Fi.
        boolean rtl = getResources().getBoolean(R.bool.rtl_menu_bar);
        int n = bar.getChildCount();
        for (int k = 0; k < n; k++) {
            View button = bar.getChildAt(rtl ? n - 1 - k : k);
            if (button != btnInputs && button.getVisibility() == View.VISIBLE) return button;
        }
        return findViewById(R.id.btnSettings);
    }

    /** top_bar_apps buttons, in bar order. */
    private final List<View> topAppButtons = new ArrayList<>();

    /**
     * Puts each top_bar_apps app in the top bar as a round pill with the app's own logo, left of the network pill.
     * The logo keeps its colours: the pill style's tint, which turns the other icons white, is cleared.
     */
    private void addTopBarApps(List<String> packages, Map<String, String> launchActions) {
        ViewGroup bar = findViewById(R.id.topButtons);
        PackageManager pm = getPackageManager();
        int size = Math.round(22 * density);
        for (String pkg : packages) {
            Intent launch = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (launch == null) launch = pm.getLaunchIntentForPackage(pkg);
            if (launch == null) continue;   // not installed, or disabled
            // Use the same configured launch_actions as tiles; retain the normal entry if unavailable.
            launch = LaunchActions.select(pkg, launchActions, launch, (targetPackage, action) -> {
                Intent custom = LaunchActions.intent(targetPackage, action);
                return pm.resolveActivity(custom, 0) != null ? custom : null;
            });
            Drawable logo;
            CharSequence label;
            try {
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                logo = info.loadIcon(pm);
                label = info.loadLabel(pm);
            } catch (PackageManager.NameNotFoundException e) {
                continue;
            }
            TextView button = (TextView) getLayoutInflater().inflate(R.layout.top_app_button, bar, false);
            // pillKeys finds the bar's ends by id: without one of its own, every app button would be an end.
            button.setId(View.generateViewId());
            logo.setBounds(0, 0, size, size);
            button.setCompoundDrawablesRelative(logo, null, null, null);
            button.setCompoundDrawableTintList(null);
            button.setContentDescription(label);
            Intent target = launch;
            // An input: action switches the TV input, as the tile for the same app does.
            String inputId = LaunchActions.inputId(launchActions.get(pkg));
            if (inputId != null) button.setOnClickListener(v -> openInput(inputId));
            else button.setOnClickListener(v -> open(new Intent(target)));
            // After the network pill and the VPN pill; the Hebrew bar runs the other way, so before both there.
            bar.addView(button, bar.indexOfChild(getResources().getBoolean(R.bool.rtl_menu_bar) ? btnVpn : btnWifi));
            topAppButtons.add(button);
        }
    }

    @Override public void onLibraryUp() {
        if (adapter.appCount() == 0) { firstTopButton().requestFocus(); return; }
        int lastRow = ((adapter.appCount() - 1) / COLUMNS) * COLUMNS;
        focusTile(Math.min(lastRow + lastFocused % COLUMNS, adapter.appCount() - 1));
    }

    private void focusLibrary() {
        cancelPendingFocusScroll();
        int position = adapter.appCount();
        if (!adapter.isLibraryAt(position)) return;
        RecyclerView.ViewHolder holder = grid.findViewHolderForAdapterPosition(position);
        if (holder != null) {
            View button = holder.itemView.findViewById(R.id.btnLibrary);
            Rect visible = new Rect();
            if (button.getGlobalVisibleRect(visible) && visible.height() >= button.getHeight()) {
                if (button.requestFocus()) libraryFocusPending = false;
                return;
            }
        }
        if (!animations) {
            grid.scrollToPosition(position);
            grid.post(() -> {
                if (appLibrary != null || !hasWindowFocus()) return;
                RecyclerView.ViewHolder footer = grid.findViewHolderForAdapterPosition(adapter.appCount());
                if (footer != null && adapter.isLibraryAt(adapter.appCount())
                        && footer.itemView.findViewById(R.id.btnLibrary).requestFocus()) libraryFocusPending = false;
            });
            return;
        }
        pendingFocusScroll = new RecyclerView.OnScrollListener() {
            @Override public void onScrollStateChanged(@NonNull RecyclerView rv, int state) {
                if (state != RecyclerView.SCROLL_STATE_IDLE) return;
                rv.removeOnScrollListener(this);
                if (pendingFocusScroll != this) return;
                pendingFocusScroll = null;
                RecyclerView.ViewHolder footer = rv.findViewHolderForAdapterPosition(position);
                if (footer != null && footer.itemView.findViewById(R.id.btnLibrary).requestFocus())
                    libraryFocusPending = false;
            }
        };
        grid.addOnScrollListener(pendingFocusScroll);
        grid.smoothScrollToPosition(position);
    }

    private void cancelPendingFocusScroll() {
        if (pendingFocusScroll != null) {
            grid.removeOnScrollListener(pendingFocusScroll);
            pendingFocusScroll = null;
            grid.stopScroll();
        }
    }

    private void focusTile(int position) {
        libraryFocusPending = false;
        cancelPendingFocusScroll();
        if (adapter.appCount() == 0) {
            if (adapter.isLibraryAt(0)) focusLibrary();
            else firstTopButton().requestFocus();
            return;
        }
        final int pos = adapter.focusablePosition(Math.max(0, Math.min(position, adapter.appCount() - 1)));
        RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(pos);
        if (vh != null) {
            View card = vh.itemView.findViewById(R.id.card);
            // Already focused (e.g. back from an app): no focus change fires, so restore the glass by hand.
            if (card.isFocused()) onTileFocused(pos, card);
            else card.requestFocus();
            return;
        }
        // Not laid out yet: scroll there, then focus once the scroll settles.
        if (!animations) {
            grid.scrollToPosition(pos);
            grid.post(() -> {
                RecyclerView.ViewHolder h = grid.findViewHolderForAdapterPosition(pos);
                if (h != null) h.itemView.findViewById(R.id.card).requestFocus();
            });
            return;
        }
        pendingFocusScroll = new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView rv, int newState) {
                if (newState != RecyclerView.SCROLL_STATE_IDLE) return;
                rv.removeOnScrollListener(this);
                if (pendingFocusScroll != this) return;
                pendingFocusScroll = null;
                RecyclerView.ViewHolder h = rv.findViewHolderForAdapterPosition(pos);
                View target = h != null ? h.itemView.findViewById(R.id.card) : rv.getChildAt(0);
                if (target != null) target.requestFocus();
            }
        };
        grid.addOnScrollListener(pendingFocusScroll);
        grid.smoothScrollToPosition(pos);
    }

    // ---- top bar ---------------------------------------------------------------------------------

    /** Some TVs (Coocaa OS) set the network time without ACTION_TIME_CHANGED, so keep checking until it is valid. */
    private final Runnable clockCheck = this::updateClockVisibility;

    private void updateClockVisibility() {
        boolean valid = System.currentTimeMillis() >= TIME_VALID_AFTER_MS;
        clockBlock.setVisibility(valid ? View.VISIBLE : View.INVISIBLE);
        handler.removeCallbacks(clockCheck);
        if (valid) {
            updateGreeting();
        } else {
            handler.postDelayed(clockCheck, 1_000L);
        }
    }

    private void updateGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int res;
        // Locale-specific day parts (app language on Android 13+).
        // Indonesian: Pagi 00-10, Siang 10-15, Sore 15-18, Malam 18-24.
        // Spain (es-ES) and Catalan: "Buenas tardes" into the evening; "Buenas noches" from 21.
        // Latin American Spanish (es-MX, es-AR, …) keeps the default hours: evening strings are also
        // «Buenas noches», and there «Buenas noches» from ~17 matches local use better than Spain's 21.
        Locale locale = getResources().getConfiguration().getLocales().get(0);
        String lang = locale.getLanguage();
        String country = locale.getCountry();
        if ("in".equals(lang) || "id".equals(lang)) {
            if (hour < 10) res = R.string.good_morning;
            else if (hour < 15) res = R.string.good_afternoon;
            else if (hour < 18) res = R.string.good_evening;
            else res = R.string.good_night;
        } else if (("es".equals(lang) && "ES".equals(country)) || "ca".equals(lang)) {
            if (hour < 6) res = R.string.good_night;
            else if (hour < 12) res = R.string.good_morning;
            else if (hour < 21) res = R.string.good_afternoon;
            else res = R.string.good_night;
        } else if ("da".equals(lang)) {
            // Danish day parts: "Godmorgen" until 11, then "God formiddag" to noon.
            if (hour < 5) res = R.string.good_night;
            else if (hour < 11) res = R.string.good_morning;
            else if (hour < 12) res = R.string.good_forenoon;
            else if (hour < 18) res = R.string.good_afternoon;
            else if (hour < 22) res = R.string.good_evening;
            else res = R.string.good_night;
        } else {
            if (hour < 5) res = R.string.good_night;
            else if (hour < 12) res = R.string.good_morning;
            else if (hour < 17) res = R.string.good_afternoon;
            else if (hour < 22) res = R.string.good_evening;
            else res = R.string.good_night;
        }
        String festiveGreeting = festive ? festival.greetingText(getResources()) : "";
        if (!festiveGreeting.isEmpty()) {
            greeting.setText(festiveGreeting);
            greeting.setTextColor(liftTowardsWhite(festival.accentColor(), 0.25f));
        } else {
            greeting.setText(greetingName.isEmpty() ? getString(res)
                    : getString(R.string.greeting_with_name, getString(res), greetingName));
            greeting.setTextColor(greetingColor);
        }
        if (shamsi) shamsiDate.setText(Shamsi.today(getResources()));
        if (lunar) lunarDate.setText(Lunar.today(getResources(), lunarOffset));
    }

    // ---- race-weekend panel (a theme's race_calendar) -----------------------------------------------

    private static final int RACE_RED = 0xFFFF3B2F;

    /**
     * Shows or hides the race-weekend panel for this minute. Text only, set once a minute with the clock:
     * nothing animates, so the panel costs the GPU nothing between ticks.
     */
    /**
     * The race panel's place under the clock. With game_day off it is exactly the F1 panel (updateRace). With it on,
     * each team's next game takes a turn there, and the theme's F1 weekend is one more turn drawn as today.
     */
    private void updatePanel() {
        if (gameDay == null) {
            updateRace();
            return;
        }
        handler.removeCallbacks(turnTick);
        long now = System.currentTimeMillis();
        List<GameDay.Turn> games = gameDay.turns();
        for (GameDay.Turn g : games) {
            if (g.endMs <= now && now - lastEndedRead > MINUTE_MS) {
                // A game is over: the add-on already has that team's next one.
                lastEndedRead = now;
                gameDay.read();
                break;
            }
        }
        RaceWeekend.State f1 = raceCalendar.isEmpty() ? null : RaceWeekend.at(raceCalendar, java.time.Instant.ofEpochMilli(now));
        List<GameDay.Turn> turns = GameDay.merge(games, f1, now);
        if (turns.isEmpty()) {
            racePanel.setVisibility(View.GONE);
            return;
        }
        int seconds = gameDay.turnSeconds();
        long since = SystemClock.elapsedRealtime() - rotationStart;
        int on = GameDay.current(turns.size(), since, seconds);
        GameDay.Turn t = turns.get(on);
        if (t.f1) {
            raceBar.setBackgroundResource(R.drawable.race_bar);
            raceSessions.setVisibility(View.VISIBLE);
            updateRace();
        } else {
            GradientDrawable bar = new GradientDrawable();
            bar.setCornerRadius(1.5f * density);
            bar.setColor(t.colour);
            raceBar.setBackground(bar);
            raceKicker.setText(t.topLine);
            if (GameDay.live(t, now)) {
                SpannableString live = new SpannableString("\u25CF  " + getString(R.string.game_live));
                live.setSpan(new ForegroundColorSpan(RACE_RED), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                raceHeadline.setText(live);
            } else {
                String in = RaceWeekend.countdown(getResources(), GameDay.until(t, now));
                raceHeadline.setText(t.word.isEmpty() ? in : getString(R.string.race_next, t.word, in));
            }
            // No session times for a game: the line takes no room, so the dots sit under the countdown.
            raceSessions.setVisibility(View.GONE);
            racePanel.setVisibility(View.VISIBLE);
        }
        showPager(turns.size(), on);
        if (turns.size() > 1 && !stopped) handler.postDelayed(turnTick, GameDay.delayToNextTurn(since, seconds));
    }

    /** One dot per turn, the one on screen bright; none for a single turn. */
    private void showPager(int count, int on) {
        if (count < 2) {
            racePager.setVisibility(View.GONE);
            return;
        }
        if (racePager.getChildCount() != count) {
            racePager.removeAllViews();
            int size = Math.round(5 * density);
            for (int k = 0; k < count; k++) {
                View dot = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setShape(GradientDrawable.OVAL);
                d.setColor(0xFFFFFFFF);
                dot.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
                lp.setMarginEnd(size);
                racePager.addView(dot, lp);
            }
        }
        for (int k = 0; k < count; k++) racePager.getChildAt(k).setAlpha(k == on ? 0.9f : 0.3f);
        racePager.setVisibility(View.VISIBLE);
    }

    private void updateRace() {        // an empty calendar (a theme without race_calendar, or a reset) hides a panel the last theme showed
        RaceWeekend.State s = raceCalendar.isEmpty() ? null : RaceWeekend.at(raceCalendar, java.time.Instant.now());
        if (s == null) {
            racePanel.setVisibility(View.GONE);
            return;
        }
        RaceWeekend.Race race = s.race;
        raceKicker.setText(race.place.isEmpty()
                ? getString(R.string.race_kicker_no_place, race.round, race.shortName())
                : getString(R.string.race_kicker, race.round, race.shortName(), race.place));

        if (s.live != null) {
            SpannableString live = new SpannableString("\u25CF  " + getString(R.string.race_live, s.live.title(getResources())));
            live.setSpan(new android.text.style.ForegroundColorSpan(RACE_RED), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            raceHeadline.setText(live);
        } else if (s.next != null) {
            String in = RaceWeekend.countdown(getResources(), s.untilNext);
            raceHeadline.setText(s.next.isRace() ? getString(R.string.race_lights_out, in)
                    : getString(R.string.race_next, s.next.title(getResources()), in));
        } else {
            raceHeadline.setText(R.string.race_finished);
        }

        // FP1 FRI 11:00 PM   FP2 SAT 2:30 AM ...: done sessions fade, the live one is red, the next one bright.
        java.time.format.DateTimeFormatter when = java.time.format.DateTimeFormatter.ofPattern(
                ClockFormat.is24(this, clockFormat) ? "EEE HH:mm" : "EEE h:mm a", Locale.getDefault())
                .withZone(java.time.ZoneId.systemDefault());
        android.text.SpannableStringBuilder row = new android.text.SpannableStringBuilder();
        for (int i = 0; i < race.sessions.size(); i++) {
            RaceWeekend.Session session = race.sessions.get(i);
            if (i > 0) row.append("     ");
            int start = row.length();
            row.append(session.shortName(getResources())).append("  ").append(when.format(session.start).toUpperCase(Locale.getDefault()));
            int color;
            switch (s.statuses.get(i)) {
                case DONE: color = 0x47FFFFFF; break;
                case LIVE: color = RACE_RED; break;
                case NEXT: color = 0xFFFFFFFF; break;
                default: color = 0x99FFFFFF;
            }
            row.setSpan(new android.text.style.ForegroundColorSpan(color), start, row.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        raceSessions.setText(row);
        racePanel.setVisibility(View.VISIBLE);
    }

    private void refreshPillsAfterNextDraw() {
        root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                root.getViewTreeObserver().removeOnPreDrawListener(this);
                // Posted from inside the frame's traversal, so it runs after that frame is drawn. A post straight
                // from onResume would run first: the frame is only scheduled after onResume returns.
                handler.post(() -> {
                    if (isDestroyed()) return;
                    updateWifiLabel();
                    updateInputsButton();
                });
                return true;
            }
        });
        root.invalidate();   // a resume that changes nothing on screen still draws once, so the refresh runs
    }

    // ---- custom: Bluetooth in the Wi-Fi pill --------------------------------------------------------------

    /** Launcher settings, "Bluetooth en la pastilla": the rune and the number of connected devices after the network name. */
    private boolean bluetoothPill = true;

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handler.post(MainActivity.this::updateWifiLabel);
        }
    };

    /** -1 hides the badge (Bluetooth off, absent, switched off in settings or not allowed); otherwise the connected devices. */
    private int bluetoothDevices() {
        if (!bluetoothPill) return -1;
        try {
            if (Build.VERSION.SDK_INT >= 31
                    && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                return -1;
            }
            android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) return -1;
            int connected = 0;
            try {
                java.lang.reflect.Method isConnected = android.bluetooth.BluetoothDevice.class.getMethod("isConnected");
                for (android.bluetooth.BluetoothDevice device : adapter.getBondedDevices()) {
                    if (Boolean.TRUE.equals(isConnected.invoke(device))) connected++;
                }
            } catch (ReflectiveOperationException | RuntimeException e) {
                // Not offered on this firmware: fall back to the connections the public API can count.
                android.bluetooth.BluetoothManager manager =
                        (android.bluetooth.BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                if (manager != null) {
                    connected = manager.getConnectedDevices(android.bluetooth.BluetoothProfile.GATT).size();
                }
            }
            return connected;
        } catch (RuntimeException e) {
            return -1;
        }
    }

    /** Adds the Bluetooth badge after the network name; with no room for it the name is shortened, never the badge. */
    private void applyBluetoothBadge() {
        if (wifiIconOnly) return;
        int devices = bluetoothDevices();
        if (devices < 0) return;
        CharSequence base = btnWifi.getText();
        // The VPN capsule already uses the end of the label.
        if (base instanceof Spanned && ((Spanned) base).getSpans(0, base.length(), Object.class).length > 0) return;
        BluetoothBadge badge = new BluetoothBadge(devices, density);
        TextPaint paint = btnWifi.getPaint();
        Drawable[] compound = btnWifi.getCompoundDrawablesRelative();
        int iconRoom = compound[0] != null ? compound[0].getIntrinsicWidth() + btnWifi.getCompoundDrawablePadding() : 0;
        float room = btnWifi.getMaxWidth() - btnWifi.getPaddingStart() - btnWifi.getPaddingEnd() - iconRoom
                - badge.getSize(paint, "", 0, 0, null) - 2 * paint.measureText(" ") - 2 * density;
        CharSequence name = TextUtils.ellipsize(base, paint, Math.max(0, room), TextUtils.TruncateAt.END);
        android.text.SpannableStringBuilder label = new android.text.SpannableStringBuilder(name);
        label.append("  ");
        int at = label.length();
        label.append(" ");
        label.setSpan(badge, at, label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        btnWifi.setText(label);
    }

    /** The Wi-Fi icon with as many arcs lit as the signal has bars (1 to 4). */
    private static int wifiLevelIcon(int level) {
        switch (level) {
            case 1: return R.drawable.ic_wifi_level_1;
            case 2: return R.drawable.ic_wifi_level_2;
            case 3: return R.drawable.ic_wifi_level_3;
            default: return R.drawable.ic_wifi_level_4;
        }
    }

    /** Shows the Wi-Fi network name on the button when we can read it, otherwise the connection type. */
    @SuppressWarnings("deprecation")
    private void updateWifiLabel() {
        String text = getString(R.string.wifi);
        boolean vpn = false, online = false, validated = false;
        int icon = R.drawable.ic_wifi_level_4;
        // The festive light (diya flame or jack-o'-lantern candle): 0 is out (offline), 1 to 4 follow the Wi-Fi
        // signal, Ethernet burns steady at 4.
        int flame = 0;
        boolean steady = false;
        try {
            ConnectivityManager cm = getApplicationContext().getSystemService(ConnectivityManager.class);
            boolean wifi = false, ethernet = false;
            // All networks, not just the active one: with a VPN up the active network is the VPN itself.
            for (Network net : cm != null ? cm.getAllNetworks() : new Network[0]) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(net);
                if (caps == null) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    vpn = true;
                    continue;
                }
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                online = true;
                // Android reached the internet through it; a captive portal stays unvalidated until login.
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) validated = true;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) ethernet = true;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true;
            }
            if (!online) {
                text = getString(R.string.offline);
                icon = R.drawable.ic_wifi_slash;
                vpn = false;
            } else if (ethernet) {
                text = getString(R.string.ethernet);
                icon = R.drawable.ic_ethernet;
                flame = 4;
                steady = true;
            } else if (wifi) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo info = wm != null ? wm.getConnectionInfo() : null;
                String ssid = info != null ? info.getSSID() : null;
                flame = info != null ? Math.max(1, Math.min(4, WifiManager.calculateSignalLevel(info.getRssi(), 5))) : 3;
                icon = wifiLevelIcon(flame);
                if (ssid != null) {
                    ssid = ssid.replace("\"", "").trim();
                    if (!ssid.isEmpty() && !ssid.contains("unknown") && !ssid.equals("0x")) text = ssid;
                }
            }
        } catch (Exception ignored) {
        }
        // With a VPN app configured, a VPN that is down matters too: show a red "VPN off" capsule then.
        boolean vpnDown = !vpn && online && !vpnApp.isEmpty();
        if (vpnPill) updateVpnPill(vpn);
        if ((vpn || vpnDown) && !vpnPill) {
            // Network name, then the green lock-and-VPN (or red "VPN off") capsule drawn in place of the word.
            String badge = getString(vpn ? R.string.vpn : R.string.vpn_off);
            VpnBadge span = new VpnBadge(vpn ? getDrawable(R.drawable.ic_lock) : null, density);
            // The pill has a maximum width and ellipsizes at the end, which would cut the badge off after
            // a long network name, so shorten the name to whatever room the badge leaves. The Wi-Fi icon and its
            // gap are counted by hand: until the pill has a resolved layout direction (the first call, from
            // onResume, runs before that) getTotalPaddingStart/End leave the compound drawables out, which
            // left the name about 31dp too much room and the badge cut off.
            TextPaint paint = btnWifi.getPaint();
            Drawable[] compound = btnWifi.getCompoundDrawablesRelative();
            int iconRoom = compound[0] != null ? compound[0].getIntrinsicWidth() + btnWifi.getCompoundDrawablePadding() : 0;
            float room = btnWifi.getMaxWidth() - btnWifi.getPaddingStart() - btnWifi.getPaddingEnd() - iconRoom
                    - span.getSize(paint, badge, 0, badge.length(), null) - paint.measureText(" ") - 2 * density;
            String name = TextUtils.ellipsize(text, paint, Math.max(0, room), TextUtils.TruncateAt.END).toString();
            // A long badge ("VPN отключён") can leave room for a stub like "MT…", which says nothing and, after
            // rounding, can push the badge itself out of the pill. Show the badge alone then. On Ethernet the
            // icon already names the link, and "Ethernet" cut to "Ethe…" or not depended on the font size (#961),
            // so Ethernet always shows the icon and the badge alone.
            // The space stays even then: a line holding only the span gets no font metrics and collapses.
            boolean stub = name.length() < text.length() && name.length() < 5;
            text = stub || icon == R.drawable.ic_ethernet ? "" : name;
            SpannableString label = new SpannableString(text + " " + badge);
            label.setSpan(span, text.length() + 1, label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (!TextUtils.equals(btnWifi.getText(), label)) btnWifi.setText(label);
        } else if (!TextUtils.equals(btnWifi.getText(), text)) {
            btnWifi.setText(text);
        }
        if (wifiIconOnly) {
            btnWifi.setContentDescription(btnWifi.getText());
            btnWifi.setText(null);
        } else {
            applyBluetoothBadge();
        }
        if (festive && lamp != null) {
            if (online && flame == 0) flame = 3;   // online some other way (cellular, USB tethering)
            lamp.setSteady(steady);
            lamp.setFlame(flame);
        } else {
            if (icon != wifiIcon) {
                wifiIcon = icon;
                btnWifi.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
            }
            ColorStateList tint = online ? wifiOnlineTint : wifiPlainTint;
            // wifi_status_warnings: orange while connected but not validated (a captive portal), red while offline.
            if (wifiNoInternetTint != null) tint = !online ? wifiOfflineTint : validated ? wifiOnlineTint : wifiNoInternetTint;
            if (wifiOnlineTint != null && btnWifi.getCompoundDrawableTintList() != tint) {
                btnWifi.setCompoundDrawableTintList(tint);
            }
        }
    }

    /** config.xml icon_only_buttons. */
    private boolean iconOnlyButtons;
    /** config.xml top_menu: Inputs, Wi-Fi and Settings folded into one gear. */
    private boolean topMenu;
    /** show_inputs_pill as configured: top_menu clears showInputsPill, so its Inputs row reads this. */
    private boolean showInputsMenuRow = true;
    private boolean launcherSettingsButton;
    /** icon_only_buttons without wifi_label_width: the Wi-Fi pill shows no network name. */
    private boolean wifiIconOnly;
    /** config.xml wifi_status_color: the Wi-Fi icon's green while online and its usual pill colours; null while off. */
    private ColorStateList wifiOnlineTint, wifiPlainTint;
    /** wifi_status_warnings (with wifi_status_color): orange without internet, red offline; null while off. */
    private ColorStateList wifiNoInternetTint, wifiOfflineTint;
    /** The app library button in the top bar (library_button). */
    private View btnLibraryTop;
    /** Custom: follows the app that is playing media for the header's now-playing pill. */
    private NowPlaying nowPlaying;
    private View mediaPillView;
    private Runnable mediaTick;
    /** The open library came from that button: closing it returns there instead of scrolling to the grid's end. */
    private boolean libraryFromTopBar;
    /** The open library came from the VPN pill (vpn_pill, no VPN app): closing it returns there while the pill still shows. */
    private boolean libraryFromVpnPill;

    /** Turns a labelled top pill into the round TopButtonIcon shape: no text, the icon centred by even padding. */
    private void makeIconOnly(TextView pill) {
        pill.setContentDescription(pill.getText());
        pill.setText(null);
        pill.setMaxWidth(Integer.MAX_VALUE);
        int pad = Math.round(6 * density);
        pill.setPaddingRelative(pad, 0, pad, 0);
        pill.setCompoundDrawablePadding(0);
        pill.getLayoutParams().width = Math.round(34 * density);
    }

    // ---- festive skin ------------------------------------------------------------------------------

    /**
     * Swaps the pill icons for the festival's: a bell for Inputs that swings when focused, a diya for the
     * network whose flame follows the connection, and a marigold for Settings that turns when focused. Halloween
     * has its own: a bat for Inputs that flaps, a jack-o'-lantern whose face glows while online, and a ghost for
     * Settings that floats up.
     */
    private void applyFestiveSkin(TextView inputs, TextView settings) {
        if (festival.isHalloween()) {
            SpookyIconDrawable bat = new SpookyIconDrawable(getResources(), density, SpookyIconDrawable.BAT);
            SpookyIconDrawable ghost = new SpookyIconDrawable(getResources(), density, SpookyIconDrawable.GHOST);
            JackOLanternDrawable pumpkin = new JackOLanternDrawable(getResources(), density);
            bat.setReducedMotion(reducedMotion);
            ghost.setReducedMotion(reducedMotion);
            pumpkin.setReducedMotion(reducedMotion);
            lamp = pumpkin;
            setFestiveIcon(inputs, bat);
            setFestiveIcon(btnWifi, pumpkin);
            setFestiveIcon(settings, ghost);
            addFocusAction(inputs, bat::nudge);
            addFocusAction(settings, ghost::nudge);
            return;
        }
        bell = new BellDrawable(density);
        marigold = new MarigoldDrawable(density);
        DiyaDrawable diya = new DiyaDrawable(density);
        bell.setReducedMotion(reducedMotion);
        marigold.setReducedMotion(reducedMotion);
        diya.setReducedMotion(reducedMotion);
        lamp = diya;
        setFestiveIcon(inputs, bell);
        setFestiveIcon(btnWifi, diya);
        setFestiveIcon(settings, marigold);
        addFocusAction(inputs, bell::ring);
        addFocusAction(settings, marigold::turn);
    }

    private static void setFestiveIcon(TextView pill, Drawable icon) {
        // The pills tint their icons to follow focus; the festive ones keep their own colours.
        pill.setCompoundDrawableTintList(null);
        pill.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, null, null, null);
    }

    /** Runs {@code action} when the view gains focus, keeping any focus listener it already had. */
    private static void addFocusAction(View view, Runnable action) {
        View.OnFocusChangeListener previous = view.getOnFocusChangeListener();
        view.setOnFocusChangeListener((v, focused) -> {
            if (previous != null) previous.onFocusChange(v, focused);
            if (focused) action.run();
        });
    }

    private void playPetalShower() {
        if (isFinishing() || isDestroyed()) return;
        if (festival.isHalloween()) {
            BatFlightView bats = new BatFlightView(this);
            root.addView(bats, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            bats.play(16, 2800, () -> root.removeView(bats));
            return;
        }
        PetalShowerView shower = new PetalShowerView(this);
        root.addView(shower, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        shower.play(60, 2200, () -> root.removeView(shower));
    }

    private static int liftTowardsWhite(int argb, float amount) {
        int r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        r += (int) ((255 - r) * amount);
        g += (int) ((255 - g) * amount);
        b += (int) ((255 - b) * amount);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /**
     * The network pill opens the VPN app when one is configured and installed, otherwise Wi-Fi settings. With
     * vpn_pill the VPN app has its own pill, so this one always opens Wi-Fi settings.
     */
    private void openNetworkPill() {
        Intent i = vpnPill ? null : vpnAppIntent();
        open(i != null ? i : systemIntent(Settings.ACTION_WIFI_SETTINGS));
    }

    /** vpn_app's launch intent, or null when none is set or it is not installed. */
    private Intent vpnAppIntent() {
        if (vpnApp.isEmpty()) return null;
        Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(vpnApp);
        return i != null ? i : getPackageManager().getLaunchIntentForPackage(vpnApp);
    }

    /**
     * vpn_pill: the VPN app, where it is switched on and off. Without one installed, the App library to pick from, or
     * Android's VPN settings when the theme turned the library off.
     */
    private void openVpnPill() {
        Intent i = vpnAppIntent();
        if (i != null || !appLibraryEnabled) {
            open(i != null ? i : systemIntent(Settings.ACTION_VPN_SETTINGS));
            return;
        }
        onLibraryRequested();
        libraryFromVpnPill = true;
    }

    /** vpn_pill: the pill outlined in green with a lock while a VPN is up, outlined in red "VPN off" while it is not;
     *  solid with a white ring only while focused. */
    private void updateVpnPill(boolean vpn) {
        int state = VpnBadge.pillState(vpn, vpnAppIntent() != null);
        if (state == VpnBadge.PILL_HIDDEN) {
            if (btnVpn.getVisibility() == View.GONE) return;
            boolean focused = btnVpn.hasFocus();
            btnVpn.setVisibility(View.GONE);
            if (focused) (btnWifi.getVisibility() == View.VISIBLE ? btnWifi : firstTopButton()).requestFocus();
            return;
        }
        if (state != vpnPillState) {
            vpnPillState = state;
            boolean up = state == VpnBadge.PILL_UP;
            // The state colour at rest (the pill is an outline then), the contrasting ink on the solid focused fill.
            ColorStateList ink = new ColorStateList(
                    new int[][]{new int[]{android.R.attr.state_focused}, new int[0]},
                    new int[]{VpnBadge.pillInkColor(up, true), VpnBadge.pillInkColor(up, false)});
            if (iconOnlyVpn) {
                // An open lock on the plain glass button, or the closed lock outlined in green like the pill (solid
                // while focused); the words go to talkback.
                btnVpn.setContentDescription(getString(up ? R.string.vpn : R.string.vpn_off));
                btnVpn.setBackground(up ? VpnBadge.pillBackground(true, density) : vpnPlainBackground.newDrawable());
                btnVpn.setCompoundDrawablesRelativeWithIntrinsicBounds(VpnBadge.iconOnlyLock(up), 0, 0, 0);
                btnVpn.setCompoundDrawableTintList(up ? ink : vpnPlainInk);
                btnVpn.setVisibility(View.VISIBLE);
                return;
            }
            btnVpn.setText(up ? R.string.vpn : R.string.vpn_off);
            btnVpn.setTextColor(ink);
            btnVpn.setBackground(VpnBadge.pillBackground(up, density));
            btnVpn.setCompoundDrawablesRelativeWithIntrinsicBounds(up ? R.drawable.ic_lock : 0, 0, 0, 0);
            btnVpn.setCompoundDrawableTintList(ink);
        }
        btnVpn.setVisibility(View.VISIBLE);
    }


    /** Every settings entry shares the standard intent and the vendor fallback (SystemSettings). */
    private Intent systemIntent(String standardAction) {
        return SystemSettings.intent(this, standardAction);
    }

    /** Hides the Inputs pill when it would have nothing to list: streaming boxes have no HDMI-in, AV or tuner. */
    private void updateInputsButton() {
        if (!showInputsPill) {
            btnInputs.setVisibility(View.GONE);
            return;
        }
        btnInputs.setVisibility(tvHasInputs() ? View.VISIBLE : View.GONE);
    }

    /** True when the TV has something to list in the Inputs menu (also decides the control-panel card). */
    private boolean tvHasInputs() {
        boolean any = liveTvIntent() != null || !sourcePanelService.isEmpty()
                || (coocaaSources && !CoocaaSources.list(this).isEmpty());
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (!any && tim != null) {
            for (TvInputInfo info : tim.getTvInputList()) {
                // Inputs hidden in Settings > Inputs are left out of the menu, so they don't count here either.
                if (info.isPassthroughInput() && !info.isHidden(this)) {
                    any = true;
                    break;
                }
            }
        }
        return any;
    }

    /** boot_to_live_tv, or the Open on start app: the first time Home comes up after the TV starts, open that app
     *  instead. Once per boot, keyed on Settings.Global.BOOT_COUNT and committed to disk before the app starts: on a
     *  low-memory TV the app can push the launcher out of memory, and an apply() still in flight was lost then, so
     *  every Home press opened the app again. */
    private boolean openLiveTvAfterBoot() {
        String app = openOnStartChoice ? getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE)
                .getString(OpenOnStart.KEY, "") : "";
        if (!bootToLiveTv && app.isEmpty()) return false;
        int boot = OpenOnStart.boot(this);
        SharedPreferences prefs = getSharedPreferences(OpenOnStart.BOOT_PREFS, MODE_PRIVATE);
        String target = bootToLiveTv ? liveTvPkg : app;
        if (!OpenOnStart.due(boot, prefs.getInt(OpenOnStart.BOOT_KEY, -1), target, getPackageName())) return false;
        if (!prefs.edit().putInt(OpenOnStart.BOOT_KEY, boot).commit()) return false;
        if (bootToLiveTv && bootInputId != null) {
            openInput(bootInputId);
            return true;
        }
        Intent i = bootToLiveTv ? liveTvIntent() : OpenOnStart.intent(getPackageManager(), app);
        if (i == null) return false;
        return openWhenReady(i);
    }

    /** open_on_start_on_wake: the remote's power button is a light sleep on some sets, with no boot for
     *  openLiveTvAfterBoot to catch. */
    private void openStartAppOnWake() {
        String app = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getString(OpenOnStart.KEY, "");
        if (app.isEmpty() || app.equals(getPackageName())) return;
        Intent i = OpenOnStart.intent(getPackageManager(), app);
        if (i != null) openWhenReady(i);
    }

    private boolean openWhenReady(Intent i) {
        // open_on_start_network_wait: Home stays on screen until the network is back or the wait is over.
        if (openOnStartWaitMs > 0 && !OpenOnStart.online(this)) {
            startPending = i;
            startDeadline = SystemClock.elapsedRealtime() + openOnStartWaitMs;
            handler.postDelayed(openWhenOnline, openOnStartWaitMs);
            // Validated between the check above and startPending: networkCallback may have skipped it.
            if (OpenOnStart.online(this)) handler.post(openWhenOnline);
            return false;
        }
        open(i);
        return true;
    }

    /** The Live TV app's launch intent: its leanback entry point, or the configured action if it has none. */
    private Intent liveTvIntent() {
        if (liveTvPkg.isEmpty()) return null;
        Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(liveTvPkg);
        if (i != null || liveTvAction.isEmpty()) return i;
        Intent byAction = new Intent(liveTvAction).setPackage(liveTvPkg);
        return getPackageManager().resolveActivity(byAction, 0) != null ? byAction : null;
    }

    /** The TV's own source-selection panel, for TVs that have no TvInputManager (TCL Android TV 9): a
     *  service, or an activity on sets whose panel is a dialog (BYINTEK U4's QuickSourceActivity). */
    private void openSourcePanel() {
        Intent i = new Intent(sourcePanelAction);
        ComponentName c = ComponentName.unflattenFromString(sourcePanelService);
        if (c != null) i.setComponent(c);
        int eq = sourcePanelExtra.indexOf('=');
        if (eq > 0) {
            try {
                i.putExtra(sourcePanelExtra.substring(0, eq).trim(),
                        Integer.parseInt(sourcePanelExtra.substring(eq + 1).trim()));
            } catch (NumberFormatException ignored) {
            }
        }
        try {
            if (getPackageManager().resolveActivity(i, 0) != null) {
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            }
            startService(i);
        } catch (Exception e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    private void open(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /** `input_sources` in config.xml or a theme: "HW5=23" maps the framework input whose id ends in /HW5 to a vendor
     *  source number; "HW8=-" leaves that input out of the Inputs menu (a port the board reports but the set
     *  does not have). Returns the number, -1 for a left-out input, or null when the input is not listed. */
    private Integer mappedSource(String inputId) {
        return InputSources.mapped(inputSources, inputId);
    }

    /** Switches to a passthrough input (HDMI, AV). An input mapped in `input_sources` is opened by sending
     *  `input_action` with its source number as the int extra "input" (Xiaomi China firmware, whose tvplayer
     *  answers com.xiaomi.mitv.tvplayer.EXTSRC_PLAY and nothing else). Otherwise the standard way is
     *  ACTION_VIEW on its channel URI, which the Live TV app handles; where nothing takes that, the
     *  configured `input_action` is sent with the same URI instead (XGIMI's HDMI player only answers
     *  com.xgimi.action.hdmiPlayer). An `input_action` written as "package/.Activity" starts that activity
     *  itself, ahead of the standard way, for firmware that answers the channel URI with "unsupported"
     *  (Redmi X65, MiTV-NSOP0: com.xiaomi.mitv.tvplayer/.ExternalSourceActivity). With `input_uri_scheme` set (YaOS: live-tv) the same URI goes out
     *  with that scheme and no MIME type. A player guarded by a permission this build does not declare
     *  throws SecurityException, which used to take Home down with it (YaOS before the manifest asked
     *  for ACCESS_TV_SOURCE). */
    private void openInput(String inputId) {
        // A CEC device is a child input of its HDMI port; the vendor source number belongs to the port
        // (MiTV-MFFU0). Only that lookup uses the parent: the generic path below still opens the child.
        String sourceId = inputId;
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (tim != null) {
            try {
                TvInputInfo info = tim.getTvInputInfo(inputId);
                if (info != null && info.getParentId() != null) sourceId = info.getParentId();
            } catch (RuntimeException ignored) {
            }
        }
        Integer source = mappedSource(sourceId);
        if (source != null && source >= 0 && !inputAction.isEmpty()) {
            try {
                startActivity(inputActionIntent().putExtra("input", source.intValue())
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            } catch (ActivityNotFoundException | SecurityException e) {
                // fall through to the standard way
            }
        } else if (source == null && InputSources.isComponent(inputAction)) {
            // An activity named in input_action is the vendor's own source picker (Xiaomi: tvplayer's
            // ExternalSourceActivity). Its firmware answers the standard channel URI with "unsupported", so the
            // row goes straight there; the picker is the overlay the remote's Source button opens.
            try {
                startActivity(inputActionIntent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            } catch (ActivityNotFoundException | SecurityException e) {
                // fall through to the standard way
            }
        }
        Uri uri = TvContract.buildChannelUriForPassthroughInput(inputId);
        Intent view = (inputUriScheme.isEmpty()
                ? new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "vnd.android.cursor.item/channel")
                : new Intent(Intent.ACTION_VIEW, uri.buildUpon().scheme(inputUriScheme).build()))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // Aim it at the TV app first: apps installed later (a streaming app, a file manager) can claim the same
        // channel URI too, and with two or more handlers Android shows a chooser instead of the input (WhaleOS).
        if (!liveTvPkg.isEmpty()) {
            try {
                startActivity(new Intent(view).setPackage(liveTvPkg));
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
            }
        }
        try {
            startActivity(view);
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            if (inputAction.isEmpty()) {
                Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        open(inputActionIntent().setDataAndType(uri, "vnd.android.cursor.item/channel"));
    }

    /** `input_action` as an intent: an explicit component when it reads "package/.Activity", else an action. */
    private Intent inputActionIntent() {
        ComponentName component = InputSources.isComponent(inputAction)
                ? ComponentName.unflattenFromString(inputAction) : null;
        return component != null ? new Intent().setComponent(component) : new Intent(inputAction);
    }

    /** Dropdown menu under the Inputs pill: HDMI ports (with connection state), AV and Live TV. */
    private void showInputs() {
        // A configured source panel and no Live TV row to offer next to it: the panel is the whole menu.
        // The BYINTEK U4 needs this, as its TvInputManager lists three HDMI ports and an AV input it doesn't have.
        List<CoocaaSources.Source> coocaa = coocaaSources ? CoocaaSources.list(this) : Collections.emptyList();
        if (coocaa.isEmpty() && !sourcePanelService.isEmpty() && liveTvIntent() == null) {
            openSourcePanel();
            return;
        }
        // top_menu: the pill is gone, so the list hangs under the gear, growing inward from the right.
        // Read the switch, not the pill: show_inputs_pill=false hides the pill too, and there the list
        // keeps its usual place.
        // Pill hidden (show_inputs_pill=false): the list opens from the panel, so hang it under the gear.
        boolean underGear = topMenu || !showInputsPill || btnInputs.getVisibility() != View.VISIBLE;
        View anchor = findViewById(underGear ? R.id.btnSettings : R.id.btnInputs);
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);

        // Compact: as wide as the Inputs pill (a touch wider so "HDMI 1" fits), hanging right below it.
        int width = Math.max(anchor.getWidth(), (int) (150 * density));
        final PopupWindow popup = glassPopup(panel, width);

        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        // inputs_connected_only: ports without a connected device and the AV jacks fold behind a "More inputs" row.
        boolean connectedOnly = inputsConnectedOnly;
        List<View> folded = new ArrayList<>();
        boolean sawNonHdmi = false;
        // An explicit root URI asks the Live TV app to leave any HDMI source selected by its own UI.
        boolean rootChannel = TvContract.Channels.CONTENT_URI.toString().equals(liveTvInputId);
        String tunerId = null;
        boolean tunerIsHw = false;
        boolean tunerIsAnalog = false;
        if (tim != null) {
            List<TvInputInfo> inputs = new ArrayList<>(tim.getTvInputList());
            // HDMI ports first in port order, then AV and the rest.
            Collections.sort(inputs, (a, b) -> {
                boolean ha = a.getType() == TvInputInfo.TYPE_HDMI, hb = b.getType() == TvInputInfo.TYPE_HDMI;
                if (ha != hb) return ha ? -1 : 1;
                return String.valueOf(a.loadLabel(this)).compareToIgnoreCase(String.valueOf(b.loadLabel(this)));
            });
            // An HDMI-CEC device (an Apple TV, a soundbar) gets an input of its own whose parent is the
            // port it sits on, so the port and the device would each get a row (Vestel MT7332: "HDMI 1"
            // and "HDMI Apple TV"). The device takes its port's row instead, and a bare port is listed
            // only when nothing on it speaks CEC.
            Set<String> inputIds = new HashSet<>();
            for (TvInputInfo info : inputs) inputIds.add(info.getId());
            Map<String, List<TvInputInfo>> cecDevices = new HashMap<>();
            for (TvInputInfo info : inputs) {
                String parent = info.getParentId();
                if (parent == null || !inputIds.contains(parent)) continue;
                if (!info.isPassthroughInput() || info.isHidden(this)) continue;
                List<TvInputInfo> onPort = cecDevices.get(parent);
                if (onPort == null) cecDevices.put(parent, onPort = new ArrayList<>());
                onPort.add(info);
            }
            // Some TVs (Sony) report every HDMI port as connected whether or not anything is plugged in,
            // so drop the HDMI status then. A TV with every port really in use loses it too.
            int hdmiPorts = 0, hdmiConnected = 0;
            for (TvInputInfo info : inputs) {
                if (!info.isPassthroughInput() || info.getType() != TvInputInfo.TYPE_HDMI) continue;
                if (info.getParentId() != null && inputIds.contains(info.getParentId())) continue;
                hdmiPorts++;
                if (tim.getInputState(info.getId()) == TvInputManager.INPUT_STATE_CONNECTED) hdmiConnected++;
            }
            // inputs_cec_state_only: the TV puts port states on the wrong port (TCL UnionTV, Android 9), so
            // ports show none, and a CEC device row shows its own state, which the CEC bus keeps right.
            boolean hdmiStateBogus = inputsCecStateOnly || (hdmiPorts > 1 && hdmiConnected == hdmiPorts);
            for (TvInputInfo info : inputs) {
                if (info.getType() == TvInputInfo.TYPE_TUNER
                        && (info.getServiceInfo().applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (liveTvInputId.isEmpty() || rootChannel || liveTvInputId.equals(info.getId()))) {
                    // Prefer a hardware tuner: the framework names those ".../HW<n>". System apps such as
                    // AirPlay also register software inputs of type TUNER and may sort first (seen on TCL G05).
                    // Among tuners of the same kind, skip an analog input when another is present.
                    // MediaTek names them AnalogInputService and TunerInputService; alphabetical order
                    // would pick the analog one, and Live TV then opens a dead ATV source.
                    boolean hw = info.getId().matches(".*/HW\\d+$");
                    boolean analog = info.getId().toLowerCase(Locale.ROOT).contains("analog");
                    boolean better = tunerId == null
                            || (hw && !tunerIsHw)
                            || (hw == tunerIsHw && tunerIsAnalog && !analog)
                            || (hw == tunerIsHw && analog == tunerIsAnalog
                                    && info.getId().compareTo(tunerId) < 0);
                    if (better) {
                        tunerId = info.getId();
                        tunerIsHw = hw;
                        tunerIsAnalog = analog;
                    }
                }
                // Inputs hidden in the TV's Settings > Inputs stay out of the menu too.
                if (!info.isPassthroughInput() || info.isHidden(this)) continue;
                // input_sources can leave out ports the board reports but the set does not have ("HW8=-").
                if (Integer.valueOf(-1).equals(mappedSource(info.getId()))) continue;
                // A CEC device's row is added with its port, below.
                if (info.getParentId() != null && inputIds.contains(info.getParentId())) continue;
                CharSequence l = info.loadLabel(this);
                String label = l == null ? info.getId() : l.toString();
                boolean hdmi = info.getType() == TvInputInfo.TYPE_HDMI;
                if (hdmi && !label.toUpperCase(Locale.ROOT).contains("HDMI")) label = "HDMI " + label;
                CharSequence custom = InputNames.tidy(info.loadCustomLabel(this));
                boolean named = custom != null && custom.length() > 0 && !custom.toString().equals(label);
                if (!hdmi && rows.getChildCount() > 0 && !sawNonHdmi) {
                    View line = addSeparator(rows);
                    if (connectedOnly) fold(line, folded);
                }
                if (!hdmi) sawNonHdmi = true;
                List<TvInputInfo> devices = cecDevices.get(info.getId());
                if (devices != null) {
                    // "Apple TV · HDMI 1": the device's own name (or the one given to it or to its port in
                    // Settings > Inputs), then the port. Opening the device's input also makes it the CEC
                    // active source, which wakes it.
                    for (TvInputInfo device : devices) {
                        CharSequence name = InputNames.tidy(device.loadCustomLabel(this));
                        if (name == null || name.length() == 0) name = named ? custom : device.loadLabel(this);
                        String deviceLabel = name == null || name.length() == 0 ? label : name + " \u00B7 " + label;
                        final String deviceId = device.getId();
                        int state = hdmiStateBogus && !inputsCecStateOnly ? -1 : tim.getInputState(deviceId);
                        View row = addInputRow(rows, popup, R.drawable.ic_input, deviceLabel, state, () -> openInput(deviceId));
                        if (connectedOnly && InputFold.folds(true, state)) fold(row, folded);
                    }
                    continue;
                }
                // The name given in Settings > Inputs (e.g. "MacBook Pro") goes first, the port after it.
                if (named) label = custom + " \u00B7 " + label;
                final String id = info.getId();
                // Analog AV jacks have no hotplug detection, and some TVs report them as always connected
                // (TCL Smart TV Pro G03 says "Connected" with nothing plugged in), so AV rows show no state.
                int state = !hdmi || hdmiStateBogus ? -1 : tim.getInputState(id);
                View row = addInputRow(rows, popup, hdmi ? R.drawable.ic_input : R.drawable.ic_av, label, state,
                        () -> openInput(id));
                if (connectedOnly && InputFold.folds(hdmi, state)) fold(row, folded);
            }
        }
        if (!folded.isEmpty()) {
            View more = getLayoutInflater().inflate(R.layout.item_input, rows, false);
            ((ImageView) more.findViewById(R.id.icon)).setImageResource(R.drawable.ic_input);
            ((TextView) more.findViewById(R.id.title)).setText(R.string.more_inputs);
            more.findViewById(R.id.status).setVisibility(View.GONE);
            more.findViewById(R.id.dot).setVisibility(View.GONE);
            more.setOnClickListener(v -> {
                for (View f : folded) f.setVisibility(View.VISIBLE);
                rows.removeView(more);
                for (View f : folded) {
                    if (f.isFocusable()) { f.requestFocus(); break; }
                }
            });
            rows.addView(more);
        }
        // Coocaa OS registers nothing with TvInputManager; com.skyworth.tv lists its sources instead.
        if (rows.getChildCount() == 0) {
            for (CoocaaSources.Source s : coocaa) {
                int icon = "HDMI".equals(s.name) ? R.drawable.ic_input
                        : "VOD".equals(s.name) ? R.drawable.ic_livetv : R.drawable.ic_av;
                addInputRow(rows, popup, icon, s.label, -1, () -> {
                    if (!CoocaaSources.open(this, s)) {
                        Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
        // Nothing to list where there is no TvInputManager: the TV's own source panel switches inputs.
        if (rows.getChildCount() == 0 && !sourcePanelService.isEmpty()) {
            addInputRow(rows, popup, R.drawable.ic_input, getString(R.string.inputs), -1, this::openSourcePanel);
        }
        Intent liveTv = liveTvIntent();
        if (liveTv != null && tunerId != null) {
            // Tune that input only when the Live TV package itself handles the URI.
            // The unrestricted input player also resolves it (that is how HDMI opens), but on the
            // AIWA AI PONT SA that player stays black, and the Live TV package does not handle the
            // URI at all, which used to toast "Not available on this TV". Keep the leanback activity
            // then: it is the same path as the Live TV tile. Do not drop the package restriction.
            // An explicit tuner uses its channel collection (e.g. DVB-S rather than DVB-T/C).
            // Keep the legacy passthrough route for automatic selection: some OEM players need it.
            // If the configured input is absent, tunerId stays null and the app opens normally.
            boolean configured = !liveTvInputId.isEmpty() && !rootChannel;
            Intent tuned = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(configured ? TvContract.buildChannelsUriForInput(tunerId)
                                    : TvContract.buildChannelUriForPassthroughInput(tunerId),
                            configured ? TvContract.Channels.CONTENT_TYPE : TvContract.Channels.CONTENT_ITEM_TYPE)
                    .setPackage(liveTvPkg);
            ComponentName handler = tuned.resolveActivity(getPackageManager());
            if (handler != null) {
                // On some MediaTek sets the tuner passthrough URI leaves the app's HDMI source selected.
                // The stock launcher addresses the same activity with the root channel URI instead (#1941).
                liveTv = rootChannel
                        ? new Intent(Intent.ACTION_VIEW).setData(TvContract.Channels.CONTENT_URI).setComponent(handler)
                        : tuned;
            }
        }
        if (liveTv != null) {
            if (rows.getChildCount() > 0) addSeparator(rows);
            final Intent liveTvIntent = liveTv;
            addInputRow(rows, popup, R.drawable.ic_livetv, getString(R.string.live_tv), -1, () -> open(liveTvIntent));
        }
        if (rows.getChildCount() == 0) {
            Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_SHORT).show();
            return;
        }

        // Fit the widest row: TVs that report a status on every port (Sony) would otherwise squeeze the names out.
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max(width, Math.min(panel.getMeasuredWidth(), (int) (360 * density))));

        int alignment = getResources().getBoolean(R.bool.rtl_menu_bar) != underGear ? Gravity.END : Gravity.START;
        dropIn(popup, panel, anchor, alignment);
        for (int i = 0; i < rows.getChildCount(); i++) {
            View child = rows.getChildAt(i);
            if (child.getVisibility() == View.VISIBLE && child.isFocusable()) { child.requestFocus(); break; }
        }
    }

    private static void fold(View view, List<View> folded) {
        view.setVisibility(View.GONE);
        folded.add(view);
    }

    private PopupWindow glassPopup(View panel, int width) {
        final PopupWindow popup = new PopupWindow(panel, width, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));   // needed for Back to dismiss
        popup.setOutsideTouchable(true);
        popup.setAnimationStyle(0);
        popup.setElevation(0f);
        popup.setOnDismissListener(() -> {
            if (openPopup == popup) openPopup = null;
        });
        openPopup = popup;
        return popup;
    }

    /** Drop in: fade and unfold from the top edge, hanging under the anchor pill. */
    private void dropIn(PopupWindow popup, View panel, View anchor, int gravity) {
        panel.setAlpha(0f);
        panel.setPivotY(0f);
        panel.setScaleY(0.92f);
        panel.setTranslationY(-8 * density);
        popup.showAsDropDown(anchor, 0, (int) (10 * density), gravity);
        panel.animate().alpha(1f).scaleY(1f).translationY(0f).setDuration(reducedMotion ? Motion.REDUCED_MS : 220)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    private View addSeparator(LinearLayout rows) {
        View line = new View(this);
        line.setBackgroundColor(0x1FFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) density);
        int m = (int) (6 * density), h = (int) (12 * density);
        lp.setMargins(h, m, h, m);
        rows.addView(line, lp);
        return line;
    }

    private View addInputRow(LinearLayout rows, PopupWindow popup, int iconRes, String title, int state, Runnable action) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconRes);
        ((TextView) row.findViewById(R.id.title)).setText(title);
        TextView status = row.findViewById(R.id.status);
        View dot = row.findViewById(R.id.dot);
        // This TV reports "standby" for every port whether or not something is plugged in, so only
        // definite states are shown.
        if (state == TvInputManager.INPUT_STATE_CONNECTED) {
            status.setText(R.string.connected);
            dot.setVisibility(View.VISIBLE);
        } else if (state == TvInputManager.INPUT_STATE_DISCONNECTED) {
            status.setText(R.string.not_connected);
            dot.setVisibility(View.GONE);
        } else {
            status.setVisibility(View.GONE);
            dot.setVisibility(View.GONE);
        }
        row.setOnClickListener(v -> {
            popup.dismiss();
            action.run();
        });
        rows.addView(row);
        return row;
    }

    // ---- custom: gear menu and now-playing pill ------------------------------------------------------

    /** The gear opens two rows: Home settings (this launcher's) and TV settings (the system's). */
    private void showGearMenu() {
        View anchor = findViewById(R.id.btnSettings);
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        PopupWindow popup = glassPopup(panel, (int) (320 * density));
        addMenuRow(rows, popup, R.drawable.ic_home_settings_pill, getString(R.string.gear_home_settings),
                getString(R.string.gear_home_settings_hint),
                () -> startActivityForResult(new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST));
        addMenuRow(rows, popup, R.drawable.ic_settings, getString(R.string.tv_settings),
                getString(R.string.tv_settings_hint),
                () -> open(systemIntent(Settings.ACTION_SETTINGS)));
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max((int) (320 * density), panel.getMeasuredWidth()));
        dropIn(popup, panel, anchor, getResources().getBoolean(R.bool.rtl_menu_bar) ? Gravity.START : Gravity.END);
        rows.getChildAt(0).requestFocus();
    }

    private void addMenuRow(LinearLayout rows, PopupWindow popup, int iconRes, String title, String subtitle, Runnable action) {
        View row = getLayoutInflater().inflate(R.layout.item_menu_row, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconRes);
        ((TextView) row.findViewById(R.id.title)).setText(title);
        ((TextView) row.findViewById(R.id.subtitle)).setText(subtitle);
        row.setOnClickListener(v -> {
            popup.dismiss();
            action.run();
        });
        rows.addView(row);
    }

    /** 3:07, or 1:02:09 for an hour or more. */
    private static String mediaTime(long ms) {
        long total = Math.max(0, ms) / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long sec = total % 60;
        return h > 0 ? String.format(java.util.Locale.ROOT, "%d:%02d:%02d", h, m, sec)
                : String.format(java.util.Locale.ROOT, "%d:%02d", m, sec);
    }

    /** Wires the "Now playing" pill in the header: cover, title and artist, equalizer, progress and the three buttons. */
    private void setupMediaPill() {
        View pill = findViewById(R.id.mediaPill);
        if (pill == null) return;
        if (!getResources().getBoolean(R.bool.media_pill)) {
            pill.setVisibility(View.GONE);
            return;
        }
        mediaPillView = pill;
        TextView title = findViewById(R.id.mediaTitle);
        EqualizerView equalizer = findViewById(R.id.mediaEqualizer);
        equalizer.setReducedMotion(reducedMotion);
        android.widget.ProgressBar progress = findViewById(R.id.mediaProgress);
        View progressRow = findViewById(R.id.mediaProgressRow);
        TextView timeView = findViewById(R.id.mediaTime);
        ImageView play = findViewById(R.id.mediaPlay);
        ImageView art = findViewById(R.id.mediaIcon);
        // Round cover: the outline clips the picture to a circle, like the holder behind it.
        art.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View view, android.graphics.Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        art.setClipToOutline(true);
        final Bitmap[] shownArt = {null};
        final int notePadding = Math.round(10 * density);
        title.setSelected(true);   // starts the marquee
        final boolean[] noAccess = {false};
        pill.setVisibility(View.VISIBLE);
        nowPlaying = new NowPlaying(this, new NowPlaying.Callback() {
            @Override
            public void onNowPlaying(CharSequence songTitle, CharSequence artist, boolean playing) {
                noAccess[0] = false;
                cpTitle = songTitle; cpArtist = artist; cpPlaying = playing;
                if (cpRefresh != null) cpRefresh.run();
                title.setText(TextUtils.isEmpty(artist) ? songTitle : songTitle + " - " + artist);
                equalizer.setPlaying(playing);
                play.setImageResource(playing ? R.drawable.ic_media_pause : R.drawable.ic_media_play);
                play.setContentDescription(getString(playing ? R.string.media_pause : R.string.media_play));
                pill.setVisibility(View.VISIBLE);
            }

            @Override
            public void onArt(Bitmap cover) {
                if (cover != cpArt) { cpAccent = cover == null ? 0 : accentOf(cover); applyPillAccent(pill); }
                cpArt = cover;
                if (cpRefresh != null) cpRefresh.run();
                if (cover == shownArt[0]) return;
                shownArt[0] = cover;
                if (cover != null) {
                    art.setPadding(0, 0, 0, 0);
                    art.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    art.setImageBitmap(cover);
                } else {
                    art.setPadding(notePadding, notePadding, notePadding, notePadding);
                    art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    art.setImageResource(R.drawable.ic_music);
                }
            }

            @Override
            public void onNothing() {
                noAccess[0] = false;
                onArt(null);
                title.setText(R.string.media_nothing);
                equalizer.setPlaying(false);
                progressRow.setVisibility(View.GONE);
                play.setImageResource(R.drawable.ic_media_play);
                pill.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNoAccess() {
                noAccess[0] = true;
                onArt(null);
                title.setText(R.string.media_enable_access);
                equalizer.setPlaying(false);
                progressRow.setVisibility(View.GONE);
                play.setImageResource(R.drawable.ic_media_play);
                pill.setVisibility(View.VISIBLE);
            }
        });
        mediaTick = new Runnable() {
            @Override
            public void run() {
                if (cpTick != null) cpTick.run();
                pill.postDelayed(this, 1000);
            }
        };
        findViewById(R.id.mediaPrev).setOnClickListener(v -> nowPlaying.previous());
        play.setOnClickListener(v -> {
            if (noAccess[0]) {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (RuntimeException e) {
                    Toast.makeText(this, R.string.media_enable_access, Toast.LENGTH_LONG).show();
                }
            } else {
                nowPlaying.togglePlay();
            }
        });
        findViewById(R.id.mediaNext).setOnClickListener(v -> nowPlaying.next());
    }

    // ---- launcher settings and module cards -------------------------------------------------------

    /** top_menu: the gear's dropdown, standing in for the Inputs, Wi-Fi and Settings pills. */
    // ---- cover colour, icon glow, tilt ------------------------------------------------------------

    /** Launcher settings' night mode: 0 off, 1 auto (9 pm to 7 am), 2 always. */
    private boolean nightOn() {
        int mode = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getInt("night_mode", 0);
        if (mode == 2) return true;
        if (mode != 1) return false;
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return hour >= 21 || hour < 7;
    }

    /** Night mode: a soft dark veil over Home, harder dimming of bright tiles, softer whites in the panel. */
    private void applyNight() {
        boolean night = nightOn();
        View content = findViewById(android.R.id.content);
        if (content instanceof android.widget.FrameLayout) {
            ((android.widget.FrameLayout) content).setForeground(night ? new ColorDrawable(0x3A000000) : null);
        }
        if (night != AppAdapter.night) {
            AppAdapter.night = night;
            if (adapter != null) adapter.notifyDataSetChanged();
        }
    }

    private int cpWhite() { return nightOn() ? 0xB8E6E6E8 : 0xE6F2F2F4; }

    private float cpShine = -1f;
    private android.animation.ValueAnimator cpShineAnim;
    private View cpMusicCardView;
    private CharSequence cpShineTitle;

    private void startShine() {
        if (cpShineAnim != null) cpShineAnim.cancel();
        cpShineAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
        cpShineAnim.setDuration(1100);
        cpShineAnim.addUpdateListener(a -> {
            cpShine = (float) a.getAnimatedValue();
            if (cpMusicCardView != null) cpMusicCardView.invalidate();
        });
        cpShineAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                cpShine = -1f;
                if (cpMusicCardView != null) cpMusicCardView.invalidate();
            }
        });
        cpShineAnim.start();
    }

    private int cpAccent;   // opaque colour taken from the cover now playing, 0 = none
    private float prevTileX = Float.NaN, prevTileY;
    private int fxPosition = -1;
    private View iconGlow;
    /** Control-panel switch: tint the bottom glow with the focused icon's colour (default on). */
    private boolean glowEnabled = true;
    private android.graphics.drawable.GradientDrawable glowDrawable;
    private android.animation.ValueAnimator glowAnim;
    private int glowColor;
    private long lastGlowAt;
    private final java.util.WeakHashMap<android.graphics.drawable.Drawable, Integer> glowAccents = new java.util.WeakHashMap<>();

    /** A lively colour for a picture: saturation-weighted average, 0 for greys (white or black logos). */
    static int accentOf(Bitmap src) {
        if (src == null || src.getWidth() == 0 || src.getHeight() == 0) return 0;
        Bitmap b = Bitmap.createScaledBitmap(src, 16, 16, true);
        float[] hsv = new float[3];
        double r = 0, g = 0, bl = 0, wsum = 0;
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                int c = b.getPixel(x, y);
                if (android.graphics.Color.alpha(c) < 128) continue;
                android.graphics.Color.colorToHSV(c, hsv);
                double w = hsv[1] * hsv[2] + 0.02;
                r += android.graphics.Color.red(c) * w;
                g += android.graphics.Color.green(c) * w;
                bl += android.graphics.Color.blue(c) * w;
                wsum += w;
            }
        }
        if (b != src) b.recycle();
        if (wsum == 0) return 0;
        android.graphics.Color.colorToHSV(android.graphics.Color.rgb((int) (r / wsum), (int) (g / wsum), (int) (bl / wsum)), hsv);
        if (hsv[1] < 0.12f) return 0;
        hsv[1] = Math.max(0.5f, hsv[1]);
        hsv[2] = Math.min(0.95f, Math.max(0.55f, hsv[2]));
        return android.graphics.Color.HSVToColor(hsv);
    }

    private static int shade(int rgb, float f, int alpha) {
        return android.graphics.Color.argb(alpha, (int) (android.graphics.Color.red(rgb) * f),
                (int) (android.graphics.Color.green(rgb) * f), (int) (android.graphics.Color.blue(rgb) * f));
    }

    private static int mixWhite(int rgb) {
        return android.graphics.Color.rgb((android.graphics.Color.red(rgb) + 255) / 2,
                (android.graphics.Color.green(rgb) + 255) / 2, (android.graphics.Color.blue(rgb) + 255) / 2);
    }

    /** The wallpaper picture's own colour (0 for a video, or a grey picture): what the panel and pill wear without a cover. */
    private int wallpaperAccent() { return wallpaperPlayer == null ? 0 : wallpaperPlayer.accent(); }

    /** Fill of the panel's glass: the wallpaper's colour, darkened; the usual grey when there is none. */
    private int panelFill() { int a = wallpaperAccent(); return 0xCC2C2C2E; }

    private int cpTint() { return 0xE61C1C1E; }

    /** The music pill takes the cover's colour; without a cover it goes back to its grey glass. */
    private void applyPillAccent(View pill) {
        android.graphics.drawable.Drawable bg = pill.getBackground();
        if (!(bg instanceof android.graphics.drawable.GradientDrawable)) return;
        android.graphics.drawable.GradientDrawable g = (android.graphics.drawable.GradientDrawable) bg.mutate();
        g.setColors(new int[]{0xD91C1C1E, 0xD91C1C1E});
    }

    private void setupIconGlow() {
        glowDrawable = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0, 0});
        iconGlow = new View(this);
        iconGlow.setBackground(glowDrawable);
        iconGlow.setClickable(false);
        iconGlow.setFocusable(false);
        iconGlow.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        View dim = findViewById(R.id.wallpaperDim);
        root.addView(iconGlow, dim == null ? 0 : root.indexOfChild(dim) + 1,
                new android.widget.FrameLayout.LayoutParams(-1, -1));
    }

    private void setGlow(int rgb) {
        if (glowDrawable == null) return;
        if (!glowEnabled) rgb = 0;
        final int target = rgb == 0 ? (glowColor & 0x00FFFFFF) : (0x5A000000 | (rgb & 0x00FFFFFF));
        if (target == glowColor && (glowAnim == null || !glowAnim.isRunning())) return;
        if (glowAnim != null) glowAnim.cancel();
        long now = SystemClock.uptimeMillis();
        boolean rapid = now - lastGlowAt < 220;   // key held down: change colour at once, no animation per step
        lastGlowAt = now;
        if (reducedMotion || rapid) { applyGlow(target); return; }
        glowAnim = android.animation.ValueAnimator.ofObject(new android.animation.ArgbEvaluator(), glowColor, target);
        glowAnim.setDuration(380);
        glowAnim.addUpdateListener(a -> applyGlow((Integer) a.getAnimatedValue()));
        glowAnim.start();
    }

    private void applyGlow(int argb) {
        glowColor = argb;
        glowDrawable.setColors(new int[]{argb, argb & 0x00FFFFFF});
    }

    private static ImageView firstImage(View v) {
        if (v instanceof ImageView && ((ImageView) v).getDrawable() != null && v.getWidth() > 0) return (ImageView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                ImageView f = firstImage(g.getChildAt(i));
                if (f != null) return f;
            }
        }
        return null;
    }

    private static int accentOfDrawable(android.graphics.drawable.Drawable d) {
        if (d instanceof android.graphics.drawable.BitmapDrawable) return accentOf(((android.graphics.drawable.BitmapDrawable) d).getBitmap());
        Bitmap bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888);
        Rect old = d.copyBounds();
        d.setBounds(0, 0, 32, 32);
        d.draw(new android.graphics.Canvas(bmp));
        d.setBounds(old);
        int c = accentOf(bmp);
        bmp.recycle();
        return c;
    }

    /** Soft highlight that slides across a tile the opposite way to its tilt, like light catching glass, then fades. */
    private long lastSheenAt;
    private android.animation.ValueAnimator sheenAnim;

    private void cardSheen(final View card, float ry, float rx) {
        long now = SystemClock.uptimeMillis();
        if (now - lastSheenAt < 260) return;   // holding a direction key: skip it, keep the scroll light
        lastSheenAt = now;
        if (sheenAnim != null) sheenAnim.cancel();
        final android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setGradientType(android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT);
        g.setColors(new int[]{0x66FFFFFF, 0x00FFFFFF});
        g.setGradientRadius(Math.max(card.getWidth(), card.getHeight()) * 0.7f);
        g.setCornerRadius(AppAdapter.cornerRadius(card.getWidth(), density));
        g.setBounds(0, 0, card.getWidth(), card.getHeight());
        final float fx0 = 0.5f - ry / 8f * 0.45f, fy0 = 0.5f + rx / 8f * 0.45f;
        card.getOverlay().add(g);
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
        sheenAnim = va;
        va.setDuration(520);
        va.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            g.setGradientCenter(fx0 + (0.5f - fx0) * t, fy0 + (0.5f - fy0) * t);
            g.setAlpha((int) (255 * Math.sin(Math.PI * t)));
        });
        va.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator an) { card.getOverlay().remove(g); }
        });
        va.start();
    }

    /** Called when a Home tile takes focus: soft click, a little tilt towards the direction of travel, glow in the icon's colour. */
    private void tileFocusEffects(int position, View card, Rect r) {
        float cx = r.exactCenterX(), cy = r.exactCenterY();
        if (position != fxPosition) {
            if (!Float.isNaN(prevTileX)) {
                SoftSounds.play(this);
                if (!reducedMotion && card.getWidth() > 0 && card.getHeight() > 0) {
                    float ry = Math.max(-1f, Math.min(1f, (cx - prevTileX) / card.getWidth())) * 8f;
                    float rx = -Math.max(-1f, Math.min(1f, (cy - prevTileY) / card.getHeight())) * 8f;
                    if (ry != 0f || rx != 0f) {
                        card.setCameraDistance(9000f * density);
                        android.animation.ObjectAnimator tilt = android.animation.ObjectAnimator.ofPropertyValuesHolder(card,
                                android.animation.PropertyValuesHolder.ofFloat(View.ROTATION_Y, ry, 0f),
                                android.animation.PropertyValuesHolder.ofFloat(View.ROTATION_X, rx, 0f));
                        tilt.setDuration(420);
                        tilt.setInterpolator(new android.view.animation.DecelerateInterpolator());
                        tilt.start();
                        cardSheen(card, ry, rx);
                    }
                }
            }
            fxPosition = position;
            prevTileX = cx;
            prevTileY = cy;
        }
        try {
            ImageView iv = firstImage(card);
            int accent = 0;
            if (iv != null && glowEnabled) {
                android.graphics.drawable.Drawable d = iv.getDrawable();
                Integer cached = glowAccents.get(d);
                if (cached == null) {
                    cached = accentOfDrawable(d);
                    glowAccents.put(d, cached);
                }
                accent = cached;
            }
            setGlow(accent);
        } catch (RuntimeException e) {
            setGlow(0);
        }
    }

    // ---- control panel (opened by the top-bar grid button) ----------------------------------------

    private CharSequence cpTitle, cpArtist;
    private boolean cpPlaying;
    private Bitmap cpArt;
    private Runnable cpRefresh, cpTick;

    private int dp(int v) { return Math.round(v * density); }

    private void showControlPanel() {
        final android.app.Dialog dlg = new android.app.Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final boolean blur = WindowBlur.supported(this);
        final int u = dp(56), g = dp(8);
        final int full = 4 * u + 3 * g;
        LinearLayout col = cpBox(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(12), dp(12), dp(12));
        android.graphics.drawable.Drawable pic = cpPanelPicture();
        cpPic = pic != null;
        cpTileFill = cpPic ? 0x30000000 : 0xF0121214;
        cpCircleOff = cpPic ? 0x40000000 : 0xFF2C2C2E;
        cpIconOff = cpPic ? 0x55FFFFFF : 0xFF3A3A3C;
        col.setBackground(pic != null ? pic
                : cpGlass(blur ? 0xCC1A1A1E : 0xF01C1C1E, blur ? 0xD90C0C0F : 0xF40C0C0F, 30, true));

        // Music card, as wide as the panel.
        cpMusicAction = () -> { dlg.dismiss(); root.post(this::showMusicMode); };
        col.addView(cpMusicCard(), new LinearLayout.LayoutParams(full, -2));

        // Row: wallpaper | sleep timer | ambient.
        LinearLayout rowA = cpBox(LinearLayout.HORIZONTAL);
        rowA.addView(cpCircleBtn(R.drawable.ic_cp_image, false, u, () -> { dlg.dismiss(); cpPickWallpaper(); }), new LinearLayout.LayoutParams(u, u));
        final CpWide sleep = new CpWide(R.drawable.ic_cp_timer, getString(R.string.cp_sleep), sleepLabel(), HomeKeyService.sleepMinutesLeft() > 0);
        sleep.setOnClickListener(v -> {
            int[] opts = {0, 15, 30, 60, 90};
            int cur = HomeKeyService.sleepMinutesLeft() > 0 ? sleepMinutes : 0;
            int i = 0;
            while (i < opts.length - 1 && opts[i] != cur) i++;
            int next = opts[(i + 1) % opts.length];
            if (!HomeKeyService.setSleepTimer(next)) {
                Toast.makeText(this, R.string.cp_sleep_service, Toast.LENGTH_LONG).show();
                return;
            }
            sleepMinutes = next;
            sleep.set(sleepLabel(), next > 0);
            if (next > 0) Toast.makeText(this, getString(R.string.cp_sleep_set, next), Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(2 * u + g, u);
        wlp.setMargins(g, 0, g, 0);
        rowA.addView(sleep, wlp);
        rowA.addView(cpCircleBtn(R.drawable.ic_cp_ambient, false, u, () -> { dlg.dismiss(); root.post(this::enterAmbientMode); }), new LinearLayout.LayoutParams(u, u));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(full, u);
        alp.topMargin = g;
        col.addView(rowA, alp);

        // Row: brightness | connections | volume.
        LinearLayout mid = cpBox(LinearLayout.HORIZONTAL);
        CpSlider bright = new CpSlider(R.drawable.ic_cp_brightness, HomeKeyService.dimLevel(this), pct -> {
            if (!HomeKeyService.setDim(this, pct)) {
                Toast.makeText(this, R.string.cp_dim_service, Toast.LENGTH_LONG).show();
                return;
            }
            if (pct == 0) {
                Toast.makeText(this, R.string.cp_audio_only_hint, Toast.LENGTH_LONG).show();
                dlg.dismiss();
            }
        });
        int midH = 2 * u + g;
        mid.addView(bright, new LinearLayout.LayoutParams(u, midH));
        LinearLayout cluster = cpBox(LinearLayout.VERTICAL);
        cluster.setGravity(Gravity.CENTER);
        cluster.setBackground(cpGlass(cpTileFill, cpTileFill, 28, false));
        boolean wifiOn = false, btOn = false;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiOn = wm != null && wm.isWifiEnabled();
            android.bluetooth.BluetoothAdapter ad = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            btOn = ad != null && ad.isEnabled();
        } catch (RuntimeException ignored) { }
        int cs = dp(52);
        LinearLayout c1 = cpBox(LinearLayout.HORIZONTAL);
        LinearLayout c2 = cpBox(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(cs, cs);
        cl.setMargins(dp(4), dp(4), dp(4), dp(4));
        c1.addView(cpCircleBtn(R.drawable.ic_cp_wifi, wifiOn, cs, () -> { dlg.dismiss(); openNetworkPill(); }), cl);
        c1.addView(cpCircleBtn(R.drawable.ic_cp_bluetooth, btOn, cs, () -> { dlg.dismiss(); root.post(this::showBtAudio); }), new LinearLayout.LayoutParams(cl));
        c2.addView(cpCircleBtn(R.drawable.ic_cp_qr, false, cs, () -> { dlg.dismiss(); root.post(this::showWifiQr); }), new LinearLayout.LayoutParams(cl));
        c2.addView(cpCircleBtn(R.drawable.ic_settings, false, cs, () -> {
            dlg.dismiss();
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch (RuntimeException ignored) { }
        }), new LinearLayout.LayoutParams(cl));
        cluster.addView(c1);
        cluster.addView(c2);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(2 * u + g, midH);
        clp.setMargins(g, 0, g, 0);
        mid.addView(cluster, clp);
        final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        final int vmax = am == null ? 1 : Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int vcur = am == null ? 0 : am.getStreamVolume(AudioManager.STREAM_MUSIC);
        CpSlider vol = new CpSlider(R.drawable.ic_cp_volume, Math.round(vcur * 100f / vmax), pct -> {
            if (am != null) {
                try { am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(pct * vmax / 100f), 0); } catch (RuntimeException ignored) { }
            }
        });
        mid.addView(vol, new LinearLayout.LayoutParams(u, midH));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(full, midH);
        mlp.topMargin = g;
        col.addView(mid, mlp);

        // Row: reorder | glow | power.
        LinearLayout rowB = cpBox(LinearLayout.HORIZONTAL);
        rowB.addView(cpCircleBtn(R.drawable.ic_swap_vert, false, u, () -> { dlg.dismiss(); root.post(this::toggleReorder); }), new LinearLayout.LayoutParams(u, u));
        final CpWide glow = new CpWide(R.drawable.ic_cp_display, getString(R.string.cp_lbl_glow),
                getString(glowEnabled ? R.string.cp_state_on : R.string.cp_state_off), glowEnabled);
        glow.setOnClickListener(v -> {
            glowEnabled = !glowEnabled;
            getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).edit().putBoolean("color_glow", glowEnabled).apply();
            glow.set(getString(glowEnabled ? R.string.cp_state_on : R.string.cp_state_off), glowEnabled);
            if (!glowEnabled) setGlow(0);
        });
        boolean power = HomeKeyService.canOpenPowerMenu();
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(power ? 2 * u + g : 3 * u + 2 * g, u);
        glp.setMargins(g, 0, power ? g : 0, 0);
        rowB.addView(glow, glp);
        if (power) rowB.addView(cpCircleBtn(R.drawable.ic_cp_power, false, u, () -> { dlg.dismiss(); HomeKeyService.openPowerMenu(); }), new LinearLayout.LayoutParams(u, u));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(full, u);
        blp.topMargin = g;
        col.addView(rowB, blp);

        // Bottom tile: the app library.
        CpWide lib = new CpWide(R.drawable.ic_cp_apps, getString(R.string.cp_lbl_library), null, false);
        lib.setOnClickListener(v -> { dlg.dismiss(); onLibraryRequested(); libraryFromTopBar = true; });
        LinearLayout.LayoutParams libp = new LinearLayout.LayoutParams(full, u);
        libp.topMargin = g;
        col.addView(lib, libp);

        dlg.setOnDismissListener(d -> { cpRefresh = null; cpTick = null; });
        dlg.setContentView(col);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            w.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.TOP | Gravity.END);
            w.getAttributes().x = dp(28);
            w.getAttributes().y = dp(76);
            w.getAttributes().dimAmount = 0.3f;
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowBlur.apply(w.getAttributes(), dp(20));
        }
        dlg.show();
        if (cpMusicPlay != null) cpMusicPlay.requestFocus();
        // Opens the way iOS's Control Center does: it grows out of its top corner while it fades in.
        try {
            if (!reducedMotion) {
                col.setAlpha(0f);
                col.setScaleX(0.88f);
                col.setScaleY(0.88f);
                col.post(() -> {
                    col.setPivotX(col.getWidth());
                    col.setPivotY(0f);
                    col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
                });
                col.postDelayed(() -> col.setAlpha(1f), 600);
            }
        } catch (RuntimeException ignored) {
            col.setAlpha(1f);
        }
    }

    /** Black card with a glass bevel: a bright edge whose glow fades inwards, like a raised pane of glass. */
    private android.graphics.drawable.Drawable cpBevel(int radiusDp) {
        final float rad = dp(radiusDp);
        final int n = 14;
        final float step = Math.max(1f, dp(1) * 0.9f);
        final int centre = cpPic ? 0xE6000000 : 0xFF000000;
        // Launcher settings: rim tinted by the cover now playing (off by default).
        final boolean tint = cpAccent != 0 && getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean("music_card_tint", false);
        final int rimTop = tint ? 0xFF000000 | (mixWhite(cpAccent) & 0xFFFFFF) : 0xFFFFFFFF;
        final int rimBottom = tint ? 0xB3000000 | (mixWhite(cpAccent) & 0xFFFFFF) : 0xB3FFFFFF;
        return new android.graphics.drawable.Drawable() {
            private final android.graphics.Paint fill = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private final android.graphics.Paint rim = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private final android.graphics.RectF r = new android.graphics.RectF();
            private final android.graphics.Paint shinePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private float shaderH = -1f;
            @Override public void draw(android.graphics.Canvas c) {
                android.graphics.Rect b = getBounds();
                if (b.isEmpty()) return;
                fill.setColor(centre);
                r.set(b);
                c.drawRoundRect(r, rad, rad, fill);
                if (shaderH != b.height()) {
                    // The top edge catches the most light, the bottom a little less.
                    rim.setShader(new android.graphics.LinearGradient(0, b.top, 0, b.bottom, rimTop, rimBottom,
                            android.graphics.Shader.TileMode.CLAMP));
                    shaderH = b.height();
                }
                rim.setStyle(android.graphics.Paint.Style.STROKE);
                rim.setStrokeWidth(step * 1.3f);
                for (int i = 0; i < n; i++) {
                    float inset = step * (i + 0.5f);
                    float fall = 1f - i / (float) n;
                    rim.setAlpha(Math.round(215 * fall * fall));
                    r.set(b);
                    r.inset(inset, inset);
                    float rr = Math.max(0f, rad - inset);
                    c.drawRoundRect(r, rr, rr, rim);
                }
                // The crisp outer edge.
                rim.setAlpha(255);
                rim.setStrokeWidth(Math.max(1f, dp(1) * 1.4f));
                r.set(b);
                r.inset(dp(1) * 0.7f, dp(1) * 0.7f);
                c.drawRoundRect(r, rad, rad, rim);
                // Shine: a bright band sweeping along the edge when the song changes (settings: music_card_shine).
                float sh = cpShine;
                if (sh >= 0f && sh <= 1f) {
                    float half = dp(46), cx = b.left - half + (b.width() + 2 * half) * sh;
                    shinePaint.setShader(new android.graphics.LinearGradient(cx - half, 0, cx + half, 0,
                            new int[]{0x00FFFFFF, 0xFFFFFFFF, 0x00FFFFFF}, null, android.graphics.Shader.TileMode.CLAMP));
                    shinePaint.setStyle(android.graphics.Paint.Style.STROKE);
                    shinePaint.setStrokeWidth(dp(3));
                    r.set(b);
                    r.inset(dp(2), dp(2));
                    c.drawRoundRect(r, rad, rad, shinePaint);
                }
            }
            @Override public void setAlpha(int a) { }
            @Override public void setColorFilter(android.graphics.ColorFilter cf) { }
            @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
        };
    }

    /** Settings' panel_bg: a wallpaper picture behind the panel's tiles, darkened; null keeps the glass. */
    private android.graphics.drawable.Drawable cpPanelPicture() {
        try {
            String name = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getString("panel_bg", null);
            File dir = Config.dir(this);
            if (name == null || dir == null) return null;
            File f = new File(new File(dir, "panel_bg"), name);
            if (!f.isFile()) f = new File(new File(dir, "wallpapers"), name);
            if (!f.isFile()) f = new File(dir, name);
            if (!f.isFile()) return null;
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (o.outWidth > 0 && o.outWidth / (s * 2) >= dp(300) * 2) s *= 2;
            o = new android.graphics.BitmapFactory.Options();
            o.inSampleSize = s;
            final Bitmap bmp = android.graphics.BitmapFactory.decodeFile(f.getPath(), o);
            if (bmp == null) return null;
            final float radius = dp(30);
            final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            paint.setShader(new android.graphics.BitmapShader(bmp, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP));
            // Dark pictures vanish behind the tiles: lift them (x1.3 + a little offset).
            // Launcher settings' "Panel background brightness" (percent, default 130).
            final float g = Math.max(0.5f, Math.min(2f, getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getInt("panel_bg_brightness", 130) / 100f) * (nightOn() ? 0.75f : 1f));
            final float off = g >= 1.25f ? 6f : 0f;
            paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(new float[]{
                    g, 0, 0, 0, off, 0, g, 0, 0, off, 0, 0, g, 0, off, 0, 0, 0, 1, 0}));
            android.graphics.drawable.Drawable picture = new android.graphics.drawable.Drawable() {
                @Override public void draw(android.graphics.Canvas c) {
                    android.graphics.Rect b = getBounds();
                    if (b.isEmpty()) return;
                    float sc = Math.max(b.width() / (float) bmp.getWidth(), b.height() / (float) bmp.getHeight());
                    android.graphics.Matrix mx = new android.graphics.Matrix();
                    mx.setScale(sc, sc);
                    mx.postTranslate(b.left + (b.width() - bmp.getWidth() * sc) / 2f, b.top + (b.height() - bmp.getHeight() * sc) / 2f);
                    paint.getShader().setLocalMatrix(mx);
                    c.drawRoundRect(new android.graphics.RectF(b), radius, radius, paint);
                }
                @Override public void setAlpha(int a) { paint.setAlpha(a); }
                @Override public void setColorFilter(android.graphics.ColorFilter cf) { }
                @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
            };
            android.graphics.drawable.GradientDrawable scrim = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x26000000, 0x59000000});
            scrim.setCornerRadius(radius);
            scrim.setStroke(Math.max(1, dp(1)), 0x38FFFFFF);
            return new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{picture, scrim});
        } catch (RuntimeException | OutOfMemoryError e) {
            return null;
        }
    }

    private LinearLayout.LayoutParams cpLp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    /** A box that lets focused (scaled up) children grow past its edge. */
    private LinearLayout cpBox(int orientation) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(orientation);
        l.setClipChildren(false);
        l.setClipToPadding(false);
        return l;
    }

    /** The panel's focus animation: the tile grows a little and the sound plays. */
    private void cpFocusAnim(View v) {
        v.setOnFocusChangeListener((x, f) -> {
            if (f) SoftSounds.play(this);
            float s = f ? 1.06f : 1f;
            x.animate().scaleX(s).scaleY(s).setDuration(reducedMotion ? 0 : 140).start();
        });
    }

    /** Idle: the tile's colour with a thin light edge. Focused: a white ring, a gap, then the tile. */
    private android.graphics.drawable.StateListDrawable cpTileBg(int fill, int radiusDp, boolean oval) {
        android.graphics.drawable.GradientDrawable idle = new android.graphics.drawable.GradientDrawable();
        android.graphics.drawable.GradientDrawable body = new android.graphics.drawable.GradientDrawable();
        android.graphics.drawable.GradientDrawable ring = new android.graphics.drawable.GradientDrawable();
        for (android.graphics.drawable.GradientDrawable d : new android.graphics.drawable.GradientDrawable[]{idle, body, ring}) {
            if (oval) d.setShape(android.graphics.drawable.GradientDrawable.OVAL); else d.setCornerRadius(dp(radiusDp));
        }
        idle.setColor(fill);
        idle.setStroke(Math.max(1, dp(1)), 0x22FFFFFF);
        body.setColor(fill);
        ring.setColor(0);
        ring.setStroke(dp(2), 0xFFFFFFFF);
        android.graphics.drawable.LayerDrawable foc = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{ring, body});
        foc.setLayerInset(1, dp(4), dp(4), dp(4), dp(4));
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, foc);
        sl.addState(new int[]{}, idle);
        return sl;
    }

    /** iOS round button: white with a dark icon when on, dark with a white icon when off. */
    private View cpCircleBtn(int icon, boolean on, int size, Runnable action) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setImageTintList(android.content.res.ColorStateList.valueOf(on ? 0xFF000000 : 0xFFFFFFFF));
        int pad = Math.round(size * 0.27f);
        b.setPadding(pad, pad, pad, pad);
        b.setBackground(cpTileBg(on ? cpWhite() : cpCircleOff, 0, true));
        b.setFocusable(true);
        b.setClickable(true);
        cpFocusAnim(b);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    /** iOS wide tile: icon circle (white when on) with a title and an optional state line. */
    private final class CpWide extends LinearLayout {
        private final ImageView ic;
        private final TextView sub;

        CpWide(int icon, String title, String state, boolean on) {
            super(MainActivity.this);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setClipChildren(false);
            setPadding(dp(10), 0, dp(8), 0);
            setBackground(cpTileBg(cpTileFill, 24, false));
            setFocusable(true);
            setClickable(true);
            cpFocusAnim(this);
            ic = new ImageView(MainActivity.this);
            ic.setImageResource(icon);
            ic.setPadding(dp(7), dp(7), dp(7), dp(7));
            addView(ic, new LayoutParams(dp(32), dp(32)));
            LinearLayout tx = cpBox(VERTICAL);
            tx.setPadding(dp(8), 0, 0, 0);
            TextView t1 = new TextView(MainActivity.this);
            t1.setText(title);
            t1.setTextColor(0xFFFFFFFF);
            t1.setTextSize(12);
            t1.setTypeface(null, android.graphics.Typeface.BOLD);
            t1.setSingleLine(true);
            t1.setEllipsize(TextUtils.TruncateAt.END);
            sub = new TextView(MainActivity.this);
            sub.setTextColor(0xFF98989F);
            sub.setTextSize(10);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(t1);
            tx.addView(sub);
            addView(tx, new LayoutParams(0, -2, 1f));
            set(state, on);
        }

        void set(String state, boolean on) {
            sub.setText(state == null ? "" : state);
            sub.setVisibility(TextUtils.isEmpty(state) ? View.GONE : View.VISIBLE);
            ic.setBackground(cpBg(on ? cpWhite() : cpIconOff, 0, 30));
            ic.setImageTintList(android.content.res.ColorStateList.valueOf(on ? 0xFF000000 : 0xFFFFFFFF));
        }
    }

    /** Vertical iOS slider: Up/Down change the level by 10 % while it has focus. */
    private final class CpSlider extends View {
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path clip = new android.graphics.Path();
        private final android.graphics.RectF rf = new android.graphics.RectF();
        private final android.graphics.drawable.Drawable icon;
        private final java.util.function.IntConsumer onChange;
        private int level;

        CpSlider(int iconRes, int level, java.util.function.IntConsumer onChange) {
            super(MainActivity.this);
            this.level = Math.max(0, Math.min(100, Math.round(level / 10f) * 10));
            this.onChange = onChange;
            this.icon = getDrawable(iconRes).mutate();
            setFocusable(true);
            setClickable(true);
            setOnFocusChangeListener((v, f) -> {
                if (f) SoftSounds.play(MainActivity.this);
                float s = f ? 1.04f : 1f;
                v.animate().scaleX(s).scaleY(s).setDuration(reducedMotion ? 0 : 140).start();
                invalidate();
            });
        }

        @Override public boolean onKeyDown(int keyCode, KeyEvent e) {
            int step = keyCode == KeyEvent.KEYCODE_DPAD_UP ? 10 : keyCode == KeyEvent.KEYCODE_DPAD_DOWN ? -10 : 0;
            if (step == 0) return super.onKeyDown(keyCode, e);
            int next = Math.max(0, Math.min(100, level + step));
            if (next != level) { level = next; onChange.accept(level); invalidate(); }
            return true;
        }

        @Override protected void onDraw(android.graphics.Canvas c) {
            boolean foc = isFocused();
            float in = foc ? dp(4) : 0f;
            float w = getWidth(), h = getHeight(), r = dp(22);
            if (foc) {
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                p.setColor(0xF2FFFFFF);
                rf.set(dp(1), dp(1), w - dp(1), h - dp(1));
                c.drawRoundRect(rf, r, r, p);
            }
            rf.set(in, in, w - in, h - in);
            float rr = r - in;
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(cpPic ? 0x4D000000 : 0xE61C1C1E);   // dark track
            c.drawRoundRect(rf, rr, rr, p);
            clip.reset();
            clip.addRoundRect(rf, rr, rr, android.graphics.Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            p.setColor(cpWhite());   // soft white fill: pure white blinds on a TV
            c.drawRect(rf.left, rf.top + rf.height() * (1f - level / 100f), rf.right, rf.bottom, p);
            c.restore();
            p.setColor(0xFF98989F);
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            p.setTextSize(dp(11));
            if (level < 85) c.drawText(level + "%", w / 2f, rf.top + dp(18), p);
            int is = dp(22), ix = (int) (w - is) / 2, iy = (int) (rf.bottom - is - dp(10));
            icon.setBounds(ix, iy, ix + is, iy + is);
            icon.setTint(level >= 15 ? 0xFF000000 : 0xFFFFFFFF);
            icon.draw(c);
        }
    }

    // ---- music mode, ambient mode, colour keys, screen margin ----------------------------------------------

    private View uiColumn;
    private LiquidGlass liquid;
    private final android.graphics.RectF liquidDock = new android.graphics.RectF();
    private final android.graphics.RectF liquidBar = new android.graphics.RectF();
    private final android.graphics.RectF liquidSlab = new android.graphics.RectF();
    private final Rect liquidTmp = new Rect();
    private View topButtonsView;
    private final ViewTreeObserver.OnPreDrawListener liquidPreDraw = () -> {
        updateLiquid();
        return true;
    };
    private boolean ambientMode;
    private final java.util.List<View> ambientHidden = new java.util.ArrayList<>();
    private final java.util.List<Float> ambientAlphas = new java.util.ArrayList<>();

    /**
     * Liquid glass (Android 13+, a picture wallpaper, Launcher settings' switch, on by default): the picture bends
     * under the dock, the top pills and the moving glass slab. Without any of those it does nothing at all.
     */
    private void setupLiquidGlass() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || wallpaperPlayer == null) return;
        if (!getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean(LiquidGlass.KEY, true)) return;
        ImageView picture = wallpaperPlayer.imageView();
        if (picture == null || picture.getParent() == null || reducedMotion) return;
        try {
            liquid = new LiquidGlass(picture, density);
        } catch (RuntimeException | LinkageError e) {
            liquid = null;   // the TV's shader compiler said no: Home looks as it always did
            return;
        }
        root.getViewTreeObserver().addOnPreDrawListener(liquidPreDraw);
    }

    /** Each frame: where the glass regions are now, in the wallpaper's pixels. Does nothing unless one moved. */
    private void updateLiquid() {
        if (liquid == null) return;
        try {
            boolean ui = !ambientMode && (uiColumn == null || uiColumn.getAlpha() > 0.05f);
            if (ui) dockRegion(liquidDock); else liquidDock.setEmpty();
            if (ui && !topBarHidden) barRegion(liquidBar); else liquidBar.setEmpty();
            liquidSlab.setEmpty();
            if (ui && glass != null && glass.getVisibility() == View.VISIBLE && glass.getAlpha() > 0.05f
                    && glass.getWidth() > 0) {
                float inset = 6f * density;
                liquidSlab.set(glass.getX() + inset, glass.getY() + inset,
                        glass.getX() + glass.getWidth() - inset, glass.getY() + glass.getHeight() - inset);
            }
            liquid.update(liquidDock, liquidBar, liquidSlab);
        } catch (RuntimeException e) {
            // A cosmetic effect never takes Home down: drop it for this run.
            liquid.clear();
            root.getViewTreeObserver().removeOnPreDrawListener(liquidPreDraw);
            liquid = null;
        }
    }

    /** The dock row's tiles, as one rectangle with a little air around it. */
    private void dockRegion(android.graphics.RectF out) {
        out.setEmpty();
        boolean any = false;
        for (int i = 0; i < grid.getChildCount(); i++) {
            View child = grid.getChildAt(i);
            int pos = grid.getChildAdapterPosition(child);
            if (pos < 0 || pos >= COLUMNS) continue;
            View card = child.findViewById(R.id.card);
            if (card == null || card.getWidth() <= 0 || card.getVisibility() != View.VISIBLE) continue;
            liquidTmp.set(0, 0, card.getWidth(), card.getHeight());
            root.offsetDescendantRectToMyCoords(card, liquidTmp);
            if (!any) {
                out.set(liquidTmp.left, liquidTmp.top, liquidTmp.right, liquidTmp.bottom);
                any = true;
            } else {
                out.union(liquidTmp.left, liquidTmp.top, liquidTmp.right, liquidTmp.bottom);
            }
        }
        if (any) {
            float air = 12f * density;
            out.inset(-air, -air);
        }
    }

    private void barRegion(android.graphics.RectF out) {
        out.setEmpty();
        if (topButtonsView == null) topButtonsView = findViewById(R.id.topButtons);
        View bar = topButtonsView;
        if (bar == null || bar.getVisibility() != View.VISIBLE || bar.getAlpha() < 0.05f || bar.getWidth() <= 0) return;
        liquidTmp.set(0, 0, bar.getWidth(), bar.getHeight());
        root.offsetDescendantRectToMyCoords(bar, liquidTmp);
        out.set(liquidTmp.left, liquidTmp.top, liquidTmp.right, liquidTmp.bottom);
    }

    /** The screensaver Home starts: the photos when Launcher settings say so, else the clock. */
    private Class<?> saverClass() {
        return getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean("saver_photos", false)
                ? PhotoSaverActivity.class : ClockActivity.class;
    }

    /** Launcher settings' screen margin: some TVs crop the edges, so the whole interface is inset a few percent. */
    private void applySafeMargin() {
        if (uiColumn == null) uiColumn = findViewById(R.id.uiColumn);
        if (uiColumn == null) return;
        int pct = Math.max(0, Math.min(8, getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getInt("safe_margin", 0)));
        android.view.ViewGroup.LayoutParams raw = uiColumn.getLayoutParams();
        if (!(raw instanceof android.view.ViewGroup.MarginLayoutParams)) return;
        android.view.ViewGroup.MarginLayoutParams lp = (android.view.ViewGroup.MarginLayoutParams) raw;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int mx = dm.widthPixels * pct / 100;
        int my = dm.heightPixels * pct / 100;
        if (lp.leftMargin == mx && lp.rightMargin == mx && lp.topMargin == my && lp.bottomMargin == my) return;
        lp.setMargins(mx, my, mx, my);
        uiColumn.setLayoutParams(lp);
    }

    /** Remote's red, green, yellow and blue keys: panel, library, Wi-Fi QR and reorder. Acts when the key is released. */
    private boolean colorKeys(KeyEvent event) {
        int code = event.getKeyCode();
        if (code < KeyEvent.KEYCODE_PROG_RED || code > KeyEvent.KEYCODE_PROG_BLUE) return false;
        if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) {
            if (code == KeyEvent.KEYCODE_PROG_RED) showControlPanel();
            else if (code == KeyEvent.KEYCODE_PROG_GREEN) onLibraryRequested();
            else if (code == KeyEvent.KEYCODE_PROG_YELLOW) showWifiQr();
            else toggleReorder();
        }
        return true;
    }

    private void fadeOutForAmbient(View v) {
        if (v == null) return;
        ambientHidden.add(v);
        ambientAlphas.add(v.getAlpha());
        v.animate().cancel();
        v.animate().alpha(0f).setDuration(reducedMotion ? Motion.REDUCED_MS : 500).start();
    }

    /** Ambient mode: the wallpaper, the clock and the date stay (same brightness); everything else fades out. Any key brings it back. */
    private void enterAmbientMode() {
        if (ambientMode) return;
        ambientMode = true;
        ambientHidden.clear();
        ambientAlphas.clear();
        if (uiColumn == null) uiColumn = findViewById(R.id.uiColumn);
        if (uiColumn instanceof ViewGroup) {
            ViewGroup ui = (ViewGroup) uiColumn;
            for (int i = 0; i < ui.getChildCount(); i++) {
                View child = ui.getChildAt(i);
                if (i == 0 && child instanceof ViewGroup) {
                    // The top row: keep the clock block, hide the pills.
                    ViewGroup row = (ViewGroup) child;
                    for (int j = 0; j < row.getChildCount(); j++) {
                        if (row.getChildAt(j).getId() != R.id.leftBlock) fadeOutForAmbient(row.getChildAt(j));
                    }
                } else {
                    fadeOutForAmbient(child);
                }
            }
        }
        int[] ids = {R.id.glass, R.id.hero, R.id.heroScrim, R.id.heroArt, R.id.ambient, R.id.racePanel};
        for (int id : ids) fadeOutForAmbient(findViewById(id));
        fadeOutForAmbient(iconGlow);
    }

    private void exitAmbientMode() {
        if (!ambientMode) return;
        ambientMode = false;
        for (int i = 0; i < ambientHidden.size(); i++) {
            View v = ambientHidden.get(i);
            v.animate().cancel();
            v.animate().alpha(ambientAlphas.get(i)).setDuration(reducedMotion ? Motion.REDUCED_MS : 350).start();
        }
        ambientHidden.clear();
        ambientAlphas.clear();
        showTopBar();
    }

    /**
     * Music mode: the cover fills the screen, softened the way the top shelf's artwork is (a few pixels stretched
     * over the screen), with the sharp cover, title, artist, equalizer and progress in the middle. OK plays or
     * pauses, Left and Right change track, Back closes it. Fed by the same NowPlaying as the panel's music card.
     */
    private boolean musicModeOpen;

    private static String fmtTime(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private void showMusicMode() {
        if (nowPlaying == null) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
            return;
        }
        musicModeOpen = true;
        root.removeCallbacks(showIdleClock);   // the dialog eats the keys, so Home would never see "activity"
        final android.content.SharedPreferences sp = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        final boolean[] lyricsOn = {sp.getBoolean("music_lyrics", true)};
        int hDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        final int W = dp(Math.max(220, Math.min(380, Math.round(hDp * 0.60f))));   // cover size follows the screen height
        final long[] lastSkip = {0}, lastSeek = {0}, seekPos = {-1}, off = {0}, pausedSince = {0};
        final boolean[] holdSeeked = {false};
        final android.app.Dialog d = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        try {
            d.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (RuntimeException ignored) { }
        final android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
        frame.setBackgroundColor(0xFF000000);

        // Backdrop: the cover shrunk to a few pixels, stretched, blurred (Android 12+) and slowly drifting.
        final ImageView backdrop = new ImageView(this);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setScaleX(1.45f);
        backdrop.setScaleY(1.45f);
        try {
            android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();
            cm.setSaturation(1.3f);
            cm.postConcat(new android.graphics.ColorMatrix(new float[]{
                    0.7f, 0, 0, 0, 0,  0, 0.7f, 0, 0, 0,  0, 0, 0.7f, 0, 0,  0, 0, 0, 1, 0}));
            backdrop.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                backdrop.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(
                        90f, 90f, android.graphics.Shader.TileMode.CLAMP));
            }
        } catch (RuntimeException ignored) { }
        frame.addView(backdrop, new android.widget.FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000, 0x88000000, 0xCC000000}));
        frame.addView(shade, new android.widget.FrameLayout.LayoutParams(-1, -1));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(80), dp(30), dp(64), dp(30));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER_HORIZONTAL);
        final ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setBackground(cpBg(0xFF1C1C1E, 0, 22));
        art.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        art.setClipToOutline(true);
        left.addView(art, new LinearLayout.LayoutParams(W, W));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        final TextView t1 = new TextView(this);
        t1.setTextColor(0xFFFFFFFF);
        t1.setTextSize(27);
        t1.setTypeface(null, android.graphics.Typeface.BOLD);
        t1.setSingleLine(true);
        t1.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(t1, new LinearLayout.LayoutParams(-1, -2));
        final TextView t2 = new TextView(this);
        t2.setTextColor(0xAAFFFFFF);
        t2.setTextSize(19);
        t2.setSingleLine(true);
        t2.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(t2, new LinearLayout.LayoutParams(-1, -2));
        titleRow.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        final EqualizerView eq = new EqualizerView(this);
        eq.setReducedMotion(reducedMotion);
        titleRow.addView(eq, new LinearLayout.LayoutParams(dp(34), dp(26)));
        LinearLayout.LayoutParams ltr = new LinearLayout.LayoutParams(W, -2);
        ltr.topMargin = dp(18);
        left.addView(titleRow, ltr);

        final android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(1000);
        final android.graphics.drawable.GradientDrawable fillShape = cpBg(0xFFFFFFFF, 0, 3);
        android.graphics.drawable.LayerDrawable pd = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{cpBg(0x44FFFFFF, 0, 3),
                        new android.graphics.drawable.ClipDrawable(fillShape, Gravity.START,
                                android.graphics.drawable.ClipDrawable.HORIZONTAL)});
        pd.setId(0, android.R.id.background);
        pd.setId(1, android.R.id.progress);
        pb.setProgressDrawable(pd);
        LinearLayout.LayoutParams lpb = new LinearLayout.LayoutParams(W, dp(6));
        lpb.topMargin = dp(16);
        left.addView(pb, lpb);
        LinearLayout times = new LinearLayout(this);
        final TextView tNow = new TextView(this);
        final TextView tLeft = new TextView(this);
        for (TextView tv : new TextView[]{tNow, tLeft}) { tv.setTextColor(0x99FFFFFF); tv.setTextSize(13); }
        tLeft.setGravity(Gravity.END);
        times.addView(tNow, new LinearLayout.LayoutParams(0, -2, 1f));
        times.addView(tLeft, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lti = new LinearLayout.LayoutParams(W, -2);
        lti.topMargin = dp(6);
        left.addView(times, lti);
        row.addView(left, new LinearLayout.LayoutParams(-2, -2));

        final LyricsView lyrics = new LyricsView(this, reducedMotion);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(0, -1, 1f);
        ll.leftMargin = dp(96);
        row.addView(lyrics, ll);
        lyrics.setVisibility(lyricsOn[0] ? View.VISIBLE : View.GONE);
        frame.addView(row, new android.widget.FrameLayout.LayoutParams(-1, -1));

        final TextView syncTv = new TextView(this);
        syncTv.setTextColor(0xFFFFFFFF);
        syncTv.setTextSize(15);
        syncTv.setPadding(dp(14), dp(7), dp(14), dp(7));
        syncTv.setBackground(cpBg(0x88000000, 0, 16));
        syncTv.setAlpha(0f);
        android.widget.FrameLayout.LayoutParams lsy = new android.widget.FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.END);
        lsy.topMargin = dp(28);
        lsy.rightMargin = dp(40);
        frame.addView(syncTv, lsy);
        final Bitmap[] softened = {null};
        final String[] lyricsKey = {null};
        final boolean[] wasPlaying = {true};
        final Runnable[] loadLyrics = {null};
        loadLyrics[0] = () -> {
            if (!lyricsOn[0] || TextUtils.isEmpty(cpTitle)) return;
            final String key = cpTitle + "|" + (cpArtist == null ? "" : cpArtist);
            if (key.equals(lyricsKey[0])) return;
            lyricsKey[0] = key;
            off[0] = sp.getLong("lyr_off_" + key.hashCode(), 0L);
            lyrics.showMessage(getString(R.string.music_lyrics_loading));
            LyricsFetcher.fetch(cpTitle.toString(), cpArtist == null ? "" : cpArtist.toString(),
                    nowPlaying == null ? -1 : nowPlaying.durationMs(), key, (k, res) -> {
                        if (!k.equals(lyricsKey[0]) || !d.isShowing()) return;
                        if (res == null) lyrics.showMessage(getString(R.string.music_lyrics_none));
                        else lyrics.setLyrics(res);
                    });
        };
        cpRefresh = () -> {
            t1.setText(TextUtils.isEmpty(cpTitle) ? getString(R.string.media_nothing) : cpTitle);
            t2.setText(cpArtist == null ? "" : cpArtist);
            eq.setPlaying(cpPlaying);
            if (cpPlaying != wasPlaying[0] || art.getScaleX() == 1f && !cpPlaying) {
                wasPlaying[0] = cpPlaying;
                float sc = cpPlaying ? 1f : 0.88f;
                art.animate().scaleX(sc).scaleY(sc).setDuration(reducedMotion ? 0 : 400).start();
            }
            fillShape.setColor(cpAccent == 0 ? 0xFFFFFFFF : mixWhite(cpAccent));
            if (cpArt != null) {
                art.setPadding(0, 0, 0, 0);
                art.clearColorFilter();
                art.setImageBitmap(cpArt);
                if (softened[0] == null || cpArt != softened[0]) {
                    softened[0] = cpArt;
                    try {
                        int px = android.os.Build.VERSION.SDK_INT >= 31 ? 48 : 16;
                        backdrop.setImageBitmap(Bitmap.createScaledBitmap(cpArt, px, px, true));
                    } catch (RuntimeException ignored) {
                        backdrop.setImageDrawable(null);
                    }
                }
            } else {
                softened[0] = null;
                art.setPadding(dp(100), dp(100), dp(100), dp(100));
                art.setColorFilter(0xFFFFFFFF);
                art.setImageResource(R.drawable.ic_music);
                backdrop.setImageDrawable(null);
            }
            loadLyrics[0].run();
        };
        final boolean[] open = {true};
        final Runnable[] loop = {null};
        loop[0] = () -> {
            if (!open[0] || nowPlaying == null) return;
            long dur = nowPlaying.durationMs(), pos = nowPlaying.positionMs();
            boolean known = dur > 0 && pos >= 0;
            pb.setVisibility(known ? View.VISIBLE : View.INVISIBLE);
            tNow.setText(known ? fmtTime(pos) : "");
            tLeft.setText(known ? fmtTime(dur) : "");
            if (known) pb.setProgress((int) (pos * 1000 / dur));
            if (lyricsOn[0]) lyrics.update(pos < 0 ? pos : pos + off[0], dur);
            long nowT = android.os.SystemClock.uptimeMillis();
            if (cpPlaying) pausedSince[0] = 0;
            else if (pausedSince[0] == 0) pausedSince[0] = nowT;
            else if (nowT - pausedSince[0] > 600000L) { d.dismiss(); return; }   // paused 10 min: let the screensaver take over
            frame.postDelayed(loop[0], 250);
        };
        cpTick = () -> { };
        cpRefresh.run();
        loop[0].run();
        android.animation.ValueAnimator drift = null;
        if (!reducedMotion) {
            drift = android.animation.ValueAnimator.ofFloat(0f, 1f);
            drift.setDuration(40000);
            drift.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            drift.setRepeatMode(android.animation.ValueAnimator.REVERSE);
            drift.setInterpolator(new android.view.animation.LinearInterpolator());
            drift.addUpdateListener(a -> {
                float v = (float) a.getAnimatedValue();
                backdrop.setTranslationX((v - 0.5f) * dp(140));
                backdrop.setTranslationY((0.5f - v) * dp(70));
            });
            drift.start();
        }
        final android.animation.ValueAnimator driftRef = drift;
        d.setContentView(frame);
        d.setOnKeyListener((dialog, keyCode, event) -> {
            boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (down) d.dismiss();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                    || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (down && event.getRepeatCount() == 0) nowPlaying.togglePlay();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                // Tap = previous / next track (on release); hold = seek 10 s every 0.35 s.
                boolean goLeft = keyCode == KeyEvent.KEYCODE_DPAD_LEFT;
                if (down) {
                    if (event.getRepeatCount() == 0) {
                        holdSeeked[0] = false;
                        seekPos[0] = -1;
                    } else {
                        long t = android.os.SystemClock.uptimeMillis();
                        if (t - lastSeek[0] > 350) {
                            lastSeek[0] = t;
                            holdSeeked[0] = true;
                            if (seekPos[0] < 0) seekPos[0] = nowPlaying.positionMs();
                            if (seekPos[0] >= 0) {
                                long dur = nowPlaying.durationMs();
                                seekPos[0] = Math.max(0, seekPos[0] + (goLeft ? -10000 : 10000));
                                if (dur > 0) seekPos[0] = Math.min(seekPos[0], dur - 1000);
                                nowPlaying.seekTo(seekPos[0]);
                            }
                        }
                    }
                } else if (event.getAction() == KeyEvent.ACTION_UP && !holdSeeked[0] && !event.isCanceled()) {
                    long t = android.os.SystemClock.uptimeMillis();
                    if (t - lastSkip[0] > 900) {
                        lastSkip[0] = t;   // one tap = one track, even if the remote double-sends the key
                        if (goLeft) nowPlaying.previous(); else nowPlaying.next();
                    }
                }
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                // Lyrics hidden: Up shows them. Visible: Up / Down move the sync by 0.5 s; hold Up hides them.
                if (!down) return true;
                boolean up = keyCode == KeyEvent.KEYCODE_DPAD_UP;
                int rep = event.getRepeatCount();
                if (!lyricsOn[0]) {
                    if (up && rep == 0) {
                        lyricsOn[0] = true;
                        sp.edit().putBoolean("music_lyrics", true).apply();
                        lyrics.setVisibility(View.VISIBLE);
                        lyricsKey[0] = null;
                        loadLyrics[0].run();
                    }
                    return true;
                }
                if (up && rep == 1) {   // held: hide (and undo the step the first press made)
                    off[0] -= 500;
                    if (lyricsKey[0] != null) sp.edit().putLong("lyr_off_" + lyricsKey[0].hashCode(), off[0]).apply();
                    lyricsOn[0] = false;
                    sp.edit().putBoolean("music_lyrics", false).apply();
                    lyrics.setVisibility(View.GONE);
                    syncTv.animate().cancel();
                    syncTv.setAlpha(0f);
                    return true;
                }
                if (rep == 0) {
                    off[0] = Math.max(-15000L, Math.min(15000L, off[0] + (up ? 500 : -500)));
                    if (lyricsKey[0] != null) sp.edit().putLong("lyr_off_" + lyricsKey[0].hashCode(), off[0]).apply();
                    syncTv.setText(getString(R.string.music_lyrics_sync,
                            String.format(java.util.Locale.US, "%+.1f", off[0] / 1000.0)));
                    syncTv.animate().cancel();
                    syncTv.setAlpha(1f);
                    syncTv.animate().alpha(0f).setStartDelay(1400).setDuration(400).start();
                }
                return true;
            }
            return false;
        });
        d.setOnDismissListener(x -> {
            open[0] = false;
            musicModeOpen = false;
            frame.removeCallbacks(loop[0]);
            if (driftRef != null) driftRef.cancel();
            cpRefresh = null;
            cpTick = null;
            restartIdleClock();
        });
        frame.setAlpha(0f);
        d.show();
        frame.animate().alpha(1f).setDuration(reducedMotion ? Motion.REDUCED_MS : 450).start();
    }

    // ---- sleep timer (control panel); the countdown lives in HomeKeyService ------------------------------

    private int sleepMinutes;   // the option picked in the panel

    private String sleepLabel() {
        int left = HomeKeyService.sleepMinutesLeft();
        return left <= 0 ? getString(R.string.cp_sleep_off) : getString(R.string.cp_sleep_min, left);
    }

    /** Quick wallpaper switch: the theme's pictures, applied the same way the launcher settings do. */
    private void cpPickWallpaper() {
        File dir = Config.dir(this);
        final List<File> images = new ArrayList<>(WallpaperRotation.images(dir == null ? null : new File(dir, "wallpapers")));
        File single = dir == null ? null : new File(dir, Config.WALLPAPER_NAME);
        if (single != null && single.isFile()) images.add(0, single);
        if (images.isEmpty()) {
            startActivityForResult(new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST);
            return;
        }
        final android.content.SharedPreferences ch = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        String cur = ch.getString(Config.WALLPAPER_CHOICE_KEY, null);
        String[] labels = new String[images.size() + 1];
        int checked = "none".equals(cur) ? images.size() : -1;
        for (int i = 0; i < images.size(); i++) {
            labels[i] = images.get(i).getName();
            if (images.get(i).getName().equals(cur)) checked = i;
        }
        labels[images.size()] = getString(R.string.wallpaper_none);
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_label)
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    d.dismiss();
                    ch.edit().putString(Config.WALLPAPER_CHOICE_KEY, which == images.size() ? "none" : images.get(which).getName())
                            .putLong(Config.SETTINGS_REVISION_KEY, ch.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
                    settingsRevision = settingsRevision();
                    recreate();
                })
                .setNeutralButton(R.string.cp_more, (d, which) ->
                        startActivityForResult(new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private String cpNetworkLabel() {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null) return getString(R.string.cp_no_network);
            if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) {
                android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                String ssid = wm.getConnectionInfo() == null ? null : wm.getConnectionInfo().getSSID();
                if (ssid != null && !ssid.contains("unknown ssid")) return ssid.replace("\"", "");
                return getString(R.string.cp_connected);
            }
            return getString(R.string.cp_connected);
        } catch (RuntimeException e) {
            return getString(R.string.cp_connected);
        }
    }

    private TextView cpSub(View card) {
        return (TextView) ((LinearLayout) ((LinearLayout) card).getChildAt(1)).getChildAt(1);
    }

    private android.graphics.drawable.GradientDrawable cpBg(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    /** Translucent glass: a vertical sheen, a thin light edge and (lip) a darker rim under it for relief. */
    private android.graphics.drawable.Drawable cpGlass(int top, int bottom, int radiusDp, boolean lip) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), 0x38FFFFFF);
        if (!lip) return g;
        android.graphics.drawable.GradientDrawable base = new android.graphics.drawable.GradientDrawable();
        base.setColor(0x40000000);
        base.setCornerRadius(dp(radiusDp));
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{base, g});
        ld.setLayerInset(1, 0, 0, 0, Math.max(1, dp(2)));
        return ld;
    }

    /** The one focus highlight of the panel: a light fill and a clear white ring. */
    private android.graphics.drawable.GradientDrawable cpFocusRing(int radiusDp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0x40FFFFFF);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(2), 0xF2FFFFFF);
        return g;
    }

    /** iOS icon circle: grey, the same focused or not (the row carries the focus highlight). */
    private android.graphics.drawable.StateListDrawable cpCircle() {
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, cpBg(0xFF48484A, 0, 30));
        sl.addState(new int[]{}, cpBg(0xFF48484A, 0, 30));
        return sl;
    }

    private android.graphics.drawable.StateListDrawable cpFocusBg(int radiusDp) {
        return cpFocusBg(radiusDp, cpBg(panelFill(), 0, radiusDp));
    }

    private android.graphics.drawable.StateListDrawable cpFocusBg(int radiusDp, android.graphics.drawable.Drawable idle) {
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, cpFocusRing(radiusDp));
        sl.addState(new int[]{}, idle);
        return sl;
    }

    private android.content.res.ColorStateList cpInk(int focused, int idle) {
        return new android.content.res.ColorStateList(new int[][]{{android.R.attr.state_focused}, {}}, new int[]{focused, idle});
    }

    /** iOS-style tile: small coloured icon, name and (optionally) a value; turns white with dark text when focused. */
    private View cpTile(int icon, int circle, String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(11), dp(6), dp(8), dp(6));
        card.setFocusable(true);
        card.setClickable(true);
        card.setBackground(cpFocusBg(26));
        card.setOnFocusChangeListener((v, f) -> { if (f) SoftSounds.play(this); });
        ImageView ic = new ImageView(this);
        ic.setImageResource(icon);
        ic.setPadding(dp(6), dp(6), dp(6), dp(6));
        ic.setBackground(cpCircle());
        ic.setImageTintList(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        ic.setDuplicateParentStateEnabled(true);
        card.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(0, dp(4), 0, 0);
        tx.setDuplicateParentStateEnabled(true);
        TextView t1 = new TextView(this);
        t1.setText(title);
        t1.setTextColor(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        t1.setTextSize(12);
        t1.setTypeface(null, android.graphics.Typeface.BOLD);
        t1.setSingleLine(true);
        t1.setEllipsize(TextUtils.TruncateAt.END);
        t1.setDuplicateParentStateEnabled(true);
        TextView t2 = new TextView(this);
        t2.setText(subtitle == null ? "" : subtitle);
        t2.setTextColor(cpInk(0xCCFFFFFF, 0xB3FFFFFF));
        t2.setTextSize(10.5f);
        t2.setSingleLine(true);
        t2.setEllipsize(TextUtils.TruncateAt.END);
        t2.setDuplicateParentStateEnabled(true);
        if (subtitle == null) t2.setVisibility(View.GONE);
        tx.addView(t1);
        tx.addView(t2);
        card.addView(tx, new LinearLayout.LayoutParams(-1, -2));
        if (action != null) card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(100), dp(68));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        card.setLayoutParams(lp);
        return card;
    }

    /** Glass card: round icon on the left, title and subtitle on the right; content turns dark when the card is focused. */
    private View cpCard(int icon, int circle, String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), 0, dp(10), 0);
        card.setFocusable(true);
        card.setClickable(true);
        card.setBackground(cpFocusBg(28));
        card.setOnFocusChangeListener((v, f) -> { if (f) SoftSounds.play(this); });
        ImageView ic = new ImageView(this);
        ic.setImageResource(icon);
        ic.setPadding(dp(8), dp(8), dp(8), dp(8));
        ic.setBackground(cpCircle());
        ic.setImageTintList(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        ic.setDuplicateParentStateEnabled(true);
        card.addView(ic, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(12), 0, 0, 0);
        tx.setDuplicateParentStateEnabled(true);
        TextView t1 = new TextView(this);
        t1.setText(title);
        t1.setTextColor(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        t1.setTextSize(15);
        t1.setTypeface(null, android.graphics.Typeface.BOLD);
        t1.setSingleLine(true);
        t1.setDuplicateParentStateEnabled(true);
        TextView t2 = new TextView(this);
        t2.setText(subtitle);
        t2.setTextColor(cpInk(0xCCFFFFFF, 0xB3FFFFFF));
        t2.setTextSize(12);
        t2.setSingleLine(true);
        t2.setDuplicateParentStateEnabled(true);
        tx.addView(t1);
        tx.addView(t2);
        card.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        if (action != null) card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        card.setLayoutParams(lp);
        return card;
    }

    private String dimLabel() {
        int level = HomeKeyService.dimLevel(this);
        if (level <= 0) return getString(R.string.cp_audio_only);
        return level >= 100 ? getString(R.string.cp_brightness_full) : level + " %";
    }

    // ---- Bluetooth audio (panel): connect or disconnect a paired speaker or headphones --------------------

    private static final int REQUEST_BT_AUDIO = 2191;
    private android.bluetooth.BluetoothAdapter baAdapter;
    private android.bluetooth.BluetoothA2dp baA2dp;
    private android.app.AlertDialog baDialog;
    private LinearLayout baList;
    private TextView baStatus;
    private boolean baReceiving;
    private final java.util.Set<String> baPending = new java.util.HashSet<>();
    private final android.content.BroadcastReceiver baChanged = new android.content.BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { refreshBtAudio(); }
    };

    private void showBtAudio() {
        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {"android.permission.BLUETOOTH_CONNECT"}, REQUEST_BT_AUDIO);
            return;
        }
        android.bluetooth.BluetoothManager bm = (android.bluetooth.BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        baAdapter = bm == null ? null : bm.getAdapter();
        baStatus = new TextView(this);
        baStatus.setTextColor(0xFFB0B7C3);
        baStatus.setPadding(0, 0, 0, dp(12));
        baList = new LinearLayout(this);
        baList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0);
        box.setPadding(dp(24), dp(16), dp(24), dp(8));
        box.addView(baStatus);
        box.addView(baList);
        baDialog = new android.app.AlertDialog.Builder(this).setView(box)
                .setPositiveButton(R.string.wifi_qr_close, null)
                .create();
        baDialog.setOnDismissListener(d -> stopBtAudio());
        baDialog.show();
        startBtAudio();
    }

    private void startBtAudio() {
        if (baAdapter == null || !baAdapter.isEnabled()) {
            baStatus.setText(R.string.ba_off);
            return;
        }
        registerReceiver(baChanged, new IntentFilter(android.bluetooth.BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED));
        baReceiving = true;
        baAdapter.getProfileProxy(this, new android.bluetooth.BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, android.bluetooth.BluetoothProfile proxy) {
                baA2dp = (android.bluetooth.BluetoothA2dp) proxy;
                refreshBtAudio();
            }
            @Override public void onServiceDisconnected(int profile) {
                baA2dp = null;
            }
        }, android.bluetooth.BluetoothProfile.A2DP);
    }

    private void stopBtAudio() {
        if (baReceiving) {
            try {
                unregisterReceiver(baChanged);
            } catch (IllegalArgumentException ignored) {
            }
            baReceiving = false;
        }
        if (baA2dp != null && baAdapter != null) {
            baAdapter.closeProfileProxy(android.bluetooth.BluetoothProfile.A2DP, baA2dp);
        }
        baA2dp = null;
        baPending.clear();
    }

    /** Only runs after showBtAudio has checked Nearby devices on Android 12+. */
    @android.annotation.SuppressLint("MissingPermission")
    private void refreshBtAudio() {
        if (baDialog == null || !baDialog.isShowing() || baA2dp == null || baAdapter == null) return;
        int focus = 0;
        for (int i = 0; i < baList.getChildCount(); i++) if (baList.getChildAt(i).isFocused()) focus = i;
        baList.removeAllViews();
        java.util.Set<String> on = new java.util.HashSet<>();
        for (android.bluetooth.BluetoothDevice d : baA2dp.getConnectedDevices()) on.add(d.getAddress());
        for (final android.bluetooth.BluetoothDevice device : baAdapter.getBondedDevices()) {
            android.bluetooth.BluetoothClass cls = device.getBluetoothClass();
            boolean audio = cls == null   // unknown class: show it rather than hide a speaker
                    || cls.getMajorDeviceClass() == android.bluetooth.BluetoothClass.Device.Major.AUDIO_VIDEO
                    || cls.hasService(android.bluetooth.BluetoothClass.Service.AUDIO);
            if (!audio) continue;
            final String address = device.getAddress();
            final boolean connected = on.contains(address);
            String name = device.getName() == null ? address : device.getName();
            TextView row = new TextView(this);
            row.setText(name + "\n" + getString(baPending.contains(address) ? R.string.ba_working
                    : connected ? R.string.ba_connected : R.string.ba_not_connected));
            row.setTextSize(16);
            row.setTextColor(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
            row.setPadding(dp(14), dp(10), dp(14), dp(10));
            row.setFocusable(true);
            row.setClickable(true);
            row.setBackground(cpFocusBg(12));
            row.setOnClickListener(v -> toggleBtAudio(device, connected));
            baList.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        baStatus.setText(baList.getChildCount() == 0 ? R.string.ba_none : R.string.ba_hint);
        if (baList.getChildCount() > 0) baList.getChildAt(Math.min(focus, baList.getChildCount() - 1)).requestFocus();
    }

    private void toggleBtAudio(final android.bluetooth.BluetoothDevice device, boolean connected) {
        if (baA2dp == null || baPending.contains(device.getAddress())) return;
        boolean accepted;
        try {
            // Android's public API has neither call, so this uses the audio profile's own connect and disconnect.
            accepted = (Boolean) android.bluetooth.BluetoothA2dp.class
                    .getMethod(connected ? "disconnect" : "connect", android.bluetooth.BluetoothDevice.class)
                    .invoke(baA2dp, device);
        } catch (ReflectiveOperationException | SecurityException refused) {
            accepted = false;
        }
        if (!accepted) {
            baStatus.setText(R.string.ba_refused);
            return;
        }
        baPending.add(device.getAddress());
        refreshBtAudio();
        // A state change normally clears it; if none arrives (a speaker that is off), stop saying "working".
        handler.postDelayed(() -> {
            baPending.remove(device.getAddress());
            refreshBtAudio();
        }, 12000);
    }

    private static final int REQUEST_LOCATION = 2192;

    /** Android only gives the Wi-Fi network's name to apps with the location permission: ask once, so the pill can show it. */
    private void askLocationOnce() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 23) return;
            android.content.SharedPreferences sp = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
            if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == PackageManager.PERMISSION_GRANTED
                    || sp.getBoolean("asked_location", false)) return;
            sp.edit().putBoolean("asked_location", true).apply();
            requestPermissions(new String[] {"android.permission.ACCESS_FINE_LOCATION"}, REQUEST_LOCATION);
        } catch (RuntimeException ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == REQUEST_LOCATION) root.post(this::updateWifiLabel);
        if (code == REQUEST_BT_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) root.post(this::showBtAudio);
    }

    // ---- Wi-Fi QR for guests (panel) -----------------------------------------------------------------

    /** The name of the Wi-Fi the TV is on, or "" when Android does not give it (the password is never readable). */
    private String currentSsid() {
        try {
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            android.net.wifi.WifiInfo wi = wm.getConnectionInfo();
            String ssid = wi == null ? null : wi.getSSID();
            if (ssid != null && !ssid.contains("unknown ssid")) return ssid.replace("\"", "");
        } catch (RuntimeException ignored) {
        }
        return "";
    }

    private static String wifiEsc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '\\' || c == ';' || c == ',' || c == ':' || c == '"') b.append('\\');
            b.append(c);
        }
        return b.toString();
    }

    private static String wifiPayload(String ssid, String pass) {
        return pass.isEmpty() ? "WIFI:T:nopass;S:" + wifiEsc(ssid) + ";;"
                : "WIFI:T:WPA;S:" + wifiEsc(ssid) + ";P:" + wifiEsc(pass) + ";;";
    }

    /** Shows the saved network as a QR code a phone can scan to join; asks for the name and password the first time. */
    private void showWifiQr() {
        android.content.SharedPreferences sp = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        final String ssid = sp.getString("wifi_qr_ssid", "");
        if (ssid.isEmpty()) {
            editWifiQr();
            return;
        }
        boolean[][] grid = QrCode.encode(wifiPayload(ssid, sp.getString("wifi_qr_pass", "")));
        if (grid == null) {
            Toast.makeText(this, R.string.wifi_qr_toolong, Toast.LENGTH_LONG).show();
            editWifiQr();
            return;
        }
        int n = grid.length;
        int scale = Math.max(3, dp(200) / (n + 8));
        int px = (n + 8) * scale;   // 4 modules of white border on each side
        Bitmap bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(bmp);
        cv.drawColor(0xFFE9E9EC);   // a touch under pure white, still scans
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setColor(0xFF000000);
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                if (grid[y][x]) cv.drawRect((x + 4) * scale, (y + 4) * scale, (x + 5) * scale, (y + 5) * scale, paint);
            }
        }
        ImageView img = new ImageView(this);
        img.setImageBitmap(bmp);
        img.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16)); }
        });
        img.setClipToOutline(true);
        TextView label = new TextView(this);
        label.setText(getString(R.string.wifi_qr_scan, ssid));
        label.setGravity(Gravity.CENTER);
        label.setPadding(0, dp(12), 0, 0);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(16), dp(24), 0);
        box.addView(img, new LinearLayout.LayoutParams(px, px));
        box.addView(label);
        new android.app.AlertDialog.Builder(this).setView(box)
                .setPositiveButton(R.string.wifi_qr_close, null)
                .setNeutralButton(R.string.wifi_qr_edit, (d, w) -> editWifiQr())
                .show();
    }

    private void editWifiQr() {
        final android.content.SharedPreferences sp = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        String saved = sp.getString("wifi_qr_ssid", "");
        final android.widget.EditText name = new android.widget.EditText(this);
        name.setSingleLine();
        name.setHint(R.string.wifi_qr_name_hint);
        name.setText(saved.isEmpty() ? currentSsid() : saved);
        final android.widget.EditText pass = new android.widget.EditText(this);
        pass.setHint(R.string.wifi_qr_pass_hint);
        pass.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        pass.setText(sp.getString("wifi_qr_pass", ""));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(16), dp(24), 0);
        box.addView(name);
        box.addView(pass);
        new android.app.AlertDialog.Builder(this).setView(box)
                .setPositiveButton(R.string.wifi_qr_save, (d, w) -> {
                    String chosen = name.getText().toString().trim();
                    if (chosen.isEmpty()) return;
                    sp.edit().putString("wifi_qr_ssid", chosen).putString("wifi_qr_pass", pass.getText().toString()).apply();
                    root.post(this::showWifiQr);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Round icon-only button for the panel's bottom row; the circle turns white when focused. */
    private Runnable cpMusicAction;
    private View cpMusicArt;
    private View cpMusicPlay;
    /** Panel colours: near-black tiles on the glass; see-through frosted tiles when a picture is behind the panel. */
    private boolean cpPic;
    private int cpTileFill = 0xF0121214, cpCircleOff = 0xFF2C2C2E, cpIconOff = 0xFF3A3A3C;

    private TextView cpSection(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setAllCaps(true);
        t.setTextSize(11);
        t.setLetterSpacing(0.08f);
        t.setTextColor(0x99FFFFFF);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(dp(12), dp(10), 0, dp(2));
        return t;
    }

    /** A round button with its short name underneath; the round button is child 0. */
    private View cpTool(int icon, int label, Runnable action) {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        w.setGravity(Gravity.CENTER_HORIZONTAL);
        View b = cpRound(icon, getString(label), action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lp.setMargins(0, dp(4), 0, 0);
        w.addView(b, lp);
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(10.5f);
        t.setTextColor(0xCCFFFFFF);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2), dp(3), dp(2), dp(4));
        w.addView(t, new LinearLayout.LayoutParams(-1, -2));
        w.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        return w;
    }

    private View cpRound(int icon, String desc, Runnable action) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setImageTintList(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        b.setContentDescription(desc);
        b.setFocusable(true);
        b.setClickable(true);
        b.setBackground(cpFocusBg(22));
        b.setOnFocusChangeListener((v, f) -> { if (f) SoftSounds.play(this); });
        if (action != null) b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
        lp.setMargins(dp(3), dp(5), dp(3), dp(5));
        b.setLayoutParams(lp);
        return b;
    }

    private ImageView cpMiniBtn(int icon, Runnable action) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setImageTintList(cpInk(0xFFFFFFFF, 0xFFFFFFFF));
        b.setPadding(dp(5), dp(5), dp(5), dp(5));
        b.setFocusable(true);
        b.setClickable(true);
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, cpFocusRing(14));
        sl.addState(new int[]{}, cpBg(0, 0, 14));
        b.setBackground(sl);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(28), dp(28));
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        return b;
    }

    /** Tall music card: cover, transport buttons, title, artist and progress; fed by the same NowPlaying as the pill. */
    private View cpMusicCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        card.setBackground(cpBevel(26));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.StateListDrawable artBg = new android.graphics.drawable.StateListDrawable();
        artBg.addState(new int[]{android.R.attr.state_focused}, cpFocusRing(10));
        artBg.addState(new int[]{}, cpBg(0x33FFFFFF, 0, 10));
        art.setBackground(artBg);
        cpMusicArt = art;
        art.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        art.setClipToOutline(true);
        row.addView(art, new LinearLayout.LayoutParams(dp(44), dp(44)));
        View sp = new View(this);
        row.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
        final ImageView play = cpMiniBtn(R.drawable.ic_media_play, () -> nowPlaying.togglePlay());
        cpMusicPlay = play;
        row.addView(cpMiniBtn(R.drawable.ic_media_prev, () -> nowPlaying.previous()));
        row.addView(play);
        row.addView(cpMiniBtn(R.drawable.ic_media_next, () -> nowPlaying.next()));
        // The way into the full-screen music mode is its own button.
        row.addView(cpMiniBtn(R.drawable.ic_cp_expand, () -> { if (cpMusicAction != null) cpMusicAction.run(); }));
        card.addView(row);
        final TextView t1 = new TextView(this);
        t1.setTextColor(0xFFFFFFFF);
        t1.setTextSize(13);
        t1.setTypeface(null, android.graphics.Typeface.BOLD);
        t1.setSingleLine(true);
        t1.setEllipsize(TextUtils.TruncateAt.END);
        t1.setPadding(0, dp(6), 0, 0);
        final TextView t2 = new TextView(this);
        t2.setTextColor(0xB3FFFFFF);
        t2.setTextSize(12);
        t2.setSingleLine(true);
        t2.setEllipsize(TextUtils.TruncateAt.END);
        final android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, dp(4));
        plp.topMargin = dp(8);
        card.addView(t1);
        card.addView(t2);
        card.addView(pb, plp);
        cpMusicCardView = card;
        cpRefresh = () -> {
            card.setBackground(cpBevel(26));
            if (getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE).getBoolean("music_card_shine", false)
                    && !TextUtils.isEmpty(cpTitle) && !cpTitle.equals(cpShineTitle)) {
                boolean first = cpShineTitle == null;
                cpShineTitle = cpTitle;
                if (!first) startShine();
            }
            pb.setProgressTintList(android.content.res.ColorStateList.valueOf(cpAccent == 0 ? 0xFFFFFFFF : mixWhite(cpAccent)));
            t1.setText(TextUtils.isEmpty(cpTitle) ? getString(R.string.media_nothing) : cpTitle);
            t2.setText(cpArtist == null ? "" : cpArtist);
            play.setImageResource(cpPlaying ? R.drawable.ic_media_pause : R.drawable.ic_media_play);
            if (cpArt != null) art.setImageBitmap(cpArt); else art.setImageResource(R.drawable.ic_music);
            art.setColorFilter(cpArt != null ? 0 : 0xFFFFFFFF);
        };
        cpTick = () -> {
            int percent = nowPlaying == null ? -1 : nowPlaying.progressPercent();
            pb.setVisibility(percent < 0 ? View.INVISIBLE : View.VISIBLE);
            if (percent >= 0) pb.setProgress(percent);
        };
        cpRefresh.run();
        cpTick.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(124), 1f);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        card.setLayoutParams(lp);
        return card;
    }

    private void showTopMenu() {
        View anchor = findViewById(R.id.btnSettings);
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        PopupWindow popup = glassPopup(panel, (int) (220 * density));
        // Inputs opens its own list once this one has closed.
        if (showInputsMenuRow) addInputRow(rows, popup, R.drawable.ic_input, getString(R.string.inputs), -1, () -> root.post(this::showInputs));
        addInputRow(rows, popup, R.drawable.ic_wifi, getString(R.string.quick_network), -1, this::openNetworkPill);
        CharSequence network = wifiIconOnly ? btnWifi.getContentDescription() : btnWifi.getText();
        if (!TextUtils.isEmpty(network)) {
            TextView status = rows.getChildAt(rows.getChildCount() - 1).findViewById(R.id.status);
            status.setText(network);
            status.setVisibility(View.VISIBLE);
        }
        addInputRow(rows, popup, R.drawable.ic_swap_vert, getString(R.string.reorder), -1, this::toggleReorder);
        if (launcherSettingsButton) {
            addInputRow(rows, popup, R.drawable.ic_home_settings_pill, getString(R.string.launcher_settings), -1,
                    () -> startActivityForResult(new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST));
        } else {
            addInputRow(rows, popup, R.drawable.ic_settings, getString(R.string.settings), -1,
                    () -> open(systemIntent(Settings.ACTION_SETTINGS)));
        }
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max((int) (220 * density), Math.min(panel.getMeasuredWidth(), (int) (360 * density))));
        dropIn(popup, panel, anchor, getResources().getBoolean(R.bool.rtl_menu_bar) ? Gravity.START : Gravity.END);
        rows.getChildAt(0).requestFocus();
    }

    /** The header opens launcher settings directly; hold OK keeps the extra home actions available. */
    private void showSettingsMenu() {
        View anchor = findViewById(R.id.btnSettings);
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        PopupWindow popup = glassPopup(panel, (int) (200 * density));
        if (!launcherSettingsButton) addSettingsMenuRow(rows, popup, R.string.launcher_settings, () -> startActivityForResult(
                new Intent(this, LauncherSettingsActivity.class), LAUNCHER_SETTINGS_REQUEST));
        // Firmware that ships its own settings app next to the AOSP one (Xiaomi China is one): the
        // vendor app holds pages the AOSP settings has no row for, such as Account & Security with
        // the ADB switch. Offered here only while one of them is installed.
        if (SystemSettings.vendorIntent(this) != null) {
            addSettingsMenuRow(rows, popup, R.string.native_settings, () -> {
                Intent vendor = SystemSettings.vendorIntent(this);
                if (vendor != null) open(vendor);
            });
        }
        if (moduleCards) addSettingsMenuRow(rows, popup, R.string.module_cards, this::showModuleCards);
        if (dockRow) addSettingsMenuRow(rows, popup, R.string.dock_edit, this::startDockEdit);
        addSettingsMenuRow(rows, popup, R.string.reorder, this::toggleReorder);
        // A launcher may not restart the TV itself; the Home key helper can open the system power menu instead.
        if (HomeKeyService.canOpenPowerMenu()) addSettingsMenuRow(rows, popup, R.string.power_menu, HomeKeyService::openPowerMenu);
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max((int) (200 * density), panel.getMeasuredWidth()));
        // Hebrew puts Settings at the left of the header: grow the menu inward from it.
        dropIn(popup, panel, anchor, getResources().getBoolean(R.bool.rtl_menu_bar)
                ? Gravity.START : Gravity.END);
        rows.getChildAt(0).requestFocus();
    }

    /** A tile configured with launch_actions "input:<id>" (config.xml): switch to that TV input directly,
     *  the same path the Inputs menu's own rows use, instead of opening the input's owning app normally. */
    @Override
    public void onOpenInput(String inputId) {
        openInput(inputId);
    }

    /**
     * Hold OK on a tile: a glass menu next to it. Move starts reorder mode with this tile already picked up;
     * Remove from Home takes the shortcut off (only with the app library on, where one press adds it back);
     * App info opens the TV's page for the app, which is what holding OK used to do.
     */
    // ---- hold OK ---------------------------------------------------------------------------------
    // View's own long click misses on some remotes: an IR remote that sends its repeat frames as separate
    // presses, or a Bluetooth one whose repeats land after a tile rebind, never holds one DOWN long enough.
    // So the launcher times the hold itself: OK down on a tile, still down (or still repeating) after
    // HOLD_OK_MS opens the tile menu, and the UP that follows is eaten so it doesn't also open the app.

    private static final long HOLD_OK_MS = 550;
    private long holdOkDown = -1;
    private int holdOkPosition = -1;
    private String holdOkKey;    // the app under OK when it went down; a tile rebuild can move another app to that slot
    private boolean holdOkFired;
    private final Runnable holdOkTimer = this::fireHoldOk;

    private static boolean isOkKey(int code) {
        return code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A;
    }

    /** True when the event belongs to a hold that opened the tile menu and must not reach the tile. */
    private boolean holdOk(KeyEvent event) {
        if (!tileMenuEnabled || !isOkKey(event.getKeyCode())) return false;
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (event.getRepeatCount() == 0) {
                holdOkFired = false;
                handler.removeCallbacks(holdOkTimer);
                holdOkPosition = reordering || openPopup != null || cardPrompt != null ? -1 : focusedTilePosition();
                holdOkKey = holdOkPosition < 0 || holdOkPosition >= adapter.appCount() ? null : adapter.keyAt(holdOkPosition);
                if (holdOkKey == null) {
                    holdOkDown = -1;
                    return false;
                }
                holdOkDown = event.getDownTime();
                handler.postDelayed(holdOkTimer, HOLD_OK_MS);
                return false;
            }
            if (holdOkFired) return true;
            if (holdOkDown >= 0 && event.getEventTime() - holdOkDown >= HOLD_OK_MS) {
                fireHoldOk();
                return true;
            }
            return false;
        }
        // ACTION_UP
        handler.removeCallbacks(holdOkTimer);
        holdOkDown = -1;
        holdOkKey = null;
        if (holdOkFired) {
            holdOkFired = false;
            View f = getCurrentFocus();
            if (f != null) f.setPressed(false);
            return true;
        }
        return false;
    }

    /**
     * Stops timing a held OK when the launcher is paused, loses its window or goes away, so the menu can't open
     * behind another screen. An interrupted press still counts as handled: its UP, if it comes back here, is eaten
     * rather than opening the tile.
     */
    private void cancelHoldOk() {
        handler.removeCallbacks(holdOkTimer);
        if (holdOkDown >= 0) holdOkFired = true;
        holdOkDown = -1;
        holdOkPosition = -1;
        holdOkKey = null;
    }

    private void fireHoldOk() {
        handler.removeCallbacks(holdOkTimer);
        if (holdOkDown < 0 || holdOkFired) return;
        holdOkFired = true;
        if (openPopup != null || reordering) return;   // View's own long click got there first
        int position = holdOkPosition;
        if (position < 0 || position >= adapter.appCount() || position != focusedTilePosition()) return;
        // Same slot is not enough: tiles may have been rebuilt during the hold, so the app must match too.
        if (!holdOkKey.equals(adapter.keyAt(position))) return;
        View card = getCurrentFocus();
        if (card != null) card.setPressed(false);
        onTileLongPress(position, card);
    }

    @Override
    public void onTileLongPress(int position, View card) {
        if (reordering || openPopup != null) return;
        String key = adapter.keyAt(position);
        String pkg = adapter.packageAt(position);
        // Empty dock slots and the Default-home tile carry the launcher's own package: no menu for them.
        if (key == null || pkg == null || pkg.equals(getPackageName())) return;
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        PopupWindow popup = glassPopup(panel, (int) (200 * density));
        if (dockRow && position < adapter.movableCount()) {
            boolean inDock = position < COLUMNS;
            addSettingsMenuRow(rows, popup, inDock ? R.string.tile_replace_in_dock : R.string.tile_add_to_dock,
                    () -> startDockEditFor(key, inDock));
        }
        if (position < adapter.movableCount()) addSettingsMenuRow(rows, popup, R.string.tile_move, () -> {
            if (!beginReorder()) return;
            int at = adapter.positionOf(key);   // beginReorder can rebuild the tiles
            if (at < 0) return;
            focusTile(at);
            pickUp(at);
            Toast.makeText(this, R.string.reorder_hint, Toast.LENGTH_LONG).show();
        });
        if (appLibraryEnabled) addSettingsMenuRow(rows, popup, R.string.library_remove_shortcut, () -> {
            if (LibraryApps.save(this, pkg, false)) reloadApps(false);
            else Toast.makeText(this, R.string.library_save_failed, Toast.LENGTH_LONG).show();
        });
        // Some firmware has no App info page at all; a row that only toasts "can't open" helps nobody.
        Intent info = SystemSettings.appInfo(this, pkg);
        if (info != null) addSettingsMenuRow(rows, popup, R.string.library_app_info, () -> open(info));
        if ((getApplicationInfoFlags(pkg) & android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0) {
            addSettingsMenuRow(rows, popup, R.string.tile_uninstall,
                    () -> open(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))));
        }
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max((int) (200 * density), panel.getMeasuredWidth()));
        // Dock tiles sit near the bottom of the screen: open the menu above the tile when it would not fit below.
        int[] at = new int[2];
        card.getLocationInWindow(at);
        int gap = (int) (10 * density), height = panel.getMeasuredHeight();
        if (at[1] + card.getHeight() + gap + height <= root.getHeight()) {
            dropIn(popup, panel, card, Gravity.START);
        } else {
            panel.setAlpha(0f);
            panel.setPivotY(height);
            panel.setScaleY(0.92f);
            panel.setTranslationY(8 * density);
            popup.showAtLocation(root, Gravity.NO_GRAVITY, at[0], Math.max(0, at[1] - gap - height));
            panel.animate().alpha(1f).scaleY(1f).translationY(0f).setDuration(220)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
        }
        rows.getChildAt(0).requestFocus();
    }

    private int getApplicationInfoFlags(String pkg) {
        try { return getPackageManager().getApplicationInfo(pkg, 0).flags; }
        catch (android.content.pm.PackageManager.NameNotFoundException e) { return android.content.pm.ApplicationInfo.FLAG_SYSTEM; }
    }

    private void addSettingsMenuRow(LinearLayout rows, PopupWindow popup, int title, Runnable action) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        row.findViewById(R.id.icon).setVisibility(View.GONE);
        row.findViewById(R.id.dot).setVisibility(View.GONE);
        row.findViewById(R.id.status).setVisibility(View.GONE);
        ((TextView) row.findViewById(R.id.title)).setText(title);
        row.setOnClickListener(v -> {
            popup.dismiss();
            action.run();
        });
        // The OK-up after opening the menu must not activate its first row.
        final boolean[] pressed = {false};
        row.setOnKeyListener((v, code, event) -> {
            if (code != KeyEvent.KEYCODE_DPAD_CENTER && code != KeyEvent.KEYCODE_ENTER) return false;
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (event.getRepeatCount() == 0) pressed[0] = true;
                return true;
            }
            boolean activate = pressed[0];
            pressed[0] = false;
            if (activate) {
                popup.dismiss();
                action.run();
            }
            return true;
        });
        rows.addView(row);
    }

    /**
     * Asks about the next card that has no decision for its current signing key. One prompt at a
     * time, only over a laid out grid with window focus (not under a popup or another app), and
     * the next one follows as soon as this one is answered. Nothing is shown until the owner says Show.
     */
    private void showCardPrompt() {
        if (!moduleCards || !tilesReady || promptsPaused || cardPrompt != null || !hasWindowFocus() || isFinishing()
                || reordering) return;
        if (cards.isEmpty() || !CardFeature.working()) return;
        CardFeature.run(() -> {
            showCardPromptNow();
            return null;
        }, null);
    }

    private void showCardPromptNow() {
        final Cards.Card card = Cards.firstPending(cards);
        if (card == null) return;

        View panel = getLayoutInflater().inflate(R.layout.dialog_card_prompt, root, false);
        boolean rtl = getResources().getBoolean(R.bool.rtl_menu_bar);
        if (rtl) panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ((TextView) panel.findViewById(R.id.title)).setText(getString(R.string.card_prompt_title, card.appLabel));
        ((TextView) panel.findViewById(R.id.body)).setText(card.state == Cards.State.RESIGNED
                ? getString(R.string.card_prompt_resigned, card.appLabel)
                : card.state == Cards.State.RELABELLED
                ? getString(R.string.card_prompt_relabelled, card.appLabel)
                : getString(R.string.card_prompt_body, card.appLabel));
        TextView names = panel.findViewById(R.id.names);
        if (Cards.fold(card.label).equals(Cards.fold(card.appLabel))) names.setVisibility(View.GONE);
        else names.setText(getString(R.string.card_prompt_names, card.label, card.appLabel));
        ((TextView) panel.findViewById(R.id.identity)).setText(
                getString(R.string.card_prompt_identity, card.pkg, Cards.shortDigest(card.digest)));
        TextView keep = panel.findViewById(R.id.btnKeep);
        TextView show = panel.findViewById(R.id.btnShow);
        if (rtl) {
            LinearLayout buttons = (LinearLayout) keep.getParent();
            buttons.removeAllViews();
            buttons.addView(show);
            buttons.addView(keep);
            keep.setNextFocusLeftId(R.id.btnShow);
            keep.setNextFocusRightId(R.id.btnKeep);
            show.setNextFocusLeftId(R.id.btnShow);
            show.setNextFocusRightId(R.id.btnKeep);
        }

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(panel);
        dialog.setCanceledOnTouchOutside(false);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (440 * density), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setDimAmount(0.6f);
            if (WindowBlur.supported(this)) {
                android.view.WindowManager.LayoutParams lp = w.getAttributes();
                WindowBlur.apply(lp, dp(20));
                w.setAttributes(lp);
                w.setDimAmount(0.35f);
            }
        }
        // One decision per prompt: the buttons and Back (cancel) all end here.
        final boolean[] decided = {false};
        View.OnClickListener choose = v -> {
            if (decided[0]) return;
            decided[0] = true;
            cardPrompt = null;
            dialog.dismiss();
            decideCard(card, v.getId() == R.id.btnShow);   // guards its own card calls; the tile reload stays outside
            restoreFocus();   // the tiles changed under the prompt; this also chains the next prompt
        };
        keep.setOnClickListener(choose);
        show.setOnClickListener(choose);
        dialog.setOnCancelListener(d -> choose.onClick(keep));
        dialog.setOnDismissListener(d -> {
            if (cardPrompt == dialog) cardPrompt = null;
        });
        // Left and Right move between the two buttons; Up and Down stay put; the ends don't wrap.
        View.OnKeyListener keys = (v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) return true;
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT)
                return v.getId() == (rtl ? R.id.btnShow : R.id.btnKeep);
            return keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                    && v.getId() == (rtl ? R.id.btnKeep : R.id.btnShow);
        };
        keep.setOnKeyListener(keys);
        show.setOnKeyListener(keys);
        cardPrompt = dialog;
        dialog.show();
        keep.requestFocus();
    }

    /** Writes the owner's decision and rebuilds the tiles; focus is left where it is. */
    private void decideCard(Cards.Card card, boolean show) {
        boolean saved = CardFeature.run(() -> Cards.decide(Cards.storeFile(this), card, show), false);
        if (!saved) {
            Toast.makeText(this, R.string.card_not_saved, Toast.LENGTH_SHORT).show();
            promptsPaused = true;
        }
        reloadTiles();
    }

    /** Dropdown under the Settings pill (hold OK): every discovered card, its package and key; OK toggles Shown and Hidden. */
    private void showModuleCards() {
        if (cards.isEmpty() || !CardFeature.working()) {
            Toast.makeText(this, R.string.no_module_cards, Toast.LENGTH_SHORT).show();
            return;
        }
        CardFeature.run(() -> {
            showModuleCardsNow();
            return null;
        }, null);
    }

    private void showModuleCardsNow() {
        View anchor = findViewById(R.id.btnSettings);
        View panel = getLayoutInflater().inflate(R.layout.popup_cards, root, false);
        if (getResources().getBoolean(R.bool.rtl_menu_bar))
            panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout rows = panel.findViewById(R.id.rows);
        final PopupWindow popup = glassPopup(panel, (int) (400 * density));
        List<Cards.Card> listed = new ArrayList<>(cards);
        Collections.sort(listed, Cards::byLabel);
        for (Cards.Card card : listed) {
            View row = getLayoutInflater().inflate(R.layout.item_card_row, rows, false);
            row.setTag(card.pkg);
            ((TextView) row.findViewById(R.id.title)).setText(card.label);
            if (getResources().getBoolean(R.bool.rtl_menu_bar)) {
                LinearLayout heading = (LinearLayout) row.findViewById(R.id.title).getParent();
                View status = row.findViewById(R.id.state);
                heading.removeView(status);
                heading.addView(status, 0);
            }
            TextView app = row.findViewById(R.id.app);
            if (Cards.fold(card.label).equals(Cards.fold(card.appLabel))) app.setVisibility(View.GONE);
            else app.setText(getString(R.string.card_app_name, card.appLabel));
            ((TextView) row.findViewById(R.id.pkg)).setText(card.pkg);
            ((TextView) row.findViewById(R.id.digest)).setText(Cards.longDigest(card.digest));
            final String pkg = card.pkg;
            row.setOnClickListener(v -> CardFeature.run(() -> {
                // The list stays open; the decision is for the card as it is now, not as it was listed.
                Cards.Card now = cardFor(pkg);
                if (now == null) return null;
                decideCard(now, now.state != Cards.State.SHOWN);
                // Every row, not only this one: a toggle can move another card across the limit of 8.
                updateCardStates(rows);
                return null;
            }, null));
            rows.addView(row);
        }
        updateCardStates(rows);
        // Scroll inside the panel instead of running off the bottom of a 720p screen.
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int[] at = new int[2];
        anchor.getLocationInWindow(at);
        int room = root.getHeight() - (at[1] + anchor.getHeight()) - (int) (34 * density);
        popup.setHeight(Math.min(panel.getMeasuredHeight(), Math.max(room, (int) (120 * density))));
        // Hebrew places Settings on the left: align the outer panel inward, like its parent menu.
        dropIn(popup, panel, anchor, getResources().getBoolean(R.bool.rtl_menu_bar)
                ? Gravity.START : Gravity.END);
        rows.getChildAt(0).requestFocus();
    }

    private Cards.Card cardFor(String pkg) {
        for (Cards.Card c : cards) if (c.pkg.equals(pkg)) return c;
        return null;
    }

    /** Writes the state of every row in the Module cards list from the current card list. */
    private void updateCardStates(LinearLayout rows) {
        List<Cards.Card> drawn = Cards.shown(cards);
        for (int i = 0; i < rows.getChildCount(); i++) {
            View row = rows.getChildAt(i);
            Cards.Card card = row.getTag() instanceof String ? cardFor((String) row.getTag()) : null;
            ((TextView) row.findViewById(R.id.state)).setText(card != null ? stateText(card, drawn.contains(card)) : "");
        }
    }

    /** The row's state: a card the owner set to Shown but which is beyond the eight drawn says so. */
    private String stateText(Cards.Card card, boolean drawn) {
        switch (card.state) {
            case SHOWN:
                return getString(drawn ? R.string.card_state_shown : R.string.card_state_over_limit);
            case HIDDEN:
                return getString(R.string.card_state_hidden);
            case RESIGNED:
                return getString(R.string.card_state_new_key);
            case RELABELLED:
                return getString(R.string.card_state_new_label);
            default:
                return getString(R.string.card_state_new);
        }
    }
}
