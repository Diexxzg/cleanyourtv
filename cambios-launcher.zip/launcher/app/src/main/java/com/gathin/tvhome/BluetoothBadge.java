package com.gathin.tvhome;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.text.style.ReplacementSpan;

/**
 * Custom: the Bluetooth rune and, when something is connected, how many devices, drawn at the end of the Wi-Fi
 * pill's label. It draws with the text's own colour at the moment of drawing, so it turns dark with the label
 * when the pill takes focus (a plain image span would stay white on the white focused pill).
 */
final class BluetoothBadge extends ReplacementSpan {
    private final String count;
    private final float density;
    private final Path rune = new Path();
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** {@code devices} 0 draws the rune alone. */
    BluetoothBadge(int devices, float density) {
        this.count = devices > 0 ? String.valueOf(devices) : "";
        this.density = density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    private float runeWidth(Paint paint) {
        return paint.getTextSize() * 0.62f;
    }

    private float gap() {
        return 4 * density;
    }

    @Override
    public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
        float width = runeWidth(paint);
        if (!count.isEmpty()) width += gap() + paint.measureText(count);
        return Math.round(width + 1);
    }

    @Override
    public void draw(Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom,
                     Paint paint) {
        float size = paint.getTextSize();
        float h = size * 0.95f;
        float w = runeWidth(paint);
        float centre = y - size * 0.34f;   // the middle of the lower-case letters
        float top0 = centre - h / 2f;
        rune.reset();
        // The classic Bluetooth rune, in a w x h box.
        rune.moveTo(x, top0 + h * 0.28f);
        rune.lineTo(x + w, top0 + h * 0.74f);
        rune.lineTo(x + w * 0.5f, top0 + h);
        rune.lineTo(x + w * 0.5f, top0);
        rune.lineTo(x + w, top0 + h * 0.26f);
        rune.lineTo(x, top0 + h * 0.72f);
        stroke.setColor(paint.getColor());
        stroke.setAlpha(paint.getAlpha());
        stroke.setStrokeWidth(Math.max(1f, size * 0.11f));
        canvas.drawPath(rune, stroke);
        if (!count.isEmpty()) canvas.drawText(count, x + w + gap(), y, paint);
    }
}
