package com.gathin.tvhome;

import android.graphics.RectF;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.view.View;

/**
 * Liquid glass over a photo wallpaper (Android 13+): an AGSL shader on the wallpaper's own view bends the picture
 * under up to three glass regions (the dock, the top pills and the glass slab that moves between tiles). Near a
 * region's edge the picture is pulled in like light through a thick lens; inside it is magnified a touch. The
 * panels already drawn on top keep their own translucent fill, so what shows through them is the bent photo.
 *
 * Only the wallpaper view is re-drawn through the shader, and only while a frame is drawn at all, so an idle
 * Home costs nothing. The shader is one picture sample per pixel.
 */
final class LiquidGlass {
    static final String KEY = "liquid_glass";

    private static final String AGSL = ""
            + "uniform shader contents;\n"
            + "uniform float2 size;\n"
            + "uniform float4 b0;\n"
            + "uniform float4 b1;\n"
            + "uniform float4 b2;\n"
            + "uniform float rad;\n"
            + "uniform float pull;\n"
            + "float2 lens(float2 p, float4 b) {\n"
            + "    float2 hs = float2(b.z - b.x, b.w - b.y) * 0.5;\n"
            + "    if (hs.x <= 1.0 || hs.y <= 1.0) return float2(0.0);\n"
            + "    float2 c = float2(b.x + hs.x, b.y + hs.y);\n"
            + "    float r = min(rad, min(hs.x, hs.y));\n"
            + "    float2 q = abs(p - c) - hs + float2(r);\n"
            + "    float d = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;\n"
            + "    if (d > 0.0) return float2(0.0);\n"
            + "    float depth = clamp(-d / min(hs.x, hs.y), 0.0, 1.0);\n"
            + "    float rim = pow(1.0 - depth, 3.0);\n"
            + "    float2 dir = normalize(p - c + float2(0.0001));\n"
            + "    return -dir * rim * pull + (c - p) * 0.04 * clamp(depth * 2.0, 0.0, 1.0);\n"
            + "}\n"
            + "half4 main(float2 p) {\n"
            + "    float2 off = lens(p, b0) + lens(p, b1) + lens(p, b2);\n"
            + "    float2 uv = clamp(p + off, float2(0.0), size - float2(1.0));\n"
            + "    return contents.eval(uv);\n"
            + "}\n";

    private final View target;
    private final RuntimeShader shader = new RuntimeShader(AGSL);
    private final float radiusPx;
    private final float pullPx;
    private final float[] last = new float[12];
    private float lastW, lastH;
    private boolean applied;

    /** Throws when the TV's AGSL compiler refuses the shader; the caller then simply goes without. */
    LiquidGlass(View target, float density) {
        this.target = target;
        this.radiusPx = 22f * density;
        this.pullPx = 9f * density;
    }

    /** Regions in the wallpaper view's own pixels; an empty one means none. Cheap when nothing moved. */
    void update(RectF dock, RectF bar, RectF slab) {
        int w = target.getWidth();
        int h = target.getHeight();
        if (w <= 0 || h <= 0) return;
        boolean any = !dock.isEmpty() || !bar.isEmpty() || !slab.isEmpty();
        if (!any) {
            if (applied) {
                target.setRenderEffect(null);
                applied = false;
            }
            return;
        }
        float[] now = {
                dock.left, dock.top, dock.right, dock.bottom,
                bar.left, bar.top, bar.right, bar.bottom,
                slab.left, slab.top, slab.right, slab.bottom};
        if (applied && w == lastW && h == lastH && same(now)) return;
        System.arraycopy(now, 0, last, 0, 12);
        lastW = w;
        lastH = h;
        shader.setFloatUniform("size", (float) w, (float) h);
        shader.setFloatUniform("b0", now[0], now[1], now[2], now[3]);
        shader.setFloatUniform("b1", now[4], now[5], now[6], now[7]);
        shader.setFloatUniform("b2", now[8], now[9], now[10], now[11]);
        shader.setFloatUniform("rad", radiusPx);
        shader.setFloatUniform("pull", pullPx);
        target.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "contents"));
        applied = true;
    }

    /** Takes the effect off the wallpaper (Home is going away, or the setting was turned off). */
    void clear() {
        if (applied) target.setRenderEffect(null);
        applied = false;
    }

    private boolean same(float[] now) {
        for (int i = 0; i < 12; i++) if (Math.abs(now[i] - last[i]) > 0.5f) return false;
        return true;
    }
}
