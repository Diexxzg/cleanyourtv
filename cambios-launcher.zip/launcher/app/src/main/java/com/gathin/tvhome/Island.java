package com.gathin.tvhome;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Custom: the dynamic island. One dark pill at the top of the screen, over Home and over any app (it lives in
 * the accessibility service's window), that grows and shrinks to fit what it shows: the voice assistant
 * listening, an answer, an update downloading. While the voice is listening a coloured light also runs round the
 * edge of the screen. Without the accessibility service it falls back to a Toast.
 */
final class Island {
    static final int LISTEN = 0, OK = 1, WARN = 2, DOWN = 3, INFO = 4;
    private static final int NO_BAR = -2;

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final Runnable HIDE = new Runnable() {
        @Override public void run() {
            hide();
        }
    };

    private static float density = 2f;
    private static FrameLayout window;
    private static LinearLayout box;
    private static OrbView orb;
    private static TextView glyph;
    private static TextView title;
    private static TextView sub;
    private static FrameLayout barTrack;
    private static View barFill;
    private static ObjectAnimator barAnim;
    private static ValueAnimator widthAnim;
    private static boolean shown;
    private static int kind = -1;

    private static GlowView glow;
    private static boolean glowShown;

    private Island() { }

    // ---- public ----------------------------------------------------------------------------------------------

    static void listening(Context ctx) {
        present(ctx, LISTEN, "Escuchando\u2026", "Habla ahora", NO_BAR, 0);
        glowOn();
    }

    static void heard(Context ctx, CharSequence text) {
        present(ctx, LISTEN, "\u201C" + text + "\u201D", "Escuchando\u2026", NO_BAR, 0);
    }

    static void done(Context ctx, boolean ok, CharSequence t, CharSequence s) {
        glowOff();
        present(ctx, ok ? OK : WARN, t, s, NO_BAR, 3200);
    }

    static void message(Context ctx, int k, CharSequence t, CharSequence s, long ms) {
        present(ctx, k, t, s, NO_BAR, ms);
    }

    /** percent 0..100, or -1 when the size is not known yet. */
    static void progress(Context ctx, CharSequence t, CharSequence s, int percent, long ms) {
        present(ctx, DOWN, t, s, percent, ms);
    }

    static void level(final float v) {
        H.post(new Runnable() {
            @Override public void run() {
                if (orb != null) orb.setLevel(v);
                if (glow != null) glow.setLevel(v);
            }
        });
    }

    static void hide() {
        H.post(new Runnable() {
            @Override public void run() {
                H.removeCallbacks(HIDE);
                glowOffNow();
                if (!shown || box == null) return;
                shown = false;
                kind = -1;
                stopBarAnim();
                final View w = window;
                box.animate().cancel();
                box.animate().alpha(0f).scaleX(0.7f).scaleY(0.7f).setDuration(260)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                if (!shown) OverlayHost.removeWindow(w);
                            }
                        }).start();
            }
        });
    }

    // ---- the pill --------------------------------------------------------------------------------------------

    private static int dp(float v) {
        return Math.round(v * density);
    }

    private static void present(final Context ctx, final int k, final CharSequence t, final CharSequence s,
                                final int percent, final long ms) {
        H.post(new Runnable() {
            @Override public void run() {
                doPresent(ctx, k, t, s, percent, ms);
            }
        });
    }

    private static void doPresent(Context ctx, int k, CharSequence t, CharSequence s, int percent, long ms) {
        Context sc = OverlayHost.context();
        if (sc == null) {
            if (ctx != null) {
                Toast.makeText(ctx, TextUtils.isEmpty(s) ? t : t + " - " + s, Toast.LENGTH_SHORT).show();
            }
            return;
        }
        H.removeCallbacks(HIDE);
        density = sc.getResources().getDisplayMetrics().density;
        if (window == null) build(sc);
        boolean first = !shown;
        int oldWidth = first ? dp(64) : box.getWidth();
        if (first) {
            box.animate().cancel();
            OverlayHost.removeWindow(window);
            ViewGroup.LayoutParams lp = box.getLayoutParams();
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            box.setLayoutParams(lp);
            if (!OverlayHost.addWindow(window, dp(580), ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, dp(26))) {
                if (ctx != null) Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show();
                return;
            }
            shown = true;
        }
        setContent(k, t, s, percent);
        box.measure(View.MeasureSpec.makeMeasureSpec(dp(560), View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int target = box.getMeasuredWidth();
        if (widthAnim != null) widthAnim.cancel();
        widthAnim = ValueAnimator.ofInt(oldWidth, target);
        widthAnim.setDuration(first ? 460 : 380);
        widthAnim.setInterpolator(new OvershootInterpolator(0.9f));
        widthAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                ViewGroup.LayoutParams lp = box.getLayoutParams();
                lp.width = Math.max(dp(40), (Integer) a.getAnimatedValue());
                box.setLayoutParams(lp);
            }
        });
        widthAnim.start();
        if (first) {
            box.setAlpha(0f);
            box.setScaleX(0.6f);
            box.setScaleY(0.6f);
            box.setPivotY(0f);
            box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420)
                    .setInterpolator(new OvershootInterpolator(1.1f)).start();
        }
        if (ms > 0) H.postDelayed(HIDE, ms);
    }

    private static void build(Context sc) {
        window = new FrameLayout(sc);
        box = new LinearLayout(sc);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(12), dp(10), dp(22), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0141416);
        bg.setCornerRadius(dp(34));
        bg.setStroke(Math.max(1, dp(1)), 0x59FFFFFF);
        box.setBackground(bg);

        FrameLayout icon = new FrameLayout(sc);
        orb = new OrbView(sc);
        icon.addView(orb, new FrameLayout.LayoutParams(dp(40), dp(40)));
        glyph = new TextView(sc);
        glyph.setGravity(Gravity.CENTER);
        glyph.setTextSize(22);
        glyph.setTypeface(null, android.graphics.Typeface.BOLD);
        glyph.setTextColor(0xFFFFFFFF);
        icon.addView(glyph, new FrameLayout.LayoutParams(dp(40), dp(40)));
        box.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout texts = new LinearLayout(sc);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(14), 0, 0, 0);
        title = label(sc, 18, true, 0xFFFFFFFF);
        sub = label(sc, 14, false, 0xB3FFFFFF);
        texts.addView(title);
        texts.addView(sub);
        barTrack = new FrameLayout(sc);
        GradientDrawable track = new GradientDrawable();
        track.setColor(0x33FFFFFF);
        track.setCornerRadius(dp(3));
        barTrack.setBackground(track);
        barFill = new View(sc);
        GradientDrawable fill = new GradientDrawable();
        fill.setColor(0xFF0A84FF);
        fill.setCornerRadius(dp(3));
        barFill.setBackground(fill);
        barTrack.addView(barFill, new FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(200), dp(4));
        blp.topMargin = dp(7);
        texts.addView(barTrack, blp);
        box.addView(texts, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        window.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL));
    }

    private static TextView label(Context sc, int sp, boolean bold, int color) {
        TextView v = new TextView(sc);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        v.setMaxWidth(dp(400));
        return v;
    }

    private static void setContent(int k, CharSequence t, CharSequence s, int percent) {
        boolean changed = k != kind;
        kind = k;
        orb.setVisibility(k == LISTEN ? View.VISIBLE : View.GONE);
        glyph.setVisibility(k == LISTEN ? View.GONE : View.VISIBLE);
        if (k == OK) {
            glyph.setText("\u2713");
            glyph.setTextColor(0xFF30D158);
        } else if (k == WARN) {
            glyph.setText("!");
            glyph.setTextColor(0xFFFF9F0A);
        } else if (k == DOWN) {
            glyph.setText("\u2193");
            glyph.setTextColor(0xFF0A84FF);
        } else {
            glyph.setText("i");
            glyph.setTextColor(0xFF64D2FF);
        }
        title.setText(t);
        sub.setText(s);
        sub.setVisibility(TextUtils.isEmpty(s) ? View.GONE : View.VISIBLE);
        stopBarAnim();
        if (percent == NO_BAR) {
            barTrack.setVisibility(View.GONE);
        } else {
            barTrack.setVisibility(View.VISIBLE);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) barFill.getLayoutParams();
            if (percent >= 0) {
                lp.width = dp(200) * Math.min(100, percent) / 100;
                barFill.setLayoutParams(lp);
                barFill.setTranslationX(0f);
            } else {
                lp.width = dp(70);
                barFill.setLayoutParams(lp);
                barAnim = ObjectAnimator.ofFloat(barFill, View.TRANSLATION_X, 0f, dp(130));
                barAnim.setDuration(900);
                barAnim.setRepeatCount(ValueAnimator.INFINITE);
                barAnim.setRepeatMode(ValueAnimator.REVERSE);
                barAnim.start();
            }
        }
        if (changed) {
            title.setAlpha(0.2f);
            title.animate().alpha(1f).setDuration(220).start();
            sub.setAlpha(0.2f);
            sub.animate().alpha(1f).setDuration(260).start();
        }
    }

    private static void stopBarAnim() {
        if (barAnim != null) {
            barAnim.cancel();
            barAnim = null;
        }
    }

    // ---- the light round the screen --------------------------------------------------------------------------

    private static void glowOn() {
        H.post(new Runnable() {
            @Override public void run() {
                Context sc = OverlayHost.context();
                if (sc == null) return;
                if (glow == null) glow = new GlowView(sc);
                if (glowShown) return;
                glow.animate().cancel();
                OverlayHost.removeWindow(glow);
                if (!OverlayHost.addWindow(glow, ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT, Gravity.TOP | Gravity.START, 0, 0)) return;
                glowShown = true;
                glow.setAlpha(0f);
                glow.animate().alpha(1f).setDuration(450).start();
            }
        });
    }

    private static void glowOff() {
        H.post(new Runnable() {
            @Override public void run() {
                glowOffNow();
            }
        });
    }

    private static void glowOffNow() {
        if (glow == null || !glowShown) return;
        glowShown = false;
        final GlowView g = glow;
        g.animate().cancel();
        g.animate().alpha(0f).setDuration(380).withEndAction(new Runnable() {
            @Override public void run() {
                if (!glowShown) OverlayHost.removeWindow(g);
            }
        }).start();
    }

    // ---- views -----------------------------------------------------------------------------------------------

    /** The pulsing ball of the assistant; it swells with the voice. */
    static final class OrbView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float level;
        private float phase;
        private ValueAnimator pulse;

        OrbView(Context c) {
            super(c);
        }

        void setLevel(float v) {
            level = level * 0.6f + v * 0.4f;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            float r = Math.min(w, h) / 2f;
            paint.setShader(new RadialGradient(w / 2f, h / 2f, r,
                    new int[] {0xFFFFFFFF, 0xFF7AB7FF, 0xFF8E6BFF, 0x008E6BFF},
                    new float[] {0f, 0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            pulse = ValueAnimator.ofFloat(0f, 1f);
            pulse.setDuration(1600);
            pulse.setRepeatCount(ValueAnimator.INFINITE);
            pulse.setInterpolator(new LinearInterpolator());
            pulse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    phase = (Float) a.getAnimatedValue();
                    level *= 0.96f;
                    invalidate();
                }
            });
            pulse.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (pulse != null) pulse.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) / 2f;
            float breathe = 0.78f + 0.08f * (float) Math.sin(phase * 2f * Math.PI) + 0.2f * level;
            int save = canvas.save();
            canvas.scale(breathe, breathe, cx, cy);
            canvas.drawCircle(cx, cy, r, paint);
            canvas.restoreToCount(save);
        }
    }

    /** A rainbow-ish band of light that runs round the screen's edge, thicker when the voice is louder. */
    static final class GlowView extends View {
        private static final int[] COLORS = {0xFF4FC3F7, 0xFF7C4DFF, 0xFFFF4081, 0xFFFFB74D, 0xFF4FC3F7};
        private static final int[] ALPHAS = {0x10, 0x1C, 0x33, 0x66, 0xE6};
        private static final float[] WIDTHS = {9f, 6f, 3.6f, 1.8f, 1f};
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix matrix = new Matrix();
        private final RectF rect = new RectF();
        private SweepGradient sweep;
        private ValueAnimator spin;
        private float angle;
        private float level;

        GlowView(Context c) {
            super(c);
            paint.setStyle(Paint.Style.STROKE);
        }

        void setLevel(float v) {
            level = level * 0.6f + v * 0.4f;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            sweep = new SweepGradient(w / 2f, h / 2f, COLORS, null);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            spin = ValueAnimator.ofFloat(0f, 360f);
            spin.setDuration(3600);
            spin.setRepeatCount(ValueAnimator.INFINITE);
            spin.setInterpolator(new LinearInterpolator());
            spin.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    angle = (Float) a.getAnimatedValue();
                    level *= 0.97f;
                    invalidate();
                }
            });
            spin.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (spin != null) spin.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (sweep == null) return;
            float d = getResources().getDisplayMetrics().density;
            matrix.setRotate(angle, getWidth() / 2f, getHeight() / 2f);
            sweep.setLocalMatrix(matrix);
            paint.setShader(sweep);
            float base = d * (2f + level * 6f);
            float radius = 24f * d;
            for (int i = 0; i < WIDTHS.length; i++) {
                float w = base * WIDTHS[i];
                paint.setStrokeWidth(w);
                paint.setAlpha(ALPHAS[i]);
                rect.set(w / 2f, w / 2f, getWidth() - w / 2f, getHeight() - w / 2f);
                canvas.drawRoundRect(rect, radius, radius, paint);
            }
        }
    }
}
