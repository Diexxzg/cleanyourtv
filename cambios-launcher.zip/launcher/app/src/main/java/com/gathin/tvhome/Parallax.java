package com.gathin.tvhome;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

/** Custom: switch and focus hook for ParallaxDrawable (Novedades > Iconos). On by default. */
final class Parallax {
    static final String KEY = "parallax_icons";

    private static float lastX = Float.NaN;
    private static float lastY = Float.NaN;

    private Parallax() { }

    static boolean enabled(Context ctx) {
        return ctx.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).getBoolean(KEY, true);
    }

    /** The picture to show in a tile: wrapped for depth when the effect is on. */
    static Drawable wrap(Context ctx, Drawable d) {
        if (d == null || d instanceof ParallaxDrawable || !enabled(ctx)) return d;
        return new ParallaxDrawable(d);
    }

    /** Called when a tile gains or loses focus; the layers settle from the side the focus came from. */
    static void onFocus(View card, ImageView banner, ImageView icon, boolean focused, boolean motion) {
        ParallaxDrawable pd = find(banner);
        if (pd == null) pd = find(icon);
        if (pd == null) return;
        final ParallaxDrawable target = pd;
        target.reset();
        if (!focused) return;
        float dx = 0f;
        float dy = 0f;
        int[] loc = new int[2];
        card.getLocationOnScreen(loc);
        float cx = loc[0] + card.getWidth() / 2f;
        float cy = loc[1] + card.getHeight() / 2f;
        if (!Float.isNaN(lastX)) {
            dx = cx - lastX;
            dy = cy - lastY;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 1f) {
                dx /= len;
                dy /= len;
            } else {
                dx = 0f;
                dy = 0f;
            }
        }
        lastX = cx;
        lastY = cy;
        if (!motion) return;
        final float fx = dx;
        final float fy = dy;
        final OvershootInterpolator settle = new OvershootInterpolator(2.2f);
        final DecelerateInterpolator glide = new DecelerateInterpolator(1.4f);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(620);
        a.addUpdateListener(an -> {
            float t = (Float) an.getAnimatedValue();
            float k = 1f - settle.getInterpolation(t);
            target.set(fx * k, fy * k, glide.getInterpolation(t));
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                target.set(0f, 0f, -1f);
            }
        });
        target.animator = a;
        a.start();
    }

    private static ParallaxDrawable find(ImageView v) {
        if (v == null || v.getVisibility() != View.VISIBLE) return null;
        Drawable d = v.getDrawable();
        return d instanceof ParallaxDrawable ? (ParallaxDrawable) d : null;
    }
}
