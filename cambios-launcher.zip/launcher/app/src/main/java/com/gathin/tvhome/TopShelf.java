package com.gathin.tvhome;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Top Shelf: a row of the focused dock app's Android TV content (its Watch Next and preview-channel programs)
 * above the hero name. Up from the dock enters the row, Down or Back returns. Shows nothing when the app
 * publishes no content or the TV's TvProvider refuses to list it.
 */
final class TopShelf {
    static final String PERM = "android.permission.READ_TV_LISTINGS";
    private static final String KEY = "top_shelf";
    private static final int HEIGHT_DP = 150;

    static final class Item {
        String title;
        Uri art;
        String intentUri;
        long rank;
    }

    private static final class Cached {
        final long time = System.currentTimeMillis();
        final List<Item> items;
        Cached(List<Item> items) { this.items = items; }
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final LruCache<String, Bitmap> BITMAPS = new LruCache<String, Bitmap>(6 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private final Map<String, Cached> cache = new ConcurrentHashMap<>();

    private final Activity act;
    private final Consumer<Intent> opener;
    private final Runnable back;
    private final HorizontalScrollView scroll;
    private final LinearLayout row;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final float density;
    private String pkg;
    private int token;
    private boolean ready;
    private Runnable pending;

    TopShelf(Activity act, FrameLayout root, int index, Consumer<Intent> opener, Runnable back) {
        this.act = act;
        this.opener = opener;
        this.back = back;
        density = act.getResources().getDisplayMetrics().density;
        row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        scroll = new HorizontalScrollView(act);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(8), dp(10), dp(8), dp(10));
        scroll.setVisibility(View.GONE);
        scroll.addView(row, new FrameLayout.LayoutParams(-2, -2));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(HEIGHT_DP), Gravity.TOP | Gravity.START);
        lp.setMarginStart(dp(60));
        root.addView(scroll, Math.min(index, root.getChildCount()), lp);
    }

    static boolean enabled(Context c) {
        return c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).getBoolean(KEY, false);
    }

    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply();
    }

    static boolean granted(Context c) {
        return c.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
    }

    static int heightPx(Context c) {
        return Math.round(HEIGHT_DP * c.getResources().getDisplayMetrics().density);
    }

    private int dp(int v) { return Math.round(v * density); }

    /** The focused dock app changed: place the row at y and (after a short pause) fill it with that app's content. */
    void show(String packageName, float y) {
        if (packageName == null || !enabled(act) || !granted(act)) { hide(); return; }
        scroll.setY(y);
        if (packageName.equals(pkg)) return;
        pkg = packageName;
        final int mine = ++token;
        ready = false;
        scroll.animate().cancel();
        scroll.setVisibility(View.GONE);
        handler.removeCallbacks(pending);
        final String target = packageName;
        pending = () -> POOL.execute(() -> {
            Cached c = cache.get(target);
            if (c == null || System.currentTimeMillis() - c.time > 60_000L) {
                c = new Cached(query(act, target));
                cache.put(target, c);
            }
            final List<Item> items = c.items;
            act.runOnUiThread(() -> { if (mine == token) fill(items); });
        });
        handler.postDelayed(pending, 220);
    }

    void hide() {
        token++;
        pkg = null;
        ready = false;
        handler.removeCallbacks(pending);
        scroll.animate().cancel();
        scroll.setVisibility(View.GONE);
    }

    /** Moves focus into the row; false when there is nothing to show. */
    boolean focusFirst() {
        if (!ready || row.getChildCount() == 0 || scroll.getVisibility() != View.VISIBLE) return false;
        return row.getChildAt(0).requestFocus();
    }

    private void fill(List<Item> items) {
        row.removeAllViews();
        if (items.isEmpty()) { ready = false; scroll.setVisibility(View.GONE); return; }
        for (Item it : items) row.addView(card(it));
        scroll.scrollTo(0, 0);
        scroll.setAlpha(0f);
        scroll.setVisibility(View.VISIBLE);
        scroll.animate().alpha(1f).setDuration(180).start();
        ready = true;
    }

    private View card(final Item it) {
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(3), dp(3), dp(3), dp(3));
        col.setFocusable(true);
        col.setClickable(true);
        GradientDrawable on = new GradientDrawable();
        on.setCornerRadius(dp(14));
        on.setColor(0x26FFFFFF);
        on.setStroke(dp(2), Color.WHITE);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, on);
        bg.addState(new int[]{}, new GradientDrawable());
        col.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(182), -2);
        cp.setMarginEnd(dp(10));
        col.setLayoutParams(cp);

        final ImageView iv = new ImageView(act);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0x33FFFFFF);
        iv.setClipToOutline(true);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(10)); }
        });
        col.addView(iv, new LinearLayout.LayoutParams(dp(176), dp(99)));
        TextView t = new TextView(act);
        t.setText(it.title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(dp(2), dp(4), dp(2), 0);
        col.addView(t, new LinearLayout.LayoutParams(dp(176), -2));

        if (it.art != null) {
            iv.setTag(it.art);
            POOL.execute(() -> {
                final Bitmap b = load(act, it.art);
                if (b != null) act.runOnUiThread(() -> { if (it.art.equals(iv.getTag())) iv.setImageBitmap(b); });
            });
        }
        col.setOnFocusChangeListener((v, f) ->
                v.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(140).start());
        col.setOnClickListener(v -> {
            try {
                Intent i = Intent.parseUri(it.intentUri, Intent.URI_INTENT_SCHEME);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                opener.accept(i);
            } catch (URISyntaxException | RuntimeException ignored) { }
        });
        col.setOnKeyListener((v, code, e) -> {
            if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_DOWN || code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) {
                back.run();
                return true;
            }
            return false;
        });
        return col;
    }

    // ---- data ---------------------------------------------------------------------------------

    static List<Item> query(Context c, String pkg) {
        List<Item> out = new ArrayList<>();
        read(c, "content://android.media.tv/watch_next_program", pkg, out, "last_engagement_time_utc_millis", 4);
        read(c, "content://android.media.tv/preview_program", pkg, out, "weight", 8);
        return out;
    }

    private static void read(Context c, String uri, String pkg, List<Item> out, String rankCol, int limit) {
        List<Item> part = new ArrayList<>();
        try (Cursor q = c.getContentResolver().query(Uri.parse(uri), null, "package_name=?", new String[]{pkg}, null)) {
            if (q == null) return;
            int t = q.getColumnIndex("title"), p = q.getColumnIndex("poster_art_uri"),
                    th = q.getColumnIndex("thumbnail_uri"), i = q.getColumnIndex("intent_uri"), r = q.getColumnIndex(rankCol);
            if (t < 0 || i < 0) return;
            while (q.moveToNext() && part.size() < 60) {
                Item it = new Item();
                it.title = q.getString(t);
                it.intentUri = q.getString(i);
                if (it.title == null || it.title.isEmpty() || it.intentUri == null || it.intentUri.isEmpty()) continue;
                String art = p >= 0 ? q.getString(p) : null;
                if (art == null || art.isEmpty()) art = th >= 0 ? q.getString(th) : null;
                it.art = art == null || art.isEmpty() ? null : Uri.parse(art);
                it.rank = r >= 0 ? q.getLong(r) : 0;
                part.add(it);
            }
        } catch (RuntimeException e) {
            return;   // no TvProvider, permission refused or a column this firmware lacks
        }
        Collections.sort(part, (a, b) -> Long.compare(b.rank, a.rank));
        out.addAll(part.size() > limit ? part.subList(0, limit) : part);
    }

    private static Bitmap load(Context c, Uri u) {
        String key = u.toString();
        Bitmap hit = BITMAPS.get(key);
        if (hit != null) return hit;
        try {
            byte[] data = readAll(c, u);
            if (data == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= 360) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (b != null) BITMAPS.put(key, b);
            return b;
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    private static byte[] readAll(Context c, Uri u) throws Exception {
        String s = u.getScheme();
        InputStream in;
        HttpURLConnection conn = null;
        if ("http".equals(s) || "https".equals(s)) {
            conn = (HttpURLConnection) new URL(u.toString()).openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(8000);
            in = conn.getInputStream();
        } else {
            in = c.getContentResolver().openInputStream(u);
        }
        if (in == null) return null;
        try (InputStream is = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = is.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 3 * 1024 * 1024) return null;
            }
            return out.toByteArray();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
