package com.gathin.tvhome;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

/** A very short, quiet click for focus moves; the switch lives in the control panel. */
final class SoftSounds {
    private static final String KEY = "soft_sounds";
    private static SoundPool pool;
    private static int clip;
    private static boolean ready;
    private static long last;

    private SoftSounds() { }

    static boolean enabled(Context c) {
        return c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).getBoolean(KEY, true);
    }

    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply();
    }

    static void init(Context c) {
        if (pool != null) return;
        try {
            File f = new File(c.getCacheDir(), "soft_click.wav");
            if (!f.isFile()) {
                try (FileOutputStream out = new FileOutputStream(f)) { out.write(wav()); }
            }
            pool = new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
            pool.setOnLoadCompleteListener((p, id, status) -> ready = status == 0);
            clip = pool.load(f.getAbsolutePath(), 1);
        } catch (Exception | Error e) {
            pool = null;
        }
    }

    static void play(Context c) {
        if (pool == null || !ready || !enabled(c)) return;
        long now = SystemClock.uptimeMillis();
        if (now - last < 70) return;
        last = now;
        pool.play(clip, 0.28f, 0.28f, 1, 0, 1f);
    }

    /** 40 ms decaying 1.4 kHz tone, 16-bit mono 22.05 kHz. */
    private static byte[] wav() {
        int rate = 22050, n = rate * 40 / 1000;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        writeAscii(o, "RIFF"); le(o, 36 + n * 2, 4); writeAscii(o, "WAVEfmt ");
        le(o, 16, 4); le(o, 1, 2); le(o, 1, 2); le(o, rate, 4); le(o, rate * 2, 4); le(o, 2, 2); le(o, 16, 2);
        writeAscii(o, "data"); le(o, n * 2, 4);
        for (int i = 0; i < n; i++) {
            double t = i / (double) rate;
            le(o, (int) (Math.sin(2 * Math.PI * 1400 * t) * Math.exp(-t * 110) * 0.6 * 32767), 2);
        }
        return o.toByteArray();
    }

    private static void writeAscii(ByteArrayOutputStream o, String s) {
        for (int i = 0; i < s.length(); i++) o.write(s.charAt(i));
    }

    private static void le(ByteArrayOutputStream o, int v, int bytes) {
        for (int i = 0; i < bytes; i++) o.write((v >> (8 * i)) & 0xFF);
    }
}
