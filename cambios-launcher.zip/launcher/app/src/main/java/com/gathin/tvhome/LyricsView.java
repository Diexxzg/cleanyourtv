package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Apple Music style lyrics: the current line big and white, the rest dim, scrolling to keep it centred. */
final class LyricsView extends ScrollView {
    private static final float DIM = 0.26f;
    private final LinearLayout box;
    private final float density;
    private final boolean reduced;
    private TextView[] rows = new TextView[0];
    private long[] times;
    private int active = -1;
    private int lastScroll = Integer.MIN_VALUE;

    LyricsView(Context c, boolean reducedMotion) {
        super(c);
        reduced = reducedMotion;
        density = c.getResources().getDisplayMetrics().density;
        setFocusable(false);
        setVerticalScrollBarEnabled(false);
        setVerticalFadingEdgeEnabled(true);
        setFadingEdgeLength((int) (110 * density));
        setOverScrollMode(OVER_SCROLL_NEVER);
        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        addView(box, new LayoutParams(-1, -2));
    }

    private int dp(int v) { return Math.round(v * density); }

    private void pad() {
        int p = getResources().getDisplayMetrics().heightPixels / 3;
        box.setPadding(0, p, 0, p);
    }

    /** One centred-ish message (searching, none found). */
    void showMessage(String text) {
        box.removeAllViews();
        rows = new TextView[0];
        times = null;
        active = -1;
        pad();
        TextView t = row(text, 22);
        t.setAlpha(0.6f);
        box.addView(t);
        scrollTo(0, 0);
    }

    void setLyrics(LyricsFetcher.Result r) {
        box.removeAllViews();
        times = r.times;
        active = -1;
        lastScroll = Integer.MIN_VALUE;
        pad();
        rows = new TextView[r.lines.length];
        for (int i = 0; i < rows.length; i++) {
            String s = r.lines[i].isEmpty() ? "\u266A" : r.lines[i];
            TextView t = row(s, 38);
            t.setAlpha(times != null ? DIM : 0.9f);
            if (times != null) { t.setScaleX(0.92f); t.setScaleY(0.92f); }
            rows[i] = t;
            box.addView(t);
        }
        scrollTo(0, 0);
    }

    private TextView row(String s, int sp) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(sp);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.START);
        t.setPadding(dp(4), dp(11), dp(32), dp(11));
        t.setPivotX(0f);
        return t;
    }

    /** Call a few times a second with the track position. */
    void update(long pos, long dur) {
        if (rows.length == 0 || pos < 0) return;
        if (times == null) {
            if (dur <= 0 || box.getHeight() <= getHeight()) return;
            int y = (int) ((box.getHeight() - getHeight()) * Math.min(1f, pos / (float) dur));
            if (Math.abs(y - (lastScroll == Integer.MIN_VALUE ? 0 : lastScroll)) > dp(24)) {
                lastScroll = y;
                smoothScrollTo(0, y);
            }
            return;
        }
        int idx = -1;
        for (int i = 0; i < times.length; i++) {
            if (times[i] <= pos + 200) idx = i; else break;
        }
        if (idx == active) return;
        int from = Math.max(0, Math.min(active < 0 ? 0 : active, idx < 0 ? 0 : idx) - 5);
        int to = Math.min(rows.length - 1, Math.max(active, idx) + 5);
        active = idx;
        for (int i = from; i <= to; i++) look(rows[i], i == idx ? 1f : fade(Math.abs(i - idx)), i == idx ? 1f : 0.92f);
        if (idx >= 0) {
            final TextView r = rows[idx];
            post(() -> smoothScrollTo(0, r.getTop() + r.getHeight() / 2 - getHeight() / 2));
        }
    }

    private static float fade(int distance) {
        return distance == 1 ? 0.55f : distance == 2 ? 0.38f : DIM;
    }

    private void look(TextView t, float a, float s) {
        if (reduced) { t.setAlpha(a); t.setScaleX(s); t.setScaleY(s); return; }
        t.animate().cancel();
        t.animate().alpha(a).scaleX(s).scaleY(s).setDuration(300).start();
    }

    @Override
    public boolean onTouchEvent(android.view.MotionEvent e) { return false; }

    @Override
    public boolean onInterceptTouchEvent(android.view.MotionEvent e) { return false; }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent e) { return false; }

    @Override
    public void setVisibility(int v) { super.setVisibility(v); }

    View asView() { return this; }
}
