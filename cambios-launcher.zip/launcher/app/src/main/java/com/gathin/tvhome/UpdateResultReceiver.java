package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/** Custom: what the system installer answers after UpdateChecker hands it a new APK. */
public final class UpdateResultReceiver extends BroadcastReceiver {
    static final String ACTION = "com.gathin.tvhome.UPDATE_RESULT";

    @Override
    public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    context.startActivity(confirm);
                } catch (RuntimeException e) {
                    Island.message(context, Island.WARN, "No pude abrir el instalador",
                            "Permite instalar apps al launcher en Novedades", 7000);
                }
            }
            return;
        }
        if (status == PackageInstaller.STATUS_SUCCESS) {
            Island.message(context, Island.OK, "Launcher actualizado", "", 3000);
            return;
        }
        String why = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        Island.message(context, Island.WARN, "No se pudo actualizar", why == null ? "" : why, 8000);
    }
}
