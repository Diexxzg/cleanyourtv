package com.gathin.tvhome;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import java.util.List;

/**
 * Follows whichever app is playing media (Spotify, YouTube Music...) and reports its title and state to the
 * header's "Now playing" pill. Needs notification access for {@link MediaListenerService}; without it
 * Android throws a SecurityException, which is treated as "nothing playing" so the pill stays hidden.
 */
final class NowPlaying {
    private static final String TAG = "TvHome.NowPlaying";

    interface Callback {
        /** Something is playing or paused; {@code artist} may be empty. */
        void onNowPlaying(CharSequence title, CharSequence artist, boolean playing);

        /** The cover of what is playing, or null when the app gives none. Called right after onNowPlaying. */
        default void onArt(android.graphics.Bitmap art) {
        }

        /** Nothing is playing. */
        void onNothing();

        /** The launcher has no notification access yet, so no session can be read. */
        void onNoAccess();
    }

    private final Context ctx;
    private final Callback callback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ComponentName listener;
    private MediaSessionManager manager;
    private MediaController controller;
    private boolean started;

    private final MediaController.Callback controllerCallback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            publish();
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            publish();
        }

        @Override
        public void onSessionDestroyed() {
            refresh();
        }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsChanged = this::pick;

    NowPlaying(Context context, Callback callback) {
        this.ctx = context.getApplicationContext();
        this.callback = callback;
        this.listener = new ComponentName(ctx, MediaListenerService.class);
    }

    void start() {
        if (started) {
            refresh();
            return;
        }
        manager = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
        if (manager == null) {
            callback.onNothing();
            return;
        }
        try {
            manager.addOnActiveSessionsChangedListener(sessionsChanged, listener, handler);
            started = true;
            pick(manager.getActiveSessions(listener));
        } catch (SecurityException e) {
            // No notification access yet: the pill asks for it.
            Log.i(TAG, "No notification access for the media pill");
            started = false;
            callback.onNoAccess();
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not follow media sessions", e);
            started = false;
            callback.onNothing();
        }
    }

    void stop() {
        if (controller != null) {
            controller.unregisterCallback(controllerCallback);
            controller = null;
        }
        if (started && manager != null) {
            try {
                manager.removeOnActiveSessionsChangedListener(sessionsChanged);
            } catch (RuntimeException ignored) {
                // Already gone with the service.
            }
        }
        started = false;
    }

    void previous() {
        if (controller != null) controller.getTransportControls().skipToPrevious();
    }

    void next() {
        if (controller != null) controller.getTransportControls().skipToNext();
    }

    void seekTo(long positionMs) {
        if (controller != null) controller.getTransportControls().seekTo(Math.max(0, positionMs));
    }

    void togglePlay() {
        if (controller == null) return;
        PlaybackState state = controller.getPlaybackState();
        if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
            controller.getTransportControls().pause();
        } else {
            controller.getTransportControls().play();
        }
    }

    private void refresh() {
        if (manager == null) return;
        try {
            pick(manager.getActiveSessions(listener));
        } catch (RuntimeException e) {
            callback.onNothing();
        }
    }

    /** Prefers a session that is playing now; otherwise the first one that has a title (paused). */
    private void pick(List<MediaController> sessions) {
        MediaController best = null;
        if (sessions != null) {
            for (MediaController c : sessions) {
                PlaybackState state = c.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
                    best = c;
                    break;
                }
                if (best == null && c.getMetadata() != null) best = c;
            }
        }
        if (best != null && controller != null && best.getSessionToken().equals(controller.getSessionToken())) {
            publish();
            return;
        }
        if (controller != null) controller.unregisterCallback(controllerCallback);
        controller = best;
        if (controller != null) controller.registerCallback(controllerCallback, handler);
        publish();
    }

    private void publish() {
        if (controller == null) {
            callback.onNothing();
            return;
        }
        MediaMetadata metadata = controller.getMetadata();
        CharSequence title = metadata == null ? null : metadata.getText(MediaMetadata.METADATA_KEY_TITLE);
        CharSequence artist = metadata == null ? null : metadata.getText(MediaMetadata.METADATA_KEY_ARTIST);
        if (TextUtils.isEmpty(title)) {
            callback.onNothing();
            return;
        }
        PlaybackState state = controller.getPlaybackState();
        boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
        callback.onNowPlaying(title, artist, playing);
        android.graphics.Bitmap art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        // Some apps announce the new song while still holding the old cover: for a moment after a change, the
        // same picture as the previous song is not trusted; the app's cover link is loaded instead.
        String key = title + "|" + artist;
        long now = android.os.SystemClock.uptimeMillis();
        if (!key.equals(artTrackKey)) {
            artTrackKey = key;
            artChangedAt = now;
            artStale = shownArt;
            uriTried = null;
        }
        if (art != null && artStale != null && now - artChangedAt < 2500 && (art == artStale || art.sameAs(artStale))) {
            art = null;
            handler.removeCallbacks(republish);
            handler.postDelayed(republish, 2700);
        }
        if (art == null && key.equals(fetchedKey)) art = fetchedBmp;
        if (art == null) {
            String uri = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
            if (TextUtils.isEmpty(uri)) uri = metadata.getString(MediaMetadata.METADATA_KEY_ART_URI);
            if (TextUtils.isEmpty(uri)) uri = metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
            if (!TextUtils.isEmpty(uri) && !uri.equals(uriTried)) {
                uriTried = uri;
                fetchArt(uri, key);
            }
        }
        shownArt = art;
        callback.onArt(art);
    }

    private String artTrackKey, uriTried, fetchedKey;
    private long artChangedAt;
    private android.graphics.Bitmap artStale, shownArt, fetchedBmp;
    private final Runnable republish = this::publish;

    /** Loads the cover from its link (http or content) off the main thread; used only when the app gave no usable picture. */
    private void fetchArt(final String uri, final String key) {
        new Thread(() -> {
            android.graphics.Bitmap b = null;
            try {
                java.io.InputStream in;
                if (uri.startsWith("http")) {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(uri).openConnection();
                    c.setConnectTimeout(4000);
                    c.setReadTimeout(4000);
                    in = c.getInputStream();
                } else {
                    in = ctx.getContentResolver().openInputStream(android.net.Uri.parse(uri));
                }
                if (in != null) {
                    try { b = android.graphics.BitmapFactory.decodeStream(in); } finally { in.close(); }
                }
            } catch (Exception ignored) { }
            final android.graphics.Bitmap fb = b;
            if (fb == null) return;
            handler.post(() -> {
                if (!key.equals(artTrackKey)) return;
                fetchedKey = key;
                fetchedBmp = fb;
                shownArt = fb;
                callback.onArt(fb);
            });
        }, "np-art").start();
    }

    /** Songs the app lists after the current one (only apps that publish a queue do), at most {@code max}. */
    java.util.List<TrackCard> upcoming(int max) {
        java.util.List<TrackCard> out = new java.util.ArrayList<>();
        if (controller == null) return out;
        try {
            java.util.List<android.media.session.MediaSession.QueueItem> q = controller.getQueue();
            PlaybackState st = controller.getPlaybackState();
            if (q == null || st == null) return out;
            long active = st.getActiveQueueItemId();
            int at = -1;
            for (int i = 0; i < q.size(); i++) if (q.get(i).getQueueId() == active) { at = i; break; }
            if (at < 0) return out;
            for (int i = at + 1; i < q.size() && out.size() < max; i++) {
                android.media.MediaDescription d = q.get(i).getDescription();
                out.add(new TrackCard(d.getTitle(), d.getSubtitle(), d.getIconBitmap()));
            }
        } catch (RuntimeException ignored) { }
        return out;
    }

    /** How far into the track it is, 0 to 100, or -1 when the app reports no duration or position. */
    int progressPercent() {
        long duration = durationMs();
        long position = positionMs();
        if (duration <= 0 || position < 0) return -1;
        return (int) Math.max(0, Math.min(100, position * 100 / duration));
    }

    /** The track's length in milliseconds, or -1 when the app reports none. */
    long durationMs() {
        if (controller == null) return -1;
        MediaMetadata metadata = controller.getMetadata();
        if (metadata == null) return -1;
        long duration = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        return duration > 0 ? duration : -1;
    }

    /** Where the track is now in milliseconds (moving on while it plays), or -1 when the app reports none. */
    long positionMs() {
        if (controller == null) return -1;
        PlaybackState state = controller.getPlaybackState();
        if (state == null) return -1;
        long position = state.getPosition();
        if (position < 0) return -1;
        if (state.getState() == PlaybackState.STATE_PLAYING) {
            long elapsed = android.os.SystemClock.elapsedRealtime() - state.getLastPositionUpdateTime();
            position += (long) (elapsed * state.getPlaybackSpeed());
        }
        long duration = durationMs();
        return duration > 0 ? Math.min(position, duration) : position;
    }
}
