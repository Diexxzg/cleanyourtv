package com.gathin.tvhome;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Looks a song's lyrics up on lrclib.net (free, no key). Synced lines when it has them, plain text otherwise. */
final class LyricsFetcher {
    static final class Result {
        String[] lines;
        long[] times;   // null for plain (unsynced) lyrics
    }

    interface Callback {
        /** On the main thread. result is null when nothing was found or there is no network. */
        void done(String key, Result result);
    }

    private static final Pattern TAG = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]");
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static String cachedKey;
    private static Result cached;

    private LyricsFetcher() {}

    static void fetch(final String title, final String artist, final long durationMs, final String key, final Callback cb) {
        if (key.equals(cachedKey) && cached != null) {
            cb.done(key, cached);
            return;
        }
        new Thread(() -> {
            Result r = null;
            try {
                r = lookup(title, artist, durationMs);
            } catch (Throwable ignored) {
                // offline, blocked, or odd JSON: just no lyrics
            }
            final Result out = r;
            if (out != null) { cachedKey = key; cached = out; }
            MAIN.post(() -> cb.done(key, out));
        }, "lyrics").start();
    }

    private static Result lookup(String title, String artist, long durationMs) throws Exception {
        String t = URLEncoder.encode(title, "UTF-8");
        String a = URLEncoder.encode(artist == null ? "" : artist, "UTF-8");
        String body = get("https://lrclib.net/api/get?track_name=" + t + "&artist_name=" + a
                + (durationMs > 0 ? "&duration=" + (durationMs / 1000) : ""));
        if (body != null) {
            Result r = fromJson(new JSONObject(body));
            if (r != null) return r;
        }
        body = get("https://lrclib.net/api/search?track_name=" + t + (artist == null || artist.isEmpty() ? "" : "&artist_name=" + a));
        if (body == null) return null;
        JSONArray arr = new JSONArray(body);
        Result plain = null;
        for (int i = 0; i < arr.length() && i < 8; i++) {
            Result r = fromJson(arr.getJSONObject(i));
            if (r == null) continue;
            if (r.times != null) return r;
            if (plain == null) plain = r;
        }
        return plain;
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "TVHome-launcher/3.24");
        try {
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private static Result fromJson(JSONObject o) {
        String synced = o.isNull("syncedLyrics") ? "" : o.optString("syncedLyrics", "");
        if (!synced.trim().isEmpty()) {
            Result r = parseLrc(synced);
            if (r != null) return r;
        }
        String plain = o.isNull("plainLyrics") ? "" : o.optString("plainLyrics", "");
        if (plain.trim().isEmpty()) return null;
        Result r = new Result();
        r.lines = plain.trim().split("\\r?\\n");
        return r;
    }

    private static final class Line implements Comparable<Line> {
        final long ms; final String text;
        Line(long ms, String text) { this.ms = ms; this.text = text; }
        @Override public int compareTo(Line o) { return Long.compare(ms, o.ms); }
    }

    private static Result parseLrc(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\r?\\n")) {
            Matcher m = TAG.matcher(raw);
            List<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                long min = Long.parseLong(m.group(1)), sec = Long.parseLong(m.group(2));
                long frac = 0;
                String f = m.group(3);
                if (f != null) {
                    frac = Long.parseLong(f);
                    if (f.length() == 1) frac *= 100; else if (f.length() == 2) frac *= 10;
                }
                stamps.add(min * 60000 + sec * 1000 + frac);
                end = m.end();
            }
            if (stamps.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long s : stamps) out.add(new Line(s, text));
        }
        if (out.isEmpty()) return null;
        Collections.sort(out);
        Result r = new Result();
        r.lines = new String[out.size()];
        r.times = new long[out.size()];
        for (int i = 0; i < out.size(); i++) {
            r.lines[i] = out.get(i).text;
            r.times[i] = out.get(i).ms;
        }
        return r;
    }
}
