package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

/** Private DNS switch for the panel "Proteccion" tile. Needs WRITE_SECURE_SETTINGS (adb pm grant). */
final class DnsGuard {
    static final String[] HOSTS = {"dns.adguard-dns.com", "adblock.dns.mullvad.net"};
    static final String[] NAMES = {"AdGuard", "Mullvad"};

    private DnsGuard() { }

    static int provider(Context c) {
        int i = c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).getInt("dns_provider", 0);
        return i < 0 || i >= HOSTS.length ? 0 : i;
    }

    static void nextProvider(Context c) {
        SharedPreferences sp = c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt("dns_provider", (provider(c) + 1) % HOSTS.length).apply();
        if (isOn(c)) set(c, true);   // apply the new provider right away
    }

    static boolean isOn(Context c) {
        try {
            return "hostname".equals(Settings.Global.getString(c.getContentResolver(), "private_dns_mode"))
                    && HOSTS[provider(c)].equals(Settings.Global.getString(c.getContentResolver(), "private_dns_specifier"));
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** @return false when the permission is missing or the system refuses. */
    static boolean set(Context c, boolean on) {
        try {
            if (on) {
                Settings.Global.putString(c.getContentResolver(), "private_dns_specifier", HOSTS[provider(c)]);
                return Settings.Global.putString(c.getContentResolver(), "private_dns_mode", "hostname");
            }
            return Settings.Global.putString(c.getContentResolver(), "private_dns_mode", "opportunistic");
        } catch (RuntimeException e) {
            return false;
        }
    }
}
