package com.gathin.tvhome;

import android.content.Context;
import android.content.pm.PackageManager;
import android.media.audiofx.Visualizer;
import android.os.SystemClock;

/**
 * How loud the music is right now, 0 to 1, for the pulsing background and music card.
 *
 * Real: the audio output's own level through a Visualizer, which needs the microphone permission
 * (Launcher settings asks for it; `pm grant com.gathin.tvhome android.permission.RECORD_AUDIO` also works).
 * Without that permission, or when the app playing blocks the capture and the level stays silent, it falls
 * back to a steady simulated rhythm so the effect still moves while music plays.
 */
final class BeatSource {
    private static final long SILENCE_FALLBACK_MS = 2500;

    static final int BANDS = 24;

    private Visualizer visualizer;
    private volatile float level;
    private volatile long lastSound;
    private long startedAt;
    private final java.util.Set<Object> owners = new java.util.HashSet<>();
    private final float[] bandBuf = new float[BANDS];

    /** Starts capturing; safe to call again. Returns false when it will run on the simulated rhythm. */
    boolean start(Object owner, Context context) {
        owners.add(owner);
        if (visualizer != null) return true;
        if (startedAt == 0) {
            startedAt = SystemClock.uptimeMillis();
            lastSound = startedAt;
        }
        if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        try {
            Visualizer v = new Visualizer(0);
            v.setEnabled(false);
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[0]);
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer vis, byte[] wave, int samplingRate) {
                    double sum = 0;
                    for (byte b : wave) {
                        double s = ((b & 0xFF) - 128) / 128.0;
                        sum += s * s;
                    }
                    float rms = (float) Math.sqrt(sum / Math.max(1, wave.length));
                    float target = Math.min(1f, rms * 4f);
                    level = target > level ? target : level * 0.8f + target * 0.2f;
                    if (rms > 0.01f) lastSound = SystemClock.uptimeMillis();
                }

                @Override
                public void onFftDataCapture(Visualizer vis, byte[] fft, int samplingRate) {
                    // fft[0], fft[1]: DC and Nyquist; then (real, imaginary) pairs, low to high frequency.
                    int pairs = (fft.length - 2) / 2;
                    if (pairs < 4) return;
                    for (int b = 0; b < BANDS; b++) {
                        int from = 1 + (int) Math.pow(pairs - 1, b / (double) BANDS);
                        int to = Math.max(from + 1, 1 + (int) Math.pow(pairs - 1, (b + 1) / (double) BANDS));
                        double peak = 0;
                        for (int k = from; k < Math.min(to, pairs); k++) {
                            double re = fft[2 * k], im = fft[2 * k + 1];
                            peak = Math.max(peak, Math.hypot(re, im));
                        }
                        float target = (float) Math.min(1.0, Math.sqrt(peak / 128.0) * 1.6);
                        bandBuf[b] = target > bandBuf[b] ? target : bandBuf[b] * 0.85f + target * 0.15f;
                    }
                }
            }, Visualizer.getMaxCaptureRate(), true, true);
            v.setEnabled(true);
            visualizer = v;
            return true;
        } catch (RuntimeException unavailable) {
            release();
            return false;
        }
    }

    /** This owner no longer needs the level; the capture ends when the last owner lets go. */
    void stop(Object owner) {
        owners.remove(owner);
        if (owners.isEmpty()) release();
    }

    private void release() {
        startedAt = 0;
        Visualizer v = visualizer;
        visualizer = null;
        if (v == null) return;
        try {
            v.setEnabled(false);
            v.release();
        } catch (RuntimeException ignored) { }
    }

    /** 0 to 1: the captured level, or the simulated rhythm (about 108 beats a minute) when there is none. */
    float level() {
        long now = SystemClock.uptimeMillis();
        boolean silent = now - lastSound > SILENCE_FALLBACK_MS && now - startedAt > SILENCE_FALLBACK_MS;
        if (visualizer != null && !silent) return level;
        double phase = (now % 556) / 556.0 * 2 * Math.PI;
        float s = (float) (0.5 + 0.5 * Math.sin(phase));
        return s * s;
    }

    /** Fills out[0..BANDS) with 0 to 1 bar heights, low to high pitch: the real spectrum, or a lively simulation. */
    void bands(float[] out) {
        int n = Math.min(out.length, BANDS);
        if (isReal()) {
            for (int i = 0; i < n; i++) out[i] = bandBuf[i];
            return;
        }
        long now = SystemClock.uptimeMillis();
        float lv = level();
        for (int i = 0; i < n; i++) {
            double wobble = 0.5 + 0.5 * Math.sin(now / (240.0 + 37.0 * i) + i * 1.7);
            double tilt = 1.0 - 0.55 * i / (double) BANDS;   // music has more bass than treble
            out[i] = (float) Math.min(1.0, (0.18 + 0.82 * lv) * (0.35 + 0.65 * wobble) * tilt + 0.04);
        }
    }

    /** True while the level comes from the real audio output. */
    boolean isReal() {
        long now = SystemClock.uptimeMillis();
        return visualizer != null && !(now - lastSound > SILENCE_FALLBACK_MS && now - startedAt > SILENCE_FALLBACK_MS);
    }
}
