package com.gathin.tvhome;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

/**
 * Windows the launcher draws over other apps through its accessibility service (no extra permission):
 * a small clock, the "island" when the song changes, the glass control panel and the global night veil.
 * Everything is off until Launcher settings turns it on, and every window is removed when its switch goes off.
 */
final class OverlayHost {
    private static final String CLOCK = "overlay_clock", ISLAND = "overlay_island", NIGHT_GLOBAL = "night_global", PANEL_KEY = "overlay_panel_key";
    private static final Handler H = new Handler(Looper.getMainLooper());

    private static HomeKeyService svc;
    private static WindowManager wm;
    private static SharedPreferences prefs;
    private static SharedPreferences.OnSharedPreferenceChangeListener prefListener;
    private static String front = "";
    private static boolean longHandled;

    private static View clockView;
    private static long clockUntil;
    private static LinearLayout islandView;
    private static View veil;
    private static LinearLayout panelView;

    private static NowPlaying np;
    private static CharSequence lastTitle, curTitle, curArtist;
    private static Bitmap curArt;
    private static boolean curPlaying;
    private static TextView panelTitle, panelArtist;
    private static ImageView panelCover, panelPlay;

    private OverlayHost() { }

    // ---- lifecycle -------------------------------------------------------------------------------------------

    /** True when any of the overlay features is on, so the service wants to see which app is in front. */
    static boolean wants(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        return p.getInt(CLOCK, 0) != 0 || p.getBoolean(ISLAND, false) || p.getBoolean(NIGHT_GLOBAL, false) || p.getInt(PANEL_KEY, 0) != 0;
    }

    static void attach(HomeKeyService service) {
        if (svc == service) { react(); return; }
        detach(null);
        svc = service;
        wm = (WindowManager) service.getSystemService(Context.WINDOW_SERVICE);
        prefs = service.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) { react(); }
        };
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
        H.postDelayed(tick, 30000);
        react();
    }

    static void detach(HomeKeyService service) {
        if (service != null && svc != service) return;
        H.removeCallbacks(tick);
        if (prefs != null && prefListener != null) prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        prefListener = null;
        removeView(clockView); clockView = null;
        removeView(islandView); islandView = null;
        removeView(veil); veil = null;
        removeView(panelView); panelView = null;
        RecentsOverlay.close();
        if (np != null) { np.stop(); np = null; }
        svc = null;
    }

    private static final Runnable tick = new Runnable() {
        @Override public void run() {
            if (svc == null) return;
            updateClock();
            updateNight();
            if (!inHome() && !RecentsOverlay.isOpen() && panelView == null) RecentsOverlay.capture(svc, front, null);
            H.postDelayed(this, 30000);
        }
    };

    private static void react() {
        if (svc == null) return;
        if (wants(svc)) svc.enableWindowEvents();
        updateClock();
        updateIsland();
        updateNight();
    }

    private static boolean inHome() {
        return front.isEmpty() || front.equals(svc.getPackageName());
    }

    static void onWindow(AccessibilityEvent event) {
        if (svc == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (event.getPackageName() == null || event.getClassName() == null) return;
        try {
            ComponentName window = new ComponentName(event.getPackageName().toString(), event.getClassName().toString());
            svc.getPackageManager().getActivityInfo(window, 0);
            front = window.getPackageName();
            RecentsOverlay.noteFront(svc, front);
        } catch (PackageManager.NameNotFoundException notAnActivity) {
            return;   // a dialog, the volume bar or one of these overlays: the app under it is still in front
        }
        updateClock();
    }

    /** True when the key was ours: opening or closing the panel, or Back while it is open. */
    static boolean onKey(KeyEvent event) {
        if (svc == null) return false;
        int code = event.getKeyCode();
        boolean first = event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0;
        int panelKey = prefs.getInt(PANEL_KEY, 0);
        if (panelView != null) {
            if (code == KeyEvent.KEYCODE_BACK || (panelKey != 0 && code == panelKey)) {
                if (first) closePanel();
                return true;
            }
            return false;   // the other keys reach the panel's own buttons
        }
        if (RecentsOverlay.isOpen()) {
            if (code == KeyEvent.KEYCODE_BACK || (panelKey != 0 && code == panelKey)) {
                if (first) RecentsOverlay.close();
                return true;
            }
            return false;   // the other keys reach the carousel itself
        }
        if (inHome()) return false;
        if (panelKey != 0 && code == panelKey) {
            // Short press: the Home panel over the app. Long press: recent apps in 3D.
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (event.getRepeatCount() == 0) longHandled = false;
                else if (event.getRepeatCount() == 1 && !longHandled) { longHandled = true; RecentsOverlay.open(svc, wm, front); }
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                if (!longHandled) openPanel();
                longHandled = false;
            }
            return true;
        }
        if (first && prefs.getInt(CLOCK, 0) == 1) showClockBriefly();
        return false;
    }

    // ---- shared bits -----------------------------------------------------------------------------------------

    private static int dp(float v) {
        return Math.round(v * svc.getResources().getDisplayMetrics().density);
    }

    private static void removeView(View v) {
        if (v == null || wm == null) return;
        try { wm.removeView(v); } catch (RuntimeException ignored) { }
    }

    private static WindowManager.LayoutParams params(int w, int h, boolean focusable) {
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | (focusable ? WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                : WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private static GradientDrawable shape(int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private static GradientDrawable glass(int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xF01C1C1E, 0xF40C0C0F});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), 0x38FFFFFF);
        return g;
    }

    private static StateListDrawable buttonBg(int radiusDp) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, shape(0x40FFFFFF, 0xF2FFFFFF, 2, radiusDp));
        s.addState(new int[]{android.R.attr.state_selected}, shape(0xE6F2F2F4, 0, 0, radiusDp));
        s.addState(new int[]{}, shape(0x33FFFFFF, 0, 0, radiusDp));
        return s;
    }

    private static TextView text(CharSequence t, int sp, boolean bold, int color) {
        TextView v = new TextView(svc);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        return v;
    }

    // ---- clock -----------------------------------------------------------------------------------------------

    private static void showClockBriefly() {
        clockUntil = SystemClock.uptimeMillis() + 5000;
        updateClock();
        H.removeCallbacks(clockExpire);
        H.postDelayed(clockExpire, 5200);
    }

    private static final Runnable clockExpire = OverlayHost::updateClock;

    private static void updateClock() {
        if (svc == null) return;
        int mode = prefs.getInt(CLOCK, 0);
        boolean show = !inHome() && (mode == 2 || (mode == 1 && clockUntil > SystemClock.uptimeMillis()));
        if (!show) {
            removeView(clockView);
            clockView = null;
            return;
        }
        if (clockView == null) {
            View v = homeClock();
            WindowManager.LayoutParams lp = params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = dp(CLOCK_X_DP);
            lp.y = dp(CLOCK_Y_DP);
            try { wm.addView(v, lp); } catch (RuntimeException e) { return; }
            clockView = v;
        }
    }

    /** Where Home puts its clock; tune here if it is a few pixels off on the TV. */
    private static final int CLOCK_X_DP = 48, CLOCK_Y_DP = 28;

    /** The clock block of Home: light time, small AM/PM, thin divider and the date, no capsule. */
    private static View homeClock() {
        LinearLayout row = new LinearLayout(svc);
        row.setOrientation(LinearLayout.HORIZONTAL);
        android.graphics.Typeface light = android.graphics.Typeface.create(svc.getString(R.string.font_light), android.graphics.Typeface.NORMAL);
        android.graphics.Typeface medium = android.graphics.Typeface.create(svc.getString(R.string.font_medium), android.graphics.Typeface.NORMAL);
        android.graphics.Typeface regular = android.graphics.Typeface.create(svc.getString(R.string.font_regular), android.graphics.Typeface.NORMAL);

        android.widget.TextClock time = new android.widget.TextClock(svc);
        time.setFormat12Hour("h:mm");
        time.setFormat24Hour("HH:mm");
        time.setTextColor(0xFFFFFFFF);
        time.setTextSize(30);
        time.setTypeface(light);
        time.setLetterSpacing(-0.04f);
        time.setFontFeatureSettings("tnum");
        time.setIncludeFontPadding(false);
        row.addView(time, new LinearLayout.LayoutParams(-2, -2));

        android.widget.TextClock ampm = new android.widget.TextClock(svc);
        ampm.setFormat12Hour("a");
        ampm.setFormat24Hour("");
        ampm.setTextColor(0xB3FFFFFF);
        ampm.setTextSize(12);
        ampm.setTypeface(medium);
        ampm.setLetterSpacing(0.08f);
        ampm.setAllCaps(true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-2, -2);
        ap.gravity = Gravity.BOTTOM;
        ap.leftMargin = dp(6);
        ap.bottomMargin = dp(6);
        row.addView(ampm, ap);

        View div = new View(svc);
        div.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(Math.max(1, dp(1)), dp(20));
        dp1.gravity = Gravity.BOTTOM;
        dp1.leftMargin = dp(12);
        dp1.rightMargin = dp(12);
        dp1.bottomMargin = dp(6);
        row.addView(div, dp1);

        android.widget.TextClock date = new android.widget.TextClock(svc);
        date.setFormat12Hour(svc.getString(R.string.date_format_home));
        date.setFormat24Hour(svc.getString(R.string.date_format_home));
        date.setTextColor(0xA6FFFFFF);
        date.setTextSize(11);
        date.setTypeface(regular);
        date.setLetterSpacing(0.14f);
        date.setAllCaps(true);
        date.setMaxLines(2);
        date.setLineSpacing(dp(6), 1f);
        date.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(150), -2);
        dl.gravity = Gravity.BOTTOM;
        dl.bottomMargin = dp(9);
        row.addView(date, dl);
        return row;
    }

    // ---- island ----------------------------------------------------------------------------------------------

    private static void ensureNowPlaying() {
        if (np != null || svc == null) return;
        np = new NowPlaying(svc, new NowPlaying.Callback() {
            @Override public void onNowPlaying(CharSequence title, CharSequence artist, boolean playing) {
                curTitle = title; curArtist = artist; curPlaying = playing;
                if (!TextUtils.isEmpty(title) && !title.equals(lastTitle)) {
                    boolean firstTitle = lastTitle == null;
                    lastTitle = title;
                    if (!firstTitle && prefs.getBoolean(ISLAND, false) && !inHome()) showIsland();
                }
                refreshPanelMusic();
            }
            @Override public void onArt(Bitmap art) { curArt = art; refreshPanelMusic(); }
            @Override public void onNothing() { curTitle = null; curArtist = null; curPlaying = false; curArt = null; refreshPanelMusic(); }
            @Override public void onNoAccess() { }
        });
        np.start();
    }

    private static void releaseNowPlayingIfIdle() {
        if (np != null && panelView == null && !prefs.getBoolean(ISLAND, false)) {
            np.stop();
            np = null;
            lastTitle = null;
        }
    }

    private static void updateIsland() {
        if (svc == null) return;
        if (prefs.getBoolean(ISLAND, false)) ensureNowPlaying();
        else {
            removeView(islandView);
            islandView = null;
            releaseNowPlayingIfIdle();
        }
    }

    private static void showIsland() {
        removeView(islandView);
        LinearLayout pill = new LinearLayout(svc);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(10), dp(10), dp(24), dp(10));
        pill.setBackground(shape(0xF0141416, 0x59FFFFFF, 1, 40));
        ImageView cover = new ImageView(svc);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(shape(0xFF2A2A2E, 0, 0, 30));
        cover.setClipToOutline(true);
        cover.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        if (curArt != null) cover.setImageBitmap(curArt);
        pill.addView(cover, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout texts = new LinearLayout(svc);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(14), 0, 0, 0);
        texts.addView(text(curTitle == null ? "" : curTitle, 18, true, 0xFFFFFFFF));
        if (!TextUtils.isEmpty(curArtist)) texts.addView(text(curArtist, 14, false, 0xB3FFFFFF));
        pill.addView(texts, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        WindowManager.LayoutParams lp = params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(26);
        try { wm.addView(pill, lp); } catch (RuntimeException e) { return; }
        islandView = pill;
        pill.setAlpha(0f);
        pill.setScaleX(0.6f);
        pill.setScaleY(0.6f);
        pill.setPivotY(0f);
        pill.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.1f)).start();
        final LinearLayout shown = pill;
        H.postDelayed(() -> {
            if (islandView != shown) return;
            shown.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(300).withEndAction(() -> {
                if (islandView == shown) { removeView(shown); islandView = null; }
            }).start();
        }, 3800);
    }

    // ---- night veil over every app ---------------------------------------------------------------------------

    private static boolean nightOn() {
        int mode = prefs.getInt("night_mode", 0);
        if (mode == 2) return true;
        if (mode != 1) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return hour >= 21 || hour < 7;
    }

    private static void updateNight() {
        if (svc == null) return;
        boolean want = prefs.getBoolean(NIGHT_GLOBAL, false) && nightOn();
        if (!want) {
            removeView(veil);
            veil = null;
            return;
        }
        if (veil != null) return;
        View v = new View(svc);
        v.setBackgroundColor(0x4D2A1200);   // a dark, slightly warm veil: easier on the eyes in the dark
        WindowManager.LayoutParams lp = params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, false);
        lp.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        try { wm.addView(v, lp); } catch (RuntimeException e) { return; }
        veil = v;
    }

    // ---- control panel over apps -----------------------------------------------------------------------------

    private static ImageView iconButton(int res, Runnable action) {
        ImageView b = new ImageView(svc);
        b.setImageResource(res);
        b.setPadding(dp(13), dp(13), dp(13), dp(13));
        b.setBackground(buttonBg(16));
        b.setFocusable(true);
        b.setClickable(true);
        b.setOnClickListener(v -> action.run());
        b.setOnFocusChangeListener((v, focused) -> tint((ImageView) v));
        return b;
    }

    /** White on dark glass; dark on the white "selected" fill, unless the focus ring is on it. */
    private static void tint(ImageView b) {
        b.setImageTintList(ColorStateList.valueOf(b.isSelected() && !b.isFocused() ? 0xFF111111 : 0xFFFFFFFF));
    }

    private static void mark(ImageView b, boolean on) {
        b.setSelected(on);
        tint(b);
    }

    private static TextView chip(String label, Runnable action) {
        TextView t = text(label, 18, true, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(11), dp(16), dp(11));
        t.setBackground(buttonBg(14));
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    /** The panel over apps is the Home panel itself, in a transparent activity. */
    private static void openPanel() {
        if (svc == null) return;
        Intent i = new Intent(svc, PanelOverActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        try { svc.startActivity(i); } catch (RuntimeException ignored) { }
    }

    private static void openPanelLegacy() {
        if (panelView != null || svc == null) return;
        LinearLayout col = new LinearLayout(svc);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(16), dp(18), dp(18));
        col.setBackground(glass(26));

        col.addView(text(svc.getString(R.string.overlay_panel_title), 20, true, 0xFFFFFFFF));

        // Music card: cover, title, artist and the three transport buttons.
        LinearLayout music = new LinearLayout(svc);
        music.setOrientation(LinearLayout.VERTICAL);
        music.setPadding(dp(12), dp(12), dp(12), dp(12));
        music.setBackground(shape(0x40000000, 0x38FFFFFF, 1, 20));
        LinearLayout top = new LinearLayout(svc);
        top.setGravity(Gravity.CENTER_VERTICAL);
        panelCover = new ImageView(svc);
        panelCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        panelCover.setBackground(shape(0xFF2A2A2E, 0, 0, 12));
        panelCover.setClipToOutline(true);
        panelCover.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        top.addView(panelCover, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout texts = new LinearLayout(svc);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, 0, 0);
        panelTitle = text("", 17, true, 0xFFFFFFFF);
        panelArtist = text("", 14, false, 0xB3FFFFFF);
        texts.addView(panelTitle);
        texts.addView(panelArtist);
        top.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        music.addView(top);
        LinearLayout transport = new LinearLayout(svc);
        transport.setGravity(Gravity.CENTER);
        transport.setPadding(0, dp(10), 0, 0);
        panelPlay = iconButton(R.drawable.ic_media_play, () -> { if (np != null) np.togglePlay(); });
        for (View b : new View[]{iconButton(R.drawable.ic_media_prev, () -> { if (np != null) np.previous(); }), panelPlay,
                iconButton(R.drawable.ic_media_next, () -> { if (np != null) np.next(); })}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(54), dp(54));
            p.setMargins(dp(6), 0, dp(6), 0);
            transport.addView(b, p);
        }
        music.addView(transport);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(12);
        col.addView(music, mp);

        // Actions: night, clock over apps, split screen, Home.
        LinearLayout actions = new LinearLayout(svc);
        actions.setGravity(Gravity.CENTER);
        final ImageView night = iconButton(R.drawable.ic_cp_night, null);
        night.setOnClickListener(v -> {
            boolean on = prefs.getInt("night_mode", 0) == 2 && prefs.getBoolean(NIGHT_GLOBAL, false);
            prefs.edit().putInt("night_mode", on ? 0 : 2).putBoolean(NIGHT_GLOBAL, !on ? true : prefs.getBoolean(NIGHT_GLOBAL, false)).apply();
            mark(night, !on);
        });
        mark(night, prefs.getInt("night_mode", 0) == 2 && prefs.getBoolean(NIGHT_GLOBAL, false));
        final ImageView clock = iconButton(R.drawable.ic_cp_clock, null);
        clock.setOnClickListener(v -> {
            int mode = (prefs.getInt(CLOCK, 0) + 1) % 3;
            prefs.edit().putInt(CLOCK, mode).apply();
            mark(clock, mode != 0);
            Toast.makeText(svc, mode == 0 ? R.string.night_off : mode == 1 ? R.string.clock_over_key : R.string.night_always, Toast.LENGTH_SHORT).show();
        });
        mark(clock, prefs.getInt(CLOCK, 0) != 0);
        ImageView split = iconButton(R.drawable.ic_cp_display, () -> {
            closePanel();
            H.postDelayed(() -> {
                if (svc != null && !svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)) {
                    Toast.makeText(svc, R.string.overlay_split_unavailable, Toast.LENGTH_LONG).show();
                }
            }, 250);
        });
        ImageView home = iconButton(R.drawable.ic_cp_apps, () -> { closePanel(); svc.openHome(); });
        for (View b : new View[]{night, clock, split, home}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(56), dp(56));
            p.setMargins(dp(6), 0, dp(6), 0);
            actions.addView(b, p);
        }
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(14);
        col.addView(actions, ap);

        // Volume.
        final AudioManager audio = (AudioManager) svc.getSystemService(Context.AUDIO_SERVICE);
        final TextView volLabel = text("", 18, true, 0xFFFFFFFF);
        volLabel.setGravity(Gravity.CENTER);
        final Runnable showVol = () -> {
            int max = Math.max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            volLabel.setText(svc.getString(R.string.overlay_volume, Math.round(100f * audio.getStreamVolume(AudioManager.STREAM_MUSIC) / max)));
        };
        showVol.run();
        LinearLayout vol = new LinearLayout(svc);
        vol.setGravity(Gravity.CENTER_VERTICAL);
        TextView less = chip("−", () -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0); showVol.run(); });
        TextView more = chip("+", () -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0); showVol.run(); });
        vol.addView(less, new LinearLayout.LayoutParams(dp(56), -2));
        vol.addView(volLabel, new LinearLayout.LayoutParams(0, -2, 1f));
        vol.addView(more, new LinearLayout.LayoutParams(dp(56), -2));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = dp(14);
        col.addView(vol, vp);

        // Screen brightness (the service's own dimming layer).
        LinearLayout dim = new LinearLayout(svc);
        dim.setGravity(Gravity.CENTER_VERTICAL);
        dim.addView(text(svc.getString(R.string.overlay_brightness), 16, false, 0xB3FFFFFF), new LinearLayout.LayoutParams(0, -2, 1f));
        for (final int pct : new int[]{100, 70, 40}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.leftMargin = dp(8);
            dim.addView(chip(pct + "%", () -> HomeKeyService.setDim(svc, pct)), p);
        }
        LinearLayout.LayoutParams dimLp = new LinearLayout.LayoutParams(-1, -2);
        dimLp.topMargin = dp(12);
        col.addView(dim, dimLp);

        WindowManager.LayoutParams lp = params(dp(340), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        lp.x = dp(36);
        try { wm.addView(col, lp); } catch (RuntimeException e) { return; }
        panelView = col;
        ensureNowPlaying();
        refreshPanelMusic();
        panelPlay.requestFocus();
    }

    private static void closePanel() {
        removeView(panelView);
        panelView = null;
        panelTitle = panelArtist = null;
        panelCover = panelPlay = null;
        releaseNowPlayingIfIdle();
    }

    private static void refreshPanelMusic() {
        if (panelView == null || panelTitle == null) return;
        panelTitle.setText(TextUtils.isEmpty(curTitle) ? svc.getString(R.string.overlay_nothing_playing) : curTitle);
        panelArtist.setText(curArtist == null ? "" : curArtist);
        if (curArt != null) panelCover.setImageBitmap(curArt); else panelCover.setImageDrawable(null);
        panelPlay.setImageResource(curPlaying ? R.drawable.ic_media_pause : R.drawable.ic_media_play);
    }
}
