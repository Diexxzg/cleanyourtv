package com.gathin.tvhome;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * The Home control panel, unchanged, shown over whatever app is in front: a transparent copy of the launcher
 * activity that opens the panel and closes itself when the panel closes. Started by OverlayHost.
 */
public class PanelOverActivity extends MainActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean opened, dismissed;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        hideWindow();   // only the panel's own window is seen
    }

    /** The launcher draws its own wallpaper, and fades its views in on resume: make this window one transparent pixel. */
    private void hideWindow() {
        try {
            getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            getWindow().setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
            getWindow().setLayout(1, 1);
            getWindow().getDecorView().setAlpha(0f);
        } catch (RuntimeException ignored) { }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideWindow();
        if (opened) return;
        opened = true;
        getWindow().getDecorView().post(this::showControlPanel);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        closeControlPanel();
    }

    @Override
    protected void onControlPanelDismissed() {
        dismissed = true;
        h.postDelayed(this::closeIfIdle, 350);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && dismissed) h.postDelayed(this::closeIfIdle, 350);
    }

    private void closeIfIdle() {
        if (!isFinishing() && hasWindowFocus()) finish();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
