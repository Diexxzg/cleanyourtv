package com.gathin.tvhome;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * The Home control panel, unchanged, shown over whatever app is in front: a transparent copy of the launcher
 * activity that opens the panel and closes itself when the panel closes. Started by OverlayHost.
 */
public class PanelOverActivity extends MainActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean opened, dismissed;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        View c = findViewById(android.R.id.content);
        if (c != null) c.setAlpha(0f);   // only the panel's own window is seen
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (opened) return;
        opened = true;
        getWindow().getDecorView().post(this::showControlPanel);
    }

    @Override
    protected void onControlPanelDismissed() {
        dismissed = true;
        h.postDelayed(this::closeIfIdle, 350);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && dismissed) h.postDelayed(this::closeIfIdle, 350);
    }

    private void closeIfIdle() {
        if (!isFinishing() && hasWindowFocus()) finish();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
