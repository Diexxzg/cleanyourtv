package com.gathin.tvhome;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Slow drifting colour clouds over Home in the colours of the cover now playing (Launcher settings: "Aurora").
 * Idle it costs nothing: hidden, no animator running.
 */
final class AuroraView extends View {
    private final Paint[] paints = {new Paint(Paint.ANTI_ALIAS_FLAG), new Paint(Paint.ANTI_ALIAS_FLAG), new Paint(Paint.ANTI_ALIAS_FLAG)};
    private final int[] colors = new int[3];
    private float radius;
    private int accent;
    private boolean on;
    private float t;
    private ValueAnimator drift;
    private long lastFrame;

    AuroraView(Context context) {
        super(context);
        setAlpha(0f);
        setVisibility(GONE);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** Shows the aurora in this cover colour, or fades it out. Safe to call as often as you like. */
    void setTarget(boolean show, int coverColor) {
        if (show && coverColor != 0) {
            if (coverColor != accent) {
                accent = coverColor;
                float[] hsv = new float[3];
                Color.colorToHSV(coverColor, hsv);
                float s = Math.max(0.55f, hsv[1]), v = Math.max(0.85f, hsv[2]);
                colors[0] = Color.HSVToColor(0x70, new float[]{hsv[0], s, v});
                colors[1] = Color.HSVToColor(0x58, new float[]{(hsv[0] + 38f) % 360f, s, v});
                colors[2] = Color.HSVToColor(0x58, new float[]{(hsv[0] + 322f) % 360f, s, v});
                rebuild();
            }
            on = true;
            setVisibility(VISIBLE);
            animate().cancel();
            animate().alpha(1f).setDuration(700).start();
            if (drift == null) {
                drift = ValueAnimator.ofFloat(0f, 1f);
                drift.setDuration(32000);
                drift.setRepeatCount(ValueAnimator.INFINITE);
                drift.setInterpolator(new LinearInterpolator());
                drift.addUpdateListener(a -> {
                    long now = android.os.SystemClock.uptimeMillis();
                    if (now - lastFrame < 40) return;   // about 25 frames a second is plenty for a slow drift
                    lastFrame = now;
                    t = (float) a.getAnimatedValue();
                    invalidate();
                });
                drift.start();
            }
        } else if (on) {
            on = false;
            animate().cancel();
            animate().alpha(0f).setDuration(600).withEndAction(() -> {
                if (!on) {
                    setVisibility(GONE);
                    stopDrift();
                }
            }).start();
        }
    }

    /** Home left the screen: stop animating, keep the state. */
    void pause() {
        stopDrift();
    }

    private void stopDrift() {
        if (drift != null) {
            drift.cancel();
            drift = null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild();
    }

    private void rebuild() {
        radius = Math.max(getWidth(), getHeight()) * 0.55f;
        if (radius <= 0f || colors[0] == 0) return;
        for (int i = 0; i < paints.length; i++) {
            paints[i].setShader(new RadialGradient(0, 0, radius, colors[i], colors[i] & 0x00FFFFFF, Shader.TileMode.CLAMP));
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (radius <= 0f) return;
        float w = getWidth(), h = getHeight(), a = (float) (t * 2 * Math.PI);
        draw(c, paints[0], w * (0.25f + 0.18f * (float) Math.sin(a)), h * (0.30f + 0.14f * (float) Math.cos(a)));
        draw(c, paints[1], w * (0.75f + 0.16f * (float) Math.cos(a * 1.0 + 1.7)), h * (0.55f + 0.16f * (float) Math.sin(a + 0.6)));
        draw(c, paints[2], w * (0.50f + 0.22f * (float) Math.sin(a + 3.1)), h * (0.85f + 0.10f * (float) Math.cos(a + 2.2)));
    }

    private void draw(Canvas c, Paint p, float x, float y) {
        c.save();
        c.translate(x, y);
        c.drawCircle(0, 0, radius, p);
        c.restore();
    }
}
