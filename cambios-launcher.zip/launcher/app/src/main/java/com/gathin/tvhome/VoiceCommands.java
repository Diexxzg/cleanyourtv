package com.gathin.tvhome;

import android.accessibilityservice.AccessibilityService;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.provider.Settings;
import android.view.KeyEvent;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Custom: what the voice assistant understands. The text arrives already recognised (on the TV, no Internet
 * needed); this only decides what it means. Spanish first, a few English words too.
 */
final class VoiceCommands {
    static final class Result {
        final boolean ok;
        final String title;
        final String sub;

        Result(boolean ok, String title, String sub) {
            this.ok = ok;
            this.title = title;
            this.sub = sub;
        }
    }

    private static final Pattern OPEN = Pattern.compile(
            "^(abre|abrir|abreme|ejecuta|ejecutar|inicia|iniciar|lanza|lanzar|enciende|pon|ponme|ve a|ir a|vamos a|open|launch|start)"
                    + "( la| el| los| las| una| un)?( app| aplicacion)?( de)? (.+)$");
    private static final Map<String, Integer> WORDS = new HashMap<>();

    static {
        WORDS.put("un", 1);
        WORDS.put("uno", 1);
        WORDS.put("una", 1);
        WORDS.put("dos", 2);
        WORDS.put("tres", 3);
        WORDS.put("cuatro", 4);
        WORDS.put("cinco", 5);
        WORDS.put("seis", 6);
        WORDS.put("siete", 7);
        WORDS.put("ocho", 8);
        WORDS.put("nueve", 9);
        WORDS.put("diez", 10);
        WORDS.put("quince", 15);
        WORDS.put("veinte", 20);
        WORDS.put("treinta", 30);
        WORDS.put("cuarenta", 40);
        WORDS.put("cincuenta", 50);
        WORDS.put("sesenta", 60);
        WORDS.put("setenta", 70);
        WORDS.put("ochenta", 80);
        WORDS.put("noventa", 90);
        WORDS.put("cien", 100);
    }

    private VoiceCommands() { }

    static Result run(AccessibilityService svc, String heard) {
        String t = norm(heard);
        if (t.isEmpty()) return fail("No te escuche", "Pulsa el boton y habla");
        Result r = sleep(svc, t);
        if (r == null) r = volume(svc, t);
        if (r == null) r = media(svc, t);
        if (r == null) r = screen(t, svc);
        if (r == null) r = navigate(svc, t);
        if (r == null) r = openApp(svc, t);
        return r != null ? r : fail("No entendi", heard);
    }

    // ---- text helpers ----------------------------------------------------------------------------------------

    static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD);
        n = n.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
        return n.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    private static boolean has(String t, String phrase) {
        return (" " + t + " ").contains(" " + phrase + " ");
    }

    private static boolean hasAny(String t, String... phrases) {
        for (String p : phrases) if (has(t, p)) return true;
        return false;
    }

    private static int wordCount(String t) {
        return t.isEmpty() ? 0 : t.split(" ").length;
    }

    /** A number said as digits or (when allowed) as a word; -1 when there is none. */
    private static int number(String t, boolean smallWords) {
        Matcher m = Pattern.compile("(\\d+)").matcher(t);
        if (m.find()) {
            try {
                return Integer.parseInt(m.group(1));
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        int total = 0;
        boolean found = false;
        for (String tok : t.split(" ")) {
            Integer v = WORDS.get(tok);
            if (v == null) continue;
            if (v < 10 && !smallWords) continue;
            total += v;
            found = true;
        }
        return found ? total : -1;
    }

    private static Result ok(String title, String sub) {
        return new Result(true, title, sub);
    }

    private static Result fail(String title, String sub) {
        return new Result(false, title, sub);
    }

    // ---- commands --------------------------------------------------------------------------------------------

    private static Result sleep(AccessibilityService svc, String t) {
        boolean timerWord = hasAny(t, "temporizador", "timer", "apagado", "dormir");
        if (timerWord && hasAny(t, "cancela", "cancelar", "quita", "quitar", "desactiva", "desactivar", "deten", "detener")) {
            return HomeKeyService.setSleepTimer(0)
                    ? ok("Temporizador cancelado", "")
                    : fail("No pude cancelarlo", "Activa la accesibilidad del launcher");
        }
        boolean off = hasAny(t, "apaga", "apagar", "apagate", "duerme", "dormir", "temporizador", "timer");
        if (!off || has(t, "pantalla")) return null;
        int minutes;
        int n = number(t, true);
        if (n > 0) {
            minutes = (has(t, "hora") || has(t, "horas")) ? n * 60 : n;
        } else if (has(t, "media hora")) {
            minutes = 30;
        } else if (hasAny(t, "tele", "tv", "television", "televisor") || t.equals("apaga") || t.equals("apagar")) {
            minutes = 1;
        } else {
            return fail("Cuantos minutos?", "Ej: apaga en 30 minutos");
        }
        minutes = Math.min(minutes, 600);
        if (!HomeKeyService.setSleepTimer(minutes)) {
            return fail("No pude programar el apagado", "Activa la accesibilidad del launcher");
        }
        return ok("La TV se apagara en " + (minutes == 1 ? "1 minuto" : minutes + " minutos"),
                "Di \"cancela el temporizador\" para detenerlo");
    }

    private static Result volume(AccessibilityService svc, String t) {
        boolean unmute = (hasAny(t, "quita", "quitar", "desactiva", "desactivar") && hasAny(t, "silencio", "mute"))
                || (hasAny(t, "activa", "activar", "reactiva", "reactivar", "pon") && has(t, "sonido"));
        boolean mute = !unmute && hasAny(t, "silencio", "silencia", "silenciar", "mute", "mutea");
        if (!unmute && !mute && !has(t, "volumen")) return null;
        AudioManager am = (AudioManager) svc.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return fail("No pude cambiar el volumen", "");
        if (unmute) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI);
            return ok("Sonido activado", "");
        }
        if (mute) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
            return ok("Silenciado", "");
        }
        int level = number(t, false);
        if (level >= 0) {
            level = Math.min(100, level);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * level / 100f), AudioManager.FLAG_SHOW_UI);
            return ok("Volumen al " + level + "%", "");
        }
        boolean up = hasAny(t, "sube", "subir", "aumenta", "aumentar", "mas", "up");
        boolean down = hasAny(t, "baja", "bajar", "reduce", "reducir", "menos", "down");
        if (!up && !down) return fail("Subo o bajo el volumen?", "Ej: sube el volumen");
        int steps = has(t, "mucho") ? 5 : 3;
        for (int i = 0; i < steps; i++) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                    i == 0 ? AudioManager.FLAG_SHOW_UI : 0);
        }
        return ok(up ? "Volumen arriba" : "Volumen abajo", "");
    }

    private static Result media(AccessibilityService svc, String t) {
        int wc = wordCount(t);
        if (wc > 3) return null;
        int key = -1;
        String name = "";
        if (wc <= 2 && hasAny(t, "pausa", "pausar", "pausalo", "pausala", "detente", "deten", "stop", "para")) {
            key = KeyEvent.KEYCODE_MEDIA_PAUSE;
            name = "Pausa";
        } else if (hasAny(t, "reanuda", "reanudar", "continua", "continuar")
                || (wc <= 2 && has(t, "play")) || (wc == 1 && hasAny(t, "reproduce", "reproducir", "sigue"))) {
            key = KeyEvent.KEYCODE_MEDIA_PLAY;
            name = "Reproduciendo";
        } else if (hasAny(t, "siguiente", "proxima", "proximo", "next", "salta", "saltar")) {
            key = KeyEvent.KEYCODE_MEDIA_NEXT;
            name = "Siguiente";
        } else if (hasAny(t, "anterior", "previa", "previous")) {
            key = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
            name = "Anterior";
        }
        if (key < 0) return null;
        AudioManager am = (AudioManager) svc.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return fail("No pude controlar la reproduccion", "");
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, key));
        return ok(name, "");
    }

    private static Result screen(String t, AccessibilityService svc) {
        if (hasAny(t, "pantalla negra", "solo audio", "sin imagen") || (has(t, "pantalla") && hasAny(t, "apaga", "apagar"))) {
            return HomeKeyService.setDim(svc, 0)
                    ? ok("Solo audio", "Cualquier tecla devuelve la imagen")
                    : fail("No pude apagar la pantalla", "Activa la accesibilidad del launcher");
        }
        if (has(t, "brillo")) {
            int n = hasAny(t, "maximo", "maxima", "completo") ? 100 : number(t, false);
            if (n < 0) return fail("Que brillo?", "Ej: brillo al 50");
            n = Math.max(1, Math.min(100, n));
            return HomeKeyService.setDim(svc, n)
                    ? ok("Brillo al " + n + "%", "")
                    : fail("No pude cambiar el brillo", "Activa la accesibilidad del launcher");
        }
        return null;
    }

    private static Result navigate(AccessibilityService svc, String t) {
        if (hasAny(t, "recientes", "multitarea")) {
            OverlayHost.voiceRecents();
            return ok("Apps recientes", "");
        }
        if (hasAny(t, "panel", "centro de control")) {
            OverlayHost.voicePanel();
            return ok("Panel de control", "");
        }
        if (hasAny(t, "ajustes del launcher", "ajustes del lanzador", "configuracion del launcher",
                "configuracion del lanzador")) {
            return start(svc, new Intent(svc, LauncherSettingsActivity.class), "Ajustes del launcher");
        }
        if (wordCount(t) <= 3 && hasAny(t, "ajustes", "configuracion")) {
            return start(svc, new Intent(Settings.ACTION_SETTINGS), "Ajustes");
        }
        if (wordCount(t) <= 3 && has(t, "wifi")) {
            return start(svc, new Intent(Settings.ACTION_WIFI_SETTINGS), "Wi-Fi");
        }
        if (wordCount(t) <= 3 && has(t, "bluetooth")) {
            return start(svc, new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth");
        }
        if (wordCount(t) <= 5 && hasAny(t, "inicio", "home")) {
            return svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    ? ok("Inicio", "") : fail("No pude ir al inicio", "");
        }
        if (wordCount(t) <= 2 && hasAny(t, "atras", "volver", "vuelve", "regresa", "regresar")) {
            return svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    ? ok("Atras", "") : fail("No pude volver", "");
        }
        return null;
    }

    private static Result start(Context ctx, Intent intent, String title) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return ok(title, "");
        } catch (ActivityNotFoundException e) {
            return fail("No encontre " + title, "");
        } catch (RuntimeException e) {
            return fail("No pude abrir " + title, "");
        }
    }

    // ---- opening apps ----------------------------------------------------------------------------------------

    private static Result openApp(AccessibilityService svc, String t) {
        String query = t;
        boolean explicit = false;
        Matcher m = OPEN.matcher(t);
        if (m.find()) {
            query = m.group(m.groupCount());
            explicit = true;
        } else if (wordCount(t) > 3) {
            return null;
        }
        PackageManager pm = svc.getPackageManager();
        String bestLabel = null;
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo ri : launchables(pm)) {
            if (svc.getPackageName().equals(ri.activityInfo.packageName)) continue;
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            if (label.isEmpty()) continue;
            int s = score(label, query);
            if (s > bestScore || (s == bestScore && best != null && label.length() < bestLabel.length())) {
                bestScore = s;
                best = ri;
                bestLabel = label;
            }
        }
        if (best == null || bestScore < 45) {
            return explicit ? fail("No encontre esa app", query) : null;
        }
        Intent launch = pm.getLeanbackLaunchIntentForPackage(best.activityInfo.packageName);
        if (launch == null) launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (launch == null) return fail("No pude abrir la app", String.valueOf(best.loadLabel(pm)));
        return start(svc, launch, "Abriendo " + best.loadLabel(pm));
    }

    private static List<ResolveInfo> launchables(PackageManager pm) {
        List<ResolveInfo> all = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                if (ri.activityInfo != null && seen.add(ri.activityInfo.packageName)) all.add(ri);
            }
        }
        return all;
    }

    private static int score(String label, String q) {
        if (q.isEmpty()) return 0;
        if (label.equals(q)) return 100;
        if (label.startsWith(q)) return 85;
        if (has(label, q) || label.contains(q)) return 70;
        if (label.length() >= 3 && q.contains(label)) return 60;
        int limit = Math.max(1, q.length() / 4);
        int d = distance(label, q);
        if (d <= limit) return 55 - d;
        return 0;
    }

    private static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] tmp = prev;
            prev = cur;
            cur = tmp;
        }
        return prev[b.length()];
    }
}
