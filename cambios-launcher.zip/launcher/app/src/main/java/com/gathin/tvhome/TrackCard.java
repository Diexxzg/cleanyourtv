package com.gathin.tvhome;

import android.graphics.Bitmap;

/** One song in the music mode's cover row: a track already played, the current one or one queued by the app. */
final class TrackCard {
    final CharSequence title, artist;
    Bitmap art;
    final String key;

    TrackCard(CharSequence title, CharSequence artist, Bitmap art) {
        this.title = title;
        this.artist = artist;
        this.art = art;
        this.key = title + "|" + (artist == null ? "" : artist);
    }
}
