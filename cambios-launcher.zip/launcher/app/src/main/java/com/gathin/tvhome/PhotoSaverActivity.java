package com.gathin.tvhome;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Photo screensaver: the launcher's own wallpaper pictures, one after another, each drifting and zooming slowly
 * (the Ken Burns effect) and dissolving into the next. Same rules as the clock screensaver: it only starts from
 * Home, any key returns to it, and it is never left in the back stack.
 */
public class PhotoSaverActivity extends Activity {
    private static final long SHOW_MS = 10_000L;
    private static final long FADE_MS = 1_400L;
    private static final long DRIFT_MS = SHOW_MS + FADE_MS + 600L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final List<File> pictures = new ArrayList<>();
    private ImageView[] layers;
    private int front;       // the layer on top
    private int next;        // index of the next picture
    private boolean reduced;
    private boolean running;
    private int loadId;

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(LauncherLocale.wrap(base));
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(0xFF000000);
        layers = new ImageView[2];
        for (int i = 0; i < 2; i++) {
            ImageView layer = new ImageView(this);
            layer.setScaleType(ImageView.ScaleType.CENTER_CROP);
            layer.setAlpha(0f);
            frame.addView(layer, new FrameLayout.LayoutParams(-1, -1));
            layers[i] = layer;
        }
        setContentView(frame);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
        Config cfg;
        try {
            cfg = Config.load(this);
        } catch (RuntimeException e) {
            finish();
            return;
        }
        reduced = cfg.reducedMotion;
        for (File file : cfg.wallpapers) if (file != null && file.isFile()) pictures.add(file);
        if (pictures.isEmpty()) {
            Toast.makeText(this, R.string.photos_none, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        Collections.shuffle(pictures, random);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pictures.isEmpty()) return;
        running = true;
        showNext();
    }

    @Override
    protected void onPause() {
        running = false;
        loadId++;
        handler.removeCallbacksAndMessages(null);
        super.onPause();
        finish();   // never left behind in the back stack
    }

    private void showNext() {
        if (!running) return;
        final File file = pictures.get(next % pictures.size());
        next++;
        final int id = ++loadId;
        new Thread(() -> {
            final Bitmap bitmap = decode(file);
            handler.post(() -> {
                if (!running || id != loadId) return;
                if (bitmap == null) {
                    if (pictures.size() > 1) handler.postDelayed(this::showNext, 300);
                    return;
                }
                present(bitmap);
                handler.postDelayed(this::showNext, SHOW_MS);
            });
        }, "photo-saver-decode").start();
    }

    private void present(Bitmap bitmap) {
        final ImageView old = layers[front];
        front = 1 - front;
        ImageView layer = layers[front];
        layer.animate().cancel();
        layer.setImageBitmap(bitmap);
        layer.setScaleX(1f);
        layer.setScaleY(1f);
        layer.setTranslationX(0f);
        layer.setTranslationY(0f);
        layer.setAlpha(0f);
        layer.bringToFront();
        long fade = reduced ? Motion.REDUCED_MS : FADE_MS;
        // Fades run as their own animators so the slow drift below keeps its own, much longer duration.
        ObjectAnimator.ofFloat(layer, View.ALPHA, 0f, 1f).setDuration(fade).start();
        ObjectAnimator out = ObjectAnimator.ofFloat(old, View.ALPHA, old.getAlpha(), 0f);
        out.setDuration(fade);
        out.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (old.getAlpha() == 0f) old.setImageDrawable(null);
            }
        });
        out.start();
        if (!reduced) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            float zoom = 1.12f + random.nextFloat() * 0.08f;
            float dx = (random.nextBoolean() ? 1 : -1) * dm.widthPixels * (0.015f + random.nextFloat() * 0.02f);
            float dy = (random.nextBoolean() ? 1 : -1) * dm.heightPixels * (0.010f + random.nextFloat() * 0.02f);
            // The same slow drift keeps going while the next picture dissolves in over it.
            layer.animate().scaleX(zoom).scaleY(zoom).translationX(dx).translationY(dy)
                    .setDuration(DRIFT_MS).setInterpolator(new LinearInterpolator()).start();
        }
    }

    /** The picture scaled down to about the screen's size, so a large photo does not fill the TV's memory. */
    private Bitmap decode(File file) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getPath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= dm.widthPixels && bounds.outHeight / (sample * 2) >= dm.heightPixels) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(file.getPath(), options);
        } catch (RuntimeException | OutOfMemoryError e) {
            return null;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // The key that wakes the saver should not also act on Home, so it is consumed here.
        if (event.getAction() == KeyEvent.ACTION_UP) finish();
        return true;
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        finish();
        return true;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
