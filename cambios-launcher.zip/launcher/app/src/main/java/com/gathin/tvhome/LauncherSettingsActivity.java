package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Remote-friendly settings owned by the launcher; system settings stay one row away. */
public final class LauncherSettingsActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(LauncherLocale.wrap(base));   // locale
    }

    static final String EXTRA_REORDER = "com.gathin.tvhome.extra.REORDER_FROM_SETTINGS";
    private SharedPreferences choices;
    private final TextView[] columnChoices = new TextView[4];
    private final TextView[] rowChoices = new TextView[4];
    private static final int[] DOCK_OPACITIES = {100, 70, 50, 30};
    private final TextView[] dockChoices = new TextView[DOCK_OPACITIES.length];
    private static final String[] CLOCK_FORMATS = {"system", "12", "24"};
    private final TextView[] clockChoices = new TextView[CLOCK_FORMATS.length];
    /** Custom: how much Home darkens the wallpaper picture or video, in percent. */
    static final String WALLPAPER_SHADE_KEY = "wallpaper_shade";
    private static final int[] SHADES = {0, 20, 40, 60};
    private final TextView[] shadeChoices = new TextView[SHADES.length];
    /** Custom: Bluetooth rune and connected-device count in the Wi-Fi pill (default on). */
    static final String BLUETOOTH_PILL_KEY = "bluetooth_pill";
    private static final int REQUEST_BLUETOOTH = 45;
    private TextView bluetoothChoice;
    private int shade;
    private TextView wallpaperChoice;
    private TextView videoWallpaperChoice;
    private TextView animationsChoice;
    private TextView soundsChoice;
    private TextView topBarChoice;
    private TextView namesChoice;
    private TextView zoomChoice;
    private TextView liquidChoice;
    private TextView saverChoice, saverZoomChoice;
    private TextView marginChoice;
    private TextView advancedChoice;
    private TextView followThemeChoice;
    private TextView openOnStartChoice;
    private int columns;
    private int rowsBelowDock;
    private int dockOpacity;
    private String clockFormat;
    private boolean animations;
    private boolean advancedEffects;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_launcher_settings);
        choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        Config config = Config.load(this);
        View reorderChoice = findViewById(R.id.reorderChoice);
        reorderChoice.setVisibility(config.launcherSettingsButton ? View.VISIBLE : View.GONE);
        reorderChoice.setOnClickListener(v -> {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_REORDER, true));
            finish();
        });
        columns = config.columns;
        rowsBelowDock = config.rowsBelowDock;
        dockOpacity = config.dockOpacity;
        clockFormat = config.clockFormat;
        animations = config.animations;
        advancedEffects = config.animations && config.advancedEffects;

        int[] ids = {R.id.columns4, R.id.columns5, R.id.columns6, R.id.columns7};
        for (int i = 0; i < ids.length; i++) {
            final int value = i + 4;
            columnChoices[i] = findViewById(ids[i]);
            columnChoices[i].setOnClickListener(v -> {
                if (columns == value) return;
                columns = value;
                choices.edit().putInt("columns", value).apply();
                changed();
                refresh();
            });
        }
        int[] rowIds = {R.id.rows0, R.id.rows1, R.id.rows2, R.id.rows3};
        for (int i = 0; i < rowIds.length; i++) {
            final int value = i;
            rowChoices[i] = findViewById(rowIds[i]);
            rowChoices[i].setOnClickListener(v -> {
                if (rowsBelowDock == value) return;
                rowsBelowDock = value;
                choices.edit().putInt(Config.ROWS_BELOW_DOCK_KEY, value).apply();
                changed();
                refresh();
            });
        }
        int[] dockIds = {R.id.dock100, R.id.dock70, R.id.dock50, R.id.dock30};
        for (int i = 0; i < dockIds.length; i++) {
            final int value = DOCK_OPACITIES[i];
            dockChoices[i] = findViewById(dockIds[i]);
            dockChoices[i].setOnClickListener(v -> {
                if (dockOpacity == value) return;
                dockOpacity = value;
                choices.edit().putInt(Config.DOCK_OPACITY_KEY, value).apply();
                changed();
                refresh();
            });
        }
        int[] clockIds = {R.id.clockSystem, R.id.clock12, R.id.clock24};
        for (int i = 0; i < clockIds.length; i++) {
            final String value = CLOCK_FORMATS[i];
            clockChoices[i] = findViewById(clockIds[i]);
            clockChoices[i].setOnClickListener(v -> {
                if (value.equals(clockFormat)) return;
                clockFormat = value;
                choices.edit().putString(Config.CLOCK_FORMAT_KEY, value).apply();
                changed();
                refresh();
            });
        }
        shade = choices.getInt(WALLPAPER_SHADE_KEY, 0);
        int[] shadeIds = {R.id.shade0, R.id.shade20, R.id.shade40, R.id.shade60};
        for (int i = 0; i < shadeIds.length; i++) {
            final int value = SHADES[i];
            shadeChoices[i] = findViewById(shadeIds[i]);
            shadeChoices[i].setOnClickListener(v -> {
                if (shade == value) return;
                shade = value;
                if (value == 0) choices.edit().remove(WALLPAPER_SHADE_KEY).apply();
                else choices.edit().putInt(WALLPAPER_SHADE_KEY, value).apply();
                changed();
                refresh();
            });
        }
        // Mirror text alignment without globally opting the launcher into RTL. Numeric rows
        // still need explicit ordering in Android's no-supportsRtl compatibility mode.
        if (getResources().getBoolean(R.bool.rtl_menu_bar))
            findViewById(android.R.id.content).setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (getResources().getBoolean(R.bool.rtl_app_grid)) {
            reverseRow(columnChoices);
            reverseRow(rowChoices);
            reverseRow(dockChoices);
            reverseRow(clockChoices);
            reverseRow(shadeChoices);
        }
        bluetoothChoice = findViewById(R.id.bluetoothChoice);
        bluetoothChoice.setOnClickListener(v -> {
            boolean current = choices.getBoolean(BLUETOOTH_PILL_KEY, true);
            if (current && needsBluetoothPermission()) {
                // It is on but cannot count yet: OK asks for the permission instead of switching it off.
                requestPermissions(new String[] {"android.permission.BLUETOOTH_CONNECT"}, REQUEST_BLUETOOTH);
                return;
            }
            boolean on = !current;
            choices.edit().putBoolean(BLUETOOTH_PILL_KEY, on).apply();
            changed();
            refresh();
            if (on && needsBluetoothPermission()) {
                requestPermissions(new String[] {"android.permission.BLUETOOTH_CONNECT"}, REQUEST_BLUETOOTH);
            }
        });
        wallpaperChoice = findViewById(R.id.wallpaperChoice);
        wallpaperChoice.setOnClickListener(v -> showWallpaperPicker());
        videoWallpaperChoice = findViewById(R.id.videoWallpaperChoice);
        videoWallpaperChoice.setOnClickListener(v -> showVideoPicker());
        animationsChoice = findViewById(R.id.animationsChoice);
        animationsChoice.setOnClickListener(v -> {
            animations = !animations;
            if (!animations) advancedEffects = false;
            choices.edit().putBoolean("animations", animations)
                    .putBoolean("advanced_effects", advancedEffects).apply();
            changed();
            refresh();
        });
        soundsChoice = findViewById(R.id.soundsChoice);
        soundsChoice.setOnClickListener(v -> {
            SoftSounds.setEnabled(this, !SoftSounds.enabled(this));
            refresh();
        });
        topBarChoice = findViewById(R.id.topBarChoice);
        topBarChoice.setOnClickListener(v -> {
            int secs = choices.getInt("topbar_hide_s", 6);
            choices.edit().putInt("topbar_hide_s", secs == 6 ? 10 : secs == 10 ? 20 : secs == 20 ? 0 : 6).apply();
            refresh();
        });
        // Names under every app (rebuilds Home), the zoom when an app opens, the screensaver's kind and the screen margin.
        namesChoice = findViewById(R.id.namesChoice);
        namesChoice.setOnClickListener(v -> {
            choices.edit().putBoolean("show_names", !namesOn()).apply();
            changed();
            refresh();
        });
        liquidChoice = findViewById(R.id.liquidChoice);
        liquidChoice.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.TIRAMISU) return;
            choices.edit().putBoolean(LiquidGlass.KEY, !choices.getBoolean(LiquidGlass.KEY, true)).apply();
            changed();
            refresh();
        });
        zoomChoice = findViewById(R.id.zoomChoice);
        zoomChoice.setOnClickListener(v -> {
            choices.edit().putBoolean("open_zoom", !choices.getBoolean("open_zoom", true)).apply();
            refresh();
        });
        saverChoice = findViewById(R.id.saverChoice);
        saverChoice.setOnClickListener(v -> {
            choices.edit().putBoolean("saver_photos", !choices.getBoolean("saver_photos", false)).apply();
            refresh();
        });
        saverZoomChoice = findViewById(R.id.saverZoomChoice);
        saverZoomChoice.setOnClickListener(v -> {
            choices.edit().putBoolean("saver_zoom", !choices.getBoolean("saver_zoom", false)).apply();
            refresh();
        });
        marginChoice = findViewById(R.id.marginChoice);
        marginChoice.setOnClickListener(v -> {
            int pct = choices.getInt("safe_margin", 0);
            choices.edit().putInt("safe_margin", pct < 2 ? 2 : pct < 4 ? 4 : pct < 6 ? 6 : 0).apply();
            changed();
            refresh();
        });
        advancedChoice = findViewById(R.id.advancedChoice);
        advancedChoice.setOnClickListener(v -> {
            if (advancedEffects) {
                setAdvanced(false);
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.advanced_effects)
                        .setMessage(R.string.advanced_effects_warning)
                        .setPositiveButton(R.string.enable, (dialog, which) -> setAdvanced(true))
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
        openOnStartChoice = findViewById(R.id.openOnStartChoice);
        if (config.openOnStartChoice) {
            openOnStartChoice.setVisibility(View.VISIBLE);
            openOnStartChoice.setOnClickListener(v -> showOpenOnStartPicker());
        }
        followThemeChoice = findViewById(R.id.followThemeChoice);
        followThemeChoice.setOnClickListener(v -> {
            if (!hasOnTvChoices()) return;
            choices.edit().remove("columns").remove(Config.ROWS_BELOW_DOCK_KEY).remove("animations")
                    .remove("advanced_effects").remove(Config.WALLPAPER_CHOICE_KEY)
                    .remove(Config.DOCK_OPACITY_KEY).remove(Config.CLOCK_FORMAT_KEY).remove(OpenOnStart.KEY).remove(WALLPAPER_SHADE_KEY).commit();
            Config current = Config.load(this);
            shade = 0;
            columns = current.columns;
            rowsBelowDock = current.rowsBelowDock;
            dockOpacity = current.dockOpacity;
            clockFormat = current.clockFormat;
            animations = current.animations;
            advancedEffects = current.animations && current.advancedEffects;
            changed();
            refresh();
        });
        findViewById(R.id.defaultHomeChoice).setOnClickListener(v ->
                open(new Intent(this, HomeSettingsActivity.class)));
        findViewById(R.id.tvSettingsChoice).setOnClickListener(v ->
                open(SystemSettings.intent(this, Settings.ACTION_SETTINGS)));
        refresh();
        if (config.launcherSettingsButton) reorderChoice.requestFocus();
        else columnChoices[Math.max(0, Math.min(columns - 4, 3))].requestFocus();
    }

    private void reverseRow(TextView[] views) {
        LinearLayout row = (LinearLayout) views[0].getParent();
        row.removeAllViews();
        for (int i = views.length - 1; i >= 0; i--) row.addView(views[i]);
    }

    private void showWallpaperPicker() {
        File dir = Config.dir(this);
        List<File> images = new java.util.ArrayList<>(WallpaperRotation.images(
                dir == null ? null : new File(dir, "wallpapers")));
        // A theme with a single wallpaper.jpg offers that picture too (Config maps the choice back to it).
        File single = dir == null ? null : new File(dir, Config.WALLPAPER_NAME);
        if (single != null && single.isFile()) images.add(0, single);
        String[] labels = new String[images.size() + 1];
        for (int i = 0; i < images.size(); i++) labels[i] = images.get(i).getName();
        labels[images.size()] = getString(R.string.wallpaper_none);
        String current = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        int checked = "none".equals(current) ? images.size()
                : indexOf(images, current);
        new AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_label)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == images.size()) {
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY, "none").apply();
                    } else {
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY,
                                images.get(which).getName()).apply();
                    }
                    changed();
                    Toast.makeText(this, R.string.wallpaper_applied, Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setPositiveButton(R.string.wallpaper_pick_image, (dialog, which) -> showImagePicker())
                .setNeutralButton(R.string.wallpaper_theme_default, (dialog, which) -> {
                    choices.edit().remove(Config.WALLPAPER_CHOICE_KEY).apply();
                    changed();
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ---- custom: pick a wallpaper picture from the TV ---------------------------------------------------

    private static final int REQUEST_IMAGES = 43;
    private static final int REQUEST_PICK_IMAGE = 44;
    /** Pictures are shrunk to this on copy, so a 12 MP photo never costs a modest TV box its memory. */
    private static final int MAX_WALLPAPER_WIDTH = 1920;
    private static final int MAX_WALLPAPER_HEIGHT = 1080;
    private static final String PICKED_PREFIX = "fondo_";

    private String imagePermission() {
        return Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_IMAGES" : "android.permission.READ_EXTERNAL_STORAGE";
    }

    /** Browse with the TV's file picker, or list the pictures the TV has indexed. Picking one copies it. */
    private void showImagePicker() {
        List<String> labels = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        labels.add(getString(R.string.wallpaper_browse));
        actions.add(this::browseImageFiles);
        if (checkSelfPermission(imagePermission()) == PackageManager.PERMISSION_GRANTED) {
            addStoreImages(labels, actions);
        } else {
            labels.add(getString(R.string.wallpaper_tv_images));
            actions.add(() -> requestPermissions(new String[] {imagePermission()}, REQUEST_IMAGES));
        }
        new AlertDialog.Builder(this).setTitle(R.string.wallpaper_pick_image)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** The TV's own file picker (Files), when the firmware has one. */
    private void browseImageFiles() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        try {
            startActivityForResult(pick, REQUEST_PICK_IMAGE);
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            // Try the older action next.
        }
        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
        get.addCategory(Intent.CATEGORY_OPENABLE);
        get.setType("image/*");
        try {
            startActivityForResult(get, REQUEST_PICK_IMAGE);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.wallpaper_no_browser, Toast.LENGTH_LONG).show();
        }
    }

    /** The pictures the TV has indexed (Download, Pictures, DCIM...), newest first. */
    private void addStoreImages(List<String> labels, List<Runnable> actions) {
        String[] projection = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME};
        int added = 0;
        try (Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            while (cursor != null && cursor.moveToNext() && added < 40) {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                labels.add(name == null ? "imagen" : name);
                actions.add(() -> copyImage(uri));
                added++;
            }
        } catch (RuntimeException e) {
            // The list simply stays shorter.
        }
    }

    /**
     * Shrinks the picture to at most 1920x1080 (turning it upright if the camera stored it sideways), saves it
     * as a JPEG in the launcher's wallpapers folder and makes it the chosen wallpaper. A video wallpaper would
     * hide it, so that one is removed.
     */
    private void copyImage(Uri uri) {
        File dir = Config.dir(this);
        if (dir == null) {
            Toast.makeText(this, R.string.wallpaper_failed, Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, R.string.wallpaper_copying, Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File folder = new File(dir, "wallpapers");
            File target = new File(folder, PICKED_PREFIX + System.currentTimeMillis() + ".jpg");
            boolean ok = false;
            try {
                if (!folder.isDirectory() && !folder.mkdirs()) throw new IOException("no folder");
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("no stream");
                    BitmapFactory.decodeStream(in, null, bounds);
                }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("not a picture");
                int sample = 1;
                while (bounds.outWidth / (sample * 2) >= MAX_WALLPAPER_WIDTH
                        && bounds.outHeight / (sample * 2) >= MAX_WALLPAPER_HEIGHT) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                Bitmap bitmap;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("no stream");
                    bitmap = BitmapFactory.decodeStream(in, null, opts);
                }
                if (bitmap == null) throw new IOException("decode failed");
                int degrees = 0;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in != null) {
                        int orientation = new ExifInterface(in).getAttributeInt(
                                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                        if (orientation == ExifInterface.ORIENTATION_ROTATE_90) degrees = 90;
                        else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) degrees = 180;
                        else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) degrees = 270;
                    }
                } catch (IOException | RuntimeException e) {
                    // No readable EXIF: keep the picture as it is.
                }
                float scale = Math.min(1f, Math.min(
                        (float) MAX_WALLPAPER_WIDTH / bitmap.getWidth(),
                        (float) MAX_WALLPAPER_HEIGHT / bitmap.getHeight()));
                if (degrees != 0 || scale < 1f) {
                    Matrix matrix = new Matrix();
                    if (degrees != 0) matrix.postRotate(degrees);
                    if (scale < 1f) matrix.postScale(scale, scale);
                    Bitmap adjusted = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                    if (adjusted != bitmap) bitmap.recycle();
                    bitmap = adjusted;
                }
                try (OutputStream out = new FileOutputStream(target)) {
                    ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                }
                bitmap.recycle();
            } catch (IOException | RuntimeException | OutOfMemoryError e) {
                ok = false;
            }
            if (!ok) target.delete();
            final boolean done = ok;
            runOnUiThread(() -> {
                if (done) {
                    // Only the latest picked picture is kept.
                    File[] old = target.getParentFile().listFiles();
                    if (old != null) {
                        for (File f : old) {
                            if (f.getName().startsWith(PICKED_PREFIX) && !f.equals(target)) f.delete();
                        }
                    }
                    boolean hadVideo = VideoWallpaper.exists(this);
                    if (hadVideo) VideoWallpaper.file(this).delete();
                    choices.edit().putString(Config.WALLPAPER_CHOICE_KEY, target.getName()).apply();
                    changed();
                    Toast.makeText(this, hadVideo ? R.string.wallpaper_applied_no_video : R.string.wallpaper_applied,
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, R.string.wallpaper_failed, Toast.LENGTH_LONG).show();
                }
                refresh();
            });
        }).start();
    }

    // ---- custom: video wallpaper ----------------------------------------------------------------------

    private static final int REQUEST_VIDEOS = 41;
    private static final int REQUEST_PICK_VIDEO = 42;
    private static final long MAX_VIDEO_BYTES = 300L * 1024 * 1024;
    private static final String[] VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".3gp"};

    /** Android 12 and later: counting connected devices needs the user's OK. */
    private boolean needsBluetoothPermission() {
        return Build.VERSION.SDK_INT >= 31
                && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED;
    }

    private String videoPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_VIDEO" : "android.permission.READ_EXTERNAL_STORAGE";
    }

    /**
     * One list: browse with the TV's file picker, then the videos sitting in the launcher's own folder (the
     * same one the wallpaper pictures live in), then the videos the TV has indexed. Picking one copies it.
     */
    private void showVideoPicker() {
        List<String> labels = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        labels.add(getString(R.string.video_wallpaper_browse));
        actions.add(this::browseVideoFiles);
        File dir = Config.dir(this);
        if (dir != null) {
            List<File> own = new ArrayList<>();
            collectVideos(new File(dir, "wallpapers"), own);
            collectVideos(new File(dir, "videos"), own);
            collectVideos(dir, own);
            for (File file : own) {
                labels.add(file.getName() + "  (" + (file.length() / (1024 * 1024)) + " MB)");
                actions.add(() -> copyVideo(Uri.fromFile(file)));
            }
        }
        if (checkSelfPermission(videoPermission()) == PackageManager.PERMISSION_GRANTED) {
            addStoreVideos(labels, actions);
        } else {
            labels.add(getString(R.string.video_wallpaper_tv_videos));
            actions.add(() -> requestPermissions(new String[] {videoPermission()}, REQUEST_VIDEOS));
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle(R.string.video_wallpaper_label);
        dialog.setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run());
        if (VideoWallpaper.exists(this)) {
            dialog.setNeutralButton(R.string.video_wallpaper_remove, (d, which) -> {
                VideoWallpaper.file(this).delete();
                changed();
                refresh();
            });
        }
        dialog.setNegativeButton(android.R.string.cancel, null).show();
    }

    private static void collectVideos(File folder, List<File> out) {
        File[] entries = folder == null ? null : folder.listFiles();
        if (entries == null) return;
        java.util.Arrays.sort(entries, java.util.Comparator.comparing(File::getName));
        for (File entry : entries) {
            String name = entry.getName().toLowerCase(java.util.Locale.ROOT);
            if (!entry.isFile() || entry.length() <= 0 || out.size() >= 40) continue;
            for (String extension : VIDEO_EXTENSIONS) {
                if (name.endsWith(extension)) {
                    out.add(entry);
                    break;
                }
            }
        }
    }

    /** The TV's own file picker (Files), when the firmware has one. */
    private void browseVideoFiles() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("video/*");
        try {
            startActivityForResult(pick, REQUEST_PICK_VIDEO);
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            // Try the older action next.
        }
        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
        get.addCategory(Intent.CATEGORY_OPENABLE);
        get.setType("video/*");
        try {
            startActivityForResult(get, REQUEST_PICK_VIDEO);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.video_wallpaper_no_browser, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            copyVideo(data.getData());
        }
        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            copyImage(data.getData());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.bluetooth_pill_permission, Toast.LENGTH_LONG).show();
            }
            changed();
            refresh();
            return;
        }
        if (requestCode == REQUEST_IMAGES) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showImagePicker();
            } else {
                Toast.makeText(this, R.string.wallpaper_permission, Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != REQUEST_VIDEOS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showVideoPicker();
        } else {
            Toast.makeText(this, R.string.video_wallpaper_permission, Toast.LENGTH_LONG).show();
        }
    }

    /** The videos the TV has indexed (Download, Movies, DCIM...), newest first. */
    private void addStoreVideos(List<String> labels, List<Runnable> actions) {
        String[] projection = {MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE};
        int added = 0;
        try (Cursor cursor = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection,
                null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")) {
            while (cursor != null && cursor.moveToNext() && added < 40) {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                long size = cursor.getLong(2);
                Uri uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                labels.add((name == null ? "video" : name) + "  (" + (size / (1024 * 1024)) + " MB)");
                actions.add(() -> copyVideo(uri));
                added++;
            }
        } catch (RuntimeException e) {
            // The list simply stays shorter.
        }
    }

    private void copyVideo(Uri uri) {
        Toast.makeText(this, R.string.video_wallpaper_copying, Toast.LENGTH_LONG).show();
        new Thread(() -> {
            File temp = new File(getFilesDir(), "video_wallpaper.tmp");
            boolean ok = false;
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(temp)) {
                if (in != null) {
                    byte[] buffer = new byte[64 * 1024];
                    long total = 0;
                    int read;
                    while ((read = in.read(buffer)) > 0) {
                        out.write(buffer, 0, read);
                        total += read;
                        if (total > MAX_VIDEO_BYTES) throw new IOException("too big");
                    }
                    ok = total > 0;
                }
            } catch (IOException | RuntimeException e) {
                ok = false;
            }
            if (ok) ok = temp.renameTo(VideoWallpaper.file(this));
            if (!ok) temp.delete();
            final boolean done = ok;
            runOnUiThread(() -> {
                Toast.makeText(this, done ? R.string.video_wallpaper_applied : R.string.video_wallpaper_failed,
                        Toast.LENGTH_LONG).show();
                if (done) changed();
                refresh();
            });
        }).start();
    }

    /** Off, then every app with a TV entry point by name. Saved at once; it is read on the next boot. */
    private void showOpenOnStartPicker() {
        PackageManager pm = getPackageManager();
        List<String[]> apps = new ArrayList<>();
        Intent tv = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(tv, 0)) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            boolean seen = false;
            for (String[] a : apps) seen |= a[1].equals(pkg);
            if (!seen) apps.add(new String[]{r.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(apps, (a, b) -> a[0].compareToIgnoreCase(b[0]));
        String[] labels = new String[apps.size() + 1];
        labels[0] = getString(R.string.off);
        String current = choices.getString(OpenOnStart.KEY, "");
        int checked = 0;
        for (int i = 0; i < apps.size(); i++) {
            labels[i + 1] = apps.get(i)[0];
            if (apps.get(i)[1].equals(current)) checked = i + 1;
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.open_on_start_label)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == 0) choices.edit().remove(OpenOnStart.KEY).apply();
                    else {
                        OpenOnStart.skipThisBoot(this);
                        choices.edit().putString(OpenOnStart.KEY, apps.get(which - 1)[1]).apply();
                    }
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** The picked app's name, its package when it is gone, or Off. */
    private String openOnStartLabel() {
        String pkg = choices.getString(OpenOnStart.KEY, "");
        if (pkg.isEmpty()) return getString(R.string.off);
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private static int indexOf(List<File> images, String name) {
        if (name == null) return -1;
        for (int i = 0; i < images.size(); i++) {
            if (images.get(i).getName().equals(name)) return i;
        }
        return -1;
    }

    /**
     * A choice was saved. Home rebuilds when it next resumes because the change count moved, whether these
     * settings are left with Back or with the remote's Home button (which cancels the activity result).
     */
    private void changed() {
        setResult(RESULT_OK);
        choices.edit().putLong(Config.SETTINGS_REVISION_KEY,
                choices.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private void setAdvanced(boolean enabled) {
        advancedEffects = enabled;
        choices.edit().putBoolean("advanced_effects", enabled).apply();
        changed();
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < columnChoices.length; i++) {
            columnChoices[i].setSelected(columns == i + 4);
        }
        for (int i = 0; i < rowChoices.length; i++) {
            rowChoices[i].setSelected(rowsBelowDock == i);
        }
        for (int i = 0; i < dockChoices.length; i++) {
            dockChoices[i].setSelected(dockOpacity == DOCK_OPACITIES[i]);
        }
        for (int i = 0; i < clockChoices.length; i++) {
            clockChoices[i].setSelected(CLOCK_FORMATS[i].equals(clockFormat));
        }
        for (int i = 0; i < shadeChoices.length; i++) {
            shadeChoices[i].setSelected(shade == SHADES[i]);
        }
        boolean bluetoothOn = choices.getBoolean(BLUETOOTH_PILL_KEY, true);
        bluetoothChoice.setText(getString(R.string.bluetooth_pill_state,
                getString(bluetoothOn ? R.string.on : R.string.off))
                + (bluetoothOn && needsBluetoothPermission() ? getString(R.string.bluetooth_pill_needs_ok) : ""));
        soundsChoice.setText(getString(R.string.sounds_state,
                getString(SoftSounds.enabled(this) ? R.string.on : R.string.off)));
        int hideSecs = choices.getInt("topbar_hide_s", 6);
        topBarChoice.setText(getString(R.string.topbar_hide_state,
                hideSecs == 0 ? getString(R.string.off) : getString(R.string.topbar_hide_secs, hideSecs)));
        namesChoice.setText(getString(R.string.show_names_state, getString(namesOn() ? R.string.on : R.string.off)));
        boolean liquidSupported = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU;
        liquidChoice.setText(getString(R.string.liquid_glass_state,
                getString(liquidSupported && choices.getBoolean(LiquidGlass.KEY, true) ? R.string.on : R.string.off))
                + (liquidSupported ? "" : getString(R.string.liquid_glass_needs)));
        liquidChoice.setAlpha(liquidSupported ? 1f : 0.5f);
        zoomChoice.setText(getString(R.string.open_zoom_state,
                getString(choices.getBoolean("open_zoom", true) ? R.string.on : R.string.off)));
        saverChoice.setText(getString(R.string.saver_state,
                getString(choices.getBoolean("saver_photos", false) ? R.string.saver_photos : R.string.saver_clock)));
        saverZoomChoice.setText(getString(R.string.saver_zoom_state,
                getString(choices.getBoolean("saver_zoom", false) ? R.string.on : R.string.off)));
        int marginPct = choices.getInt("safe_margin", 0);
        marginChoice.setText(getString(R.string.safe_margin_state,
                marginPct <= 0 ? getString(R.string.off) : getString(R.string.safe_margin_value, marginPct)));
        animationsChoice.setText(getString(R.string.animations_state,
                getString(animations ? R.string.on : R.string.off)));
        advancedChoice.setText(getString(R.string.advanced_effects_state,
                getString(advancedEffects ? R.string.on : R.string.off)));
        advancedChoice.setEnabled(animations);
        advancedChoice.setAlpha(animations ? 1f : 0.5f);
        String wallpaperCurrent = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        wallpaperChoice.setText(getString(R.string.wallpaper_state,
                "none".equals(wallpaperCurrent) ? getString(R.string.wallpaper_none)
                        : wallpaperCurrent != null && wallpaperCurrent.startsWith(PICKED_PREFIX)
                                ? getString(R.string.wallpaper_mine)
                        : wallpaperCurrent != null ? wallpaperCurrent
                        : getString(R.string.wallpaper_theme_default)));
        videoWallpaperChoice.setText(getString(R.string.video_wallpaper_state,
                getString(VideoWallpaper.exists(this) ? R.string.on : R.string.off)));
        openOnStartChoice.setText(getString(R.string.open_on_start_state, openOnStartLabel()));
        followThemeChoice.setSelected(!hasOnTvChoices());
    }

    /** The user's choice for names under every app; the theme's own setting when none was made. */
    private boolean namesOn() {
        return choices.getBoolean("show_names", getResources().getBoolean(R.bool.always_show_names));
    }

    private boolean hasOnTvChoices() {
        return choices.contains("columns") || choices.contains(Config.ROWS_BELOW_DOCK_KEY)
                || choices.contains("animations") || choices.contains("advanced_effects")
                || choices.contains(Config.WALLPAPER_CHOICE_KEY) || choices.contains(Config.DOCK_OPACITY_KEY)
                || choices.contains(Config.CLOCK_FORMAT_KEY) || choices.contains(OpenOnStart.KEY)
                || choices.contains(WALLPAPER_SHADE_KEY);
    }

    private void open(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_LONG).show();
        }
    }
}
