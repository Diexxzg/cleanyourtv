package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/**
 * Custom: three little bars that dance while music plays (the media pill's equalizer). Paused or with reduced
 * motion they rest as short bars. It redraws about 15 times a second, and only while it is playing, attached
 * and on screen, so it costs a modest TV box next to nothing.
 */
public final class EqualizerView extends View {
    private static final int BARS = 3;
    private static final long FRAME_MS = 66;
    private static final float[] SPEED = {0.0075f, 0.0097f, 0.0062f};
    private static final float[] PHASE = {0f, 1.9f, 3.7f};

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bar = new RectF();
    private boolean playing;
    private boolean reducedMotion;
    private boolean running;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            invalidate();
            postDelayed(this, FRAME_MS);
        }
    };

    public EqualizerView(Context context) {
        this(context, null);
    }

    public EqualizerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(0xFFFFFFFF);
    }

    void setPlaying(boolean value) {
        if (playing == value) return;
        playing = value;
        update();
        invalidate();
    }

    void setReducedMotion(boolean value) {
        reducedMotion = value;
        update();
    }

    private void update() {
        boolean shouldRun = playing && !reducedMotion && isAttachedToWindow()
                && getWindowVisibility() == VISIBLE && getVisibility() == VISIBLE;
        if (shouldRun == running) return;
        running = shouldRun;
        removeCallbacks(tick);
        if (running) post(tick);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        update();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        update();
    }

    @Override
    protected void onVisibilityChanged(View changed, int visibility) {
        super.onVisibilityChanged(changed, visibility);
        update();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float gap = w * 0.16f;
        float barWidth = (w - gap * (BARS - 1)) / BARS;
        float radius = barWidth / 2f;
        long now = SystemClock.uptimeMillis();
        paint.setAlpha(playing ? 255 : 140);
        for (int i = 0; i < BARS; i++) {
            float level;
            if (!playing || reducedMotion) {
                level = 0.28f;   // resting bars
            } else {
                level = 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(now * SPEED[i] + PHASE[i]));
            }
            float barHeight = Math.max(barWidth, h * level);
            float left = i * (barWidth + gap);
            bar.set(left, h - barHeight, left + barWidth, h);
            canvas.drawRoundRect(bar, radius, radius, paint);
        }
    }
}
