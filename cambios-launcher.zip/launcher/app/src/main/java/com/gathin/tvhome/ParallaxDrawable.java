package com.gathin.tvhome;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

/**
 * Custom: tvOS-style depth for a tile's picture. An adaptive icon is drawn as two layers (background and
 * foreground) that slide against each other; any other picture (a banner) gets a small counter-shift. A
 * light band sweeps across it when the tile takes focus. Parallax drives the offsets.
 */
final class ParallaxDrawable extends Drawable {
    private final Drawable base;
    private final Drawable bg;
    private final Drawable fg;
    private final Rect bgBounds = new Rect();
    private final Rect fgBounds = new Rect();
    private final Paint shinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix shineMatrix = new Matrix();
    private final Shader shine;
    private float offX;
    private float offY;
    private float sweep = -1f;
    ValueAnimator animator;

    ParallaxDrawable(Drawable base) {
        this.base = base;
        if (base instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable a = (AdaptiveIconDrawable) base;
            bg = a.getBackground();
            fg = a.getForeground();
        } else {
            bg = null;
            fg = null;
        }
        shine = new LinearGradient(0f, 0f, 100f, 0f, new int[] {0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF},
                new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        shinePaint.setShader(shine);
    }

    /** The picture underneath, for code that needs the real thing (the focus glow reads its colours). */
    Drawable inner() {
        return base;
    }

    /** x and y in -1..1 (which way the layers are pushed), sweep 0..1 across the tile or -1 for none. */
    void set(float x, float y, float sweepPos) {
        offX = x;
        offY = y;
        sweep = sweepPos;
        invalidateSelf();
    }

    void reset() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        set(0f, 0f, -1f);
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        base.setBounds(bounds);
        if (bg != null) bgBounds.set(bg.getBounds());
        if (fg != null) fgBounds.set(fg.getBounds());
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float amp = b.width() * 0.035f;
        boolean moving = offX != 0f || offY != 0f;
        int save = canvas.save();
        if (bg != null && fg != null && moving) {
            Path mask = ((AdaptiveIconDrawable) base).getIconMask();
            canvas.clipPath(mask);
            drawLayer(canvas, bg, bgBounds, -offX * amp * 0.6f, -offY * amp * 0.6f);
            drawLayer(canvas, fg, fgBounds, offX * amp, offY * amp);
        } else if (bg == null && moving) {
            // A flat picture: a slight zoom so its edges never show, and a small counter-shift.
            canvas.scale(1.05f, 1.05f, b.exactCenterX(), b.exactCenterY());
            canvas.translate(-offX * amp * 0.5f, -offY * amp * 0.5f);
            base.draw(canvas);
        } else {
            base.draw(canvas);
        }
        canvas.restoreToCount(save);
        if (sweep >= 0f && sweep <= 1f) drawShine(canvas, b);
    }

    private void drawLayer(Canvas canvas, Drawable layer, Rect home, float dx, float dy) {
        layer.setBounds(home.left + Math.round(dx), home.top + Math.round(dy),
                home.right + Math.round(dx), home.bottom + Math.round(dy));
        layer.draw(canvas);
        layer.setBounds(home);
    }

    private void drawShine(Canvas canvas, Rect b) {
        float w = b.width();
        float band = w * 0.45f;
        float x = b.left - band + sweep * (w + band);
        shineMatrix.setScale(band / 100f, 1f);
        shineMatrix.postTranslate(x, 0f);
        shine.setLocalMatrix(shineMatrix);
        shinePaint.setShader(shine);   // the paint takes the moved matrix only when handed the shader again
        int save = canvas.save();
        if (base instanceof AdaptiveIconDrawable) canvas.clipPath(((AdaptiveIconDrawable) base).getIconMask());
        else canvas.clipRect(b);
        canvas.rotate(14f, b.exactCenterX(), b.exactCenterY());
        canvas.drawRect(x - 2f, b.top - b.height(), x + band + 2f, b.bottom + b.height(), shinePaint);
        canvas.restoreToCount(save);
    }

    @Override public void setAlpha(int alpha) {
        base.setAlpha(alpha);
        shinePaint.setAlpha(alpha);
    }

    @Override public void setColorFilter(ColorFilter filter) {
        base.setColorFilter(filter);
        if (bg != null) bg.setColorFilter(filter);
        if (fg != null) fg.setColorFilter(filter);
    }

    @Override public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    @Override public int getIntrinsicWidth() {
        return base.getIntrinsicWidth();
    }

    @Override public int getIntrinsicHeight() {
        return base.getIntrinsicHeight();
    }
}
