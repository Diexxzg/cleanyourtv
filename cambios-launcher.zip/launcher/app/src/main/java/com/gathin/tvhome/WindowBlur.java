package com.gathin.tvhome;

import android.os.Build;
import android.view.WindowManager;

/**
 * Blur behind a panel or the app library (Android 12+): the compositor blurs what is behind the window, the
 * wallpaper picture or video included. Where the TV does not support it the flag does nothing, and the dim the
 * caller already sets stays as the fallback.
 */
final class WindowBlur {
    private WindowBlur() {
    }

    /** True where the compositor can blur behind windows (Android 12+ and enabled by the TV); false means use the dark fallback. */
    static boolean supported(android.content.Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        try {
            WindowManager wm = (WindowManager) context.getSystemService(android.content.Context.WINDOW_SERVICE);
            return wm != null && wm.isCrossWindowBlurEnabled();
        } catch (RuntimeException e) {
            return false;
        }
    }

    static void apply(WindowManager.LayoutParams params, int radiusPx) {
        if (params == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            params.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            params.setBlurBehindRadius(radiusPx);
        } catch (RuntimeException ignored) {
            // Never let a cosmetic effect stop a panel from opening.
        }
    }
}
