package com.gathin.tvhome;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

/**
 * Custom: the welcome when the TV starts (Novedades > Bienvenida). Home fades in from black while the whole
 * picture eases back from a slight zoom and the clock settles into place. Once per process, so changing a
 * setting (which rebuilds Home) never replays it.
 */
final class WelcomeAnimation {
    static final String KEY = "welcome_anim";
    private static boolean played;

    private WelcomeAnimation() { }

    static void play(Context ctx, FrameLayout root, View clockRow, boolean reducedMotion) {
        if (played) return;
        played = true;
        if (reducedMotion || !ctx.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY, true)) return;
        final float density = ctx.getResources().getDisplayMetrics().density;
        final View cover = new View(ctx);
        cover.setBackgroundColor(0xFF000000);
        cover.setClickable(false);
        cover.setFocusable(false);
        root.addView(cover, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        cover.setTranslationZ(1000f * density);
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        root.setPivotX(dm.widthPixels / 2f);
        root.setPivotY(dm.heightPixels / 2f);
        root.setScaleX(1.07f);
        root.setScaleY(1.07f);
        if (clockRow != null) clockRow.setTranslationY(-16f * density);
        cover.animate().alpha(0f).setStartDelay(150).setDuration(1100)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .withEndAction(() -> root.removeView(cover)).start();
        root.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(1500)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
        if (clockRow != null) {
            clockRow.animate().translationY(0f).setStartDelay(500).setDuration(800)
                    .setInterpolator(new OvershootInterpolator(1.1f)).start();
        }
    }
}
