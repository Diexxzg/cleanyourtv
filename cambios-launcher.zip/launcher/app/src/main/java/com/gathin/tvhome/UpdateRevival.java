package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/**
 * Puts the accessibility helpers back on the enabled list right after this app is updated and when the TV
 * finishes booting, so an update does not leave them off until Home is opened. Needs WRITE_SECURE_SETTINGS
 * (pm grant), like ServiceRepair itself.
 */
public class UpdateRevival extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final PendingResult pending = goAsync();
        try {
            if (Config.load(context).restoreKeyServices) ServiceRepair.restore(context);
        } catch (RuntimeException ignored) {
            // Never let the repair break the update.
        }
        // ServiceRepair finishes its add/remove/add cycle on its own thread (about 2 s): keep the process alive for it.
        new Handler(Looper.getMainLooper()).postDelayed(pending::finish, 3500);
    }
}
