package com.gathin.tvhome;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Custom: "Novedades", the page for the newest features: icon depth, welcome, day/night video, the clock
 * editor, the voice assistant and updates. Built in code so it adds no layout of its own; it uses the same
 * row style and background as Launcher settings.
 */
public final class LabSettingsActivity extends Activity {
    private interface Txt {
        String get();
    }

    private static final int REQ_VIDEO = 51;
    private static final int REQ_MIC = 61;
    private static final int[] VOICE_KEYS = {0, 231, 84, 219, 183, 184, 185, 186};
    private static final String[] VOICE_NAMES = {"Desactivada", "Boton de voz del mando", "Boton de busqueda",
            "Boton del asistente", "Boton rojo", "Boton verde", "Boton amarillo", "Boton azul"};
    private static final int[] NIGHT_HOURS = {18, 19, 20, 21, 22, 23};
    private static final int[] DAY_HOURS = {5, 6, 7, 8, 9, 10};

    private SharedPreferences p;
    private LinearLayout list;
    private FrameLayout previewBox;
    private final List<Runnable> refreshers = new ArrayList<>();
    private File pickTarget;
    private UpdateChecker.Info found;
    private boolean busy;
    private String downloadStatus = "";
    private TextView firstRow;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        p = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundResource(R.drawable.settings_bg);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(96), dp(48), dp(96), dp(64));
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
        build();
        refreshAll();
        if (firstRow != null) firstRow.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();   // permissions or the install switch may have changed while away
    }

    // ---- the page --------------------------------------------------------------------------------------------

    private void build() {
        title("Novedades");

        section("Iconos y bienvenida");
        toggle("Parallax en los iconos", Parallax.KEY, true, true);
        toggle("Animacion de bienvenida al encender", WelcomeAnimation.KEY, true, true);

        section("Video de fondo de dia y de noche");
        videoRow("Video de dia", VideoWallpaper.file(this));
        videoRow("Video de noche", VideoWallpaper.nightFile(this));
        hours("La noche empieza a las", VideoWallpaper.NIGHT_FROM, 19, NIGHT_HOURS);
        hours("El dia empieza a las", VideoWallpaper.DAY_FROM, 7, DAY_HOURS);
        note("Con un solo video, ese se usa siempre. Con los dos, cambia solo segun la hora.");

        section("Reloj");
        toggle("Estilo de reloj personalizado", ClockStyle.ON, false, true);
        previewBox = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x44000000);
        bg.setCornerRadius(dp(18));
        previewBox.setBackground(bg);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120));
        plp.topMargin = dp(10);
        list.addView(previewBox, plp);
        refreshers.add(this::rebuildPreview);
        choice("Fuente", ClockStyle.FONT, ClockStyle.FONTS);
        cycleInt("Tamano", ClockStyle.SCALE, 100, ClockStyle.SCALES, null);
        choice("Relleno", ClockStyle.FILL, ClockStyle.FILLS);
        choice("Color", ClockStyle.COLOR, ClockStyle.COLOR_NAMES);

        section("Voz");
        row(() -> "Boton para hablar: " + voiceName(p.getInt(VoiceController.KEY, 0)), () -> {
            int cur = indexOf(VOICE_KEYS, p.getInt(VoiceController.KEY, 0));
            p.edit().putInt(VoiceController.KEY, VOICE_KEYS[(cur + 1) % VOICE_KEYS.length]).apply();
        });
        row(() -> "Permiso del microfono: " + (VoiceController.hasPermission(this) ? "concedido" : "pedir (OK)"), () -> {
            if (!VoiceController.hasPermission(this)) requestPermissions(new String[] {Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        });
        row(() -> "Probar la voz ahora", this::testVoice);
        note("Prueba: abre YouTube, sube el volumen, volumen al 30, apaga en 30 minutos, cancela el temporizador, "
                + "pausa, siguiente, pantalla negra, brillo al 50, inicio, atras, recientes, panel.");
        note("Funciona sin Internet si la TV trae el reconocimiento de voz instalado. Algunos mandos no entregan su "
                + "microfono a las apps: en ese caso usa un boton de color.");

        section("Actualizaciones");
        note("Version instalada: " + versionName());
        toggle("Buscar actualizaciones solas", UpdateChecker.AUTO, true, false);
        row(() -> busy && downloadStatus.isEmpty() ? "Buscando..." : "Buscar actualizacion ahora", this::checkNow);
        row(() -> !downloadStatus.isEmpty() ? "Descargando " + downloadStatus
                : found != null && found.newer ? "Instalar la actualizacion (" + shortDate(found.published) + ")"
                : "Instalar actualizacion: no hay una pendiente", this::installNow);
        row(() -> "Permiso para instalar desde el launcher: "
                + (getPackageManager().canRequestPackageInstalls() ? "permitido" : "pedir (OK)"), this::allowInstalls);
        note("Las actualizaciones vienen de la ultima version publicada en GitHub (" + UpdateChecker.REPO + ").");
    }

    // ---- row builders ----------------------------------------------------------------------------------------

    private void title(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        t.setTextColor(0xFFFFFFFF);
        list.addView(t);
    }

    private void section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setTextColor(0xB3FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(30);
        list.addView(t, lp);
    }

    private void note(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTextColor(0x99FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        list.addView(t, lp);
    }

    private void row(final Txt text, final Runnable click) {
        final TextView t = new TextView(this, null, 0, R.style.SettingsRow);
        t.setFocusable(true);
        t.setClickable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        lp.topMargin = dp(10);
        list.addView(t, lp);
        if (firstRow == null) firstRow = t;
        t.setOnClickListener(v -> {
            click.run();
            refreshAll();
        });
        refreshers.add(() -> t.setText(text.get()));
    }

    private void toggle(final String label, final String key, final boolean def, final boolean affectsHome) {
        row(() -> label + ": " + (p.getBoolean(key, def) ? "Si" : "No"), () -> {
            p.edit().putBoolean(key, !p.getBoolean(key, def)).apply();
            if (affectsHome) changed();
        });
    }

    private void choice(final String label, final String key, final String[] names) {
        row(() -> label + ": " + names[Math.max(0, Math.min(names.length - 1, p.getInt(key, 0)))], () -> {
            p.edit().putInt(key, (p.getInt(key, 0) + 1) % names.length).apply();
            changed();
        });
    }

    private void cycleInt(final String label, final String key, final int def, final int[] values, final String[] names) {
        row(() -> label + ": " + (names != null ? names[indexOf(values, p.getInt(key, def))]
                : values[indexOf(values, p.getInt(key, def))] + "%"), () -> {
            int next = (indexOf(values, p.getInt(key, def)) + 1) % values.length;
            p.edit().putInt(key, values[next]).apply();
            changed();
        });
    }

    private void hours(final String label, final String key, final int def, final int[] values) {
        row(() -> label + ": " + String.format(Locale.US, "%02d:00", values[indexOf(values, p.getInt(key, def))]), () -> {
            int next = (indexOf(values, p.getInt(key, def)) + 1) % values.length;
            p.edit().putInt(key, values[next]).apply();
            changed();
        });
    }

    private static int indexOf(int[] values, int v) {
        for (int i = 0; i < values.length; i++) if (values[i] == v) return i;
        return 0;
    }

    private void refreshAll() {
        for (Runnable r : refreshers) r.run();
    }

    private void changed() {
        p.edit().putLong(Config.SETTINGS_REVISION_KEY, p.getLong(Config.SETTINGS_REVISION_KEY, 0L) + 1L).apply();
        setResult(RESULT_OK);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---- clock preview ---------------------------------------------------------------------------------------

    private void rebuildPreview() {
        if (previewBox == null) return;
        previewBox.removeAllViews();
        TextClock c = new TextClock(this);
        c.setFormat12Hour("h:mm");
        c.setFormat24Hour("HH:mm");
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44);
        c.setTextColor(0xFFFFFFFF);
        c.setIncludeFontPadding(false);
        try {
            c.setTypeface(getResources().getFont(R.font.outfit_light));
        } catch (RuntimeException ignored) {
            // The default font is fine for a preview.
        }
        previewBox.addView(c, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        ClockStyle.apply(this, c, null, null);
    }

    // ---- video -----------------------------------------------------------------------------------------------

    private void videoRow(final String label, final File target) {
        row(() -> label + ": " + (target.isFile() && target.length() > 0
                ? "Si (" + Math.max(1, target.length() / (1024 * 1024)) + " MB)" : "Ninguno"), () -> pickVideo(target));
    }

    private List<File> ownVideos() {
        List<File> out = new ArrayList<>();
        File dir = Config.dir(this);
        File[] files = dir == null ? null : dir.listFiles();
        if (files == null) return out;
        for (File f : files) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (f.isFile() && f.length() > 0 && (n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".webm")
                    || n.endsWith(".mov") || n.endsWith(".m4v"))) out.add(f);
        }
        return out;
    }

    private void pickVideo(final File target) {
        final List<File> own = ownVideos();
        List<String> names = new ArrayList<>();
        names.add("Examinar los archivos de la TV...");
        for (File f : own) names.add(f.getName());
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Elegir video")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    pickTarget = target;
                    if (which == 0) {
                        browse();
                    } else {
                        File src = own.get(which - 1);
                        copyAsync(src, null);
                    }
                })
                .setNegativeButton("Cancelar", null);
        if (target.isFile()) {
            b.setNeutralButton("Quitar", (d, w) -> {
                target.delete();
                changed();
                refreshAll();
            });
        }
        b.show();
    }

    private void browse() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*");
        try {
            startActivityForResult(i, REQ_VIDEO);
        } catch (ActivityNotFoundException first) {
            try {
                startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("video/*"), REQ_VIDEO);
            } catch (ActivityNotFoundException second) {
                toast("Esta TV no trae un explorador de archivos. Copia el video a la carpeta del launcher.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            copyAsync(null, data.getData());
        }
    }

    /** Copies the chosen video (a file of the launcher folder, or a Uri from the picker) into the target. */
    private void copyAsync(final File srcFile, final Uri srcUri) {
        final File target = pickTarget;
        if (target == null) return;
        toast("Copiando el video...");
        new Thread(() -> {
            boolean ok = false;
            File tmp = new File(getFilesDir(), "video_pick.tmp");
            try {
                InputStream in = srcFile != null ? new java.io.FileInputStream(srcFile)
                        : getContentResolver().openInputStream(srcUri);
                if (in == null) throw new java.io.IOException("sin datos");
                OutputStream out = new FileOutputStream(tmp);
                try {
                    byte[] buf = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally {
                    out.close();
                    in.close();
                }
                if (tmp.length() == 0) throw new java.io.IOException("vacio");
                target.delete();
                ok = tmp.renameTo(target);
            } catch (Exception e) {
                ok = false;
            }
            if (!ok) tmp.delete();
            final boolean fine = ok;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (fine) changed();
                toast(fine ? "Video aplicado" : "No pude copiar ese video");
                refreshAll();
            });
        }, "tvhome-video-copy").start();
    }

    // ---- voice -----------------------------------------------------------------------------------------------

    private static String voiceName(int key) {
        return VOICE_NAMES[indexOf(VOICE_KEYS, key)];
    }

    private void testVoice() {
        HomeKeyService svc = OverlayHost.service();
        if (svc == null) {
            toast("Activa primero la accesibilidad del launcher (Ajustes del launcher).");
            return;
        }
        VoiceController.toggle(svc);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshAll();
    }

    // ---- updates ---------------------------------------------------------------------------------------------

    private String versionName() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "?" : info.versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    private static String shortDate(String iso) {
        return iso == null ? "" : iso.replace('T', ' ').replace("Z", "");
    }

    private void checkNow() {
        if (busy) return;
        busy = true;
        UpdateChecker.check(this, (info, err) -> {
            busy = false;
            if (isFinishing()) return;
            if (info == null) {
                toast("No pude buscar: " + err);
            } else {
                found = info;
                toast(info.newer ? "Hay una actualizacion nueva" : "Ya tienes la ultima version");
            }
            refreshAll();
        });
        refreshAll();
    }

    private void installNow() {
        if (busy) return;
        if (found == null || !found.newer) {
            toast("Primero busca una actualizacion.");
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            toast("Permite instalar desde el launcher y vuelve a pulsar.");
            allowInstalls();
            return;
        }
        busy = true;
        downloadStatus = "...";
        if (OverlayHost.context() != null) Island.progress(this, "Descargando actualizacion", "", -1, 0);
        UpdateChecker.install(this, found, pct -> {
            downloadStatus = pct >= 0 ? pct + "%" : "...";
            if (OverlayHost.context() != null) {
                Island.progress(this, "Descargando actualizacion", pct >= 0 ? pct + "%" : "", pct, 0);
            }
            refreshAll();
        }, (i, err) -> {
            busy = false;
            downloadStatus = "";
            if (err != null) {
                Island.message(this, Island.WARN, "No se pudo descargar", err, 8000);
            } else {
                Island.message(this, Island.INFO, "Instalando...", "Confirma en pantalla si te lo pide", 8000);
            }
            refreshAll();
        });
        refreshAll();
    }

    private void allowInstalls() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            toast("Abre Ajustes > Apps > Acceso especial > Instalar apps desconocidas y permite al launcher.");
        }
    }
}
