package com.gathin.tvhome;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.PowerManager;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Recent apps as a 3D carousel of glass cards, each with the last picture of the app (taken now and then
 * while it is in front, with the accessibility screenshot). Opened with a long press of the panel key.
 * Left/right move, OK opens, Up removes the card, Back closes. Apps whose picture comes out black (DRM) show their banner.
 */
final class RecentsOverlay {
    /** Flip to -1 if the side cards tilt the wrong way on a TV. */
    private static final int TILT_SIGN = 1;
    private static final int MAX = 8;
    private static final ArrayList<String> MRU = new ArrayList<>();

    private static HomeKeyService svc;
    private static WindowManager wm;
    private static FrameLayout root;
    private static ArrayList<String> items = new ArrayList<>();
    private static ArrayList<View> cards = new ArrayList<>();
    private static TextView nameView;
    private static int sel;

    private RecentsOverlay() { }

    static boolean isOpen() { return root != null; }

    // ---- tracking and pictures ---------------------------------------------------------------------------------

    static void noteFront(Context c, String pkg) {
        if (pkg == null || pkg.isEmpty() || pkg.equals(c.getPackageName()) || pkg.startsWith("com.android.systemui")
                || pkg.equals("android")) return;
        MRU.remove(pkg);
        MRU.add(0, pkg);
        while (MRU.size() > MAX) MRU.remove(MRU.size() - 1);
    }

    private static File dir(Context c) {
        File d = new File(c.getCacheDir(), "recents");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Takes a picture of the app in front (API 30+, needs canTakeScreenshot on the service); calls done either way. */
    @android.annotation.SuppressLint("NewApi")
    static void capture(HomeKeyService s, String pkg, Runnable done) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || pkg == null || pkg.isEmpty() || pkg.equals(s.getPackageName())) {
            if (done != null) done.run();
            return;
        }
        try {
            PowerManager pm = (PowerManager) s.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) { if (done != null) done.run(); return; }
            s.takeScreenshot(Display.DEFAULT_DISPLAY, s.getMainExecutor(), new AccessibilityService.TakeScreenshotCallback() {
                @Override public void onSuccess(AccessibilityService.ScreenshotResult r) {
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                        if (hw != null) {
                            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                            Bitmap small = Bitmap.createScaledBitmap(sw, 640, Math.max(1, 640 * sw.getHeight() / sw.getWidth()), true);
                            if (!mostlyBlack(small)) {
                                try (FileOutputStream o = new FileOutputStream(new File(dir(s), pkg + ".jpg"))) {
                                    small.compress(Bitmap.CompressFormat.JPEG, 80, o);
                                }
                            }
                        }
                        r.getHardwareBuffer().close();
                    } catch (Exception ignored) { }
                    if (done != null) done.run();
                }
                @Override public void onFailure(int errorCode) { if (done != null) done.run(); }
            });
        } catch (RuntimeException e) {
            if (done != null) done.run();
        }
    }

    private static boolean mostlyBlack(Bitmap b) {
        long sum = 0;
        int n = 0;
        for (int y = 1; y < 8; y++) for (int x = 1; x < 8; x++) {
            int c = b.getPixel(x * b.getWidth() / 9, y * b.getHeight() / 9);
            sum += Color.red(c) + Color.green(c) + Color.blue(c);
            n++;
        }
        return sum / (3.0 * n) < 5;
    }

    // ---- carousel ----------------------------------------------------------------------------------------------

    static void open(HomeKeyService s, WindowManager w, String frontPkg) {
        if (root != null) return;
        svc = s;
        wm = w;
        capture(s, frontPkg, () -> show());
    }

    private static int dp(float v) { return Math.round(v * svc.getResources().getDisplayMetrics().density); }

    private static void show() {
        if (svc == null || root != null) return;
        PackageManager pm = svc.getPackageManager();
        items = new ArrayList<>();
        for (String p : MRU) {
            if (pm.getLaunchIntentForPackage(p) != null || pm.getLeanbackLaunchIntentForPackage(p) != null) items.add(p);
        }
        FrameLayout r = new FrameLayout(svc);
        r.setBackground(new ColorDrawable(0xB0000000));
        r.setFocusable(true);
        r.setFocusableInTouchMode(true);
        cards = new ArrayList<>();
        sel = 0;
        if (items.isEmpty()) {
            TextView t = label(svc.getString(R.string.recents_empty), 22, 0xFFFFFFFF);
            r.addView(t, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        } else {
            for (int i = 0; i < items.size(); i++) {
                View c = card(pm, items.get(i));
                r.addView(c, new FrameLayout.LayoutParams(dp(380), dp(214), Gravity.CENTER));
                c.setCameraDistance(svc.getResources().getDisplayMetrics().density * 9000f);
                cards.add(c);
            }
            nameView = label("", 24, 0xFFFFFFFF);
            FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
            np.bottomMargin = dp(120);
            r.addView(nameView, np);
        }
        TextView hint = label(svc.getString(R.string.recents_hint), 15, 0x99FFFFFF);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        hp.bottomMargin = dp(56);
        r.addView(hint, hp);

        r.setOnKeyListener((v, code, e) -> {
            if (e.getAction() != KeyEvent.ACTION_DOWN) return code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER;
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT: move(-1); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT: move(1); return true;
                case KeyEvent.KEYCODE_DPAD_UP: removeSelected(); return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER: launchSelected(); return true;
                case KeyEvent.KEYCODE_BACK: close(); return true;
                default: return false;
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        WindowBlur.apply(lp, dp(30));
        try { wm.addView(r, lp); } catch (RuntimeException e) { return; }
        root = r;
        r.requestFocus();
        layout(false);
    }

    private static TextView label(String t, int sp, int color) {
        TextView v = new TextView(svc);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private static View card(PackageManager pm, String pkg) {
        FrameLayout c = new FrameLayout(svc);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF2A2A2E, 0xFF141416});
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1), 0x59FFFFFF);
        c.setBackground(bg);
        c.setClipToOutline(true);
        c.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        ImageView iv = new ImageView(svc);
        File f = new File(dir(svc), pkg + ".jpg");
        Bitmap shot = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (shot != null) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(shot);
            c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            Drawable d = null;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                d = pm.getApplicationBanner(ai);
                if (d == null) d = pm.getApplicationIcon(ai);
            } catch (PackageManager.NameNotFoundException ignored) { }
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setImageDrawable(d);
            iv.setPadding(dp(40), dp(30), dp(40), dp(30));
            c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        }
        c.setTag(pkg);
        return c;
    }

    private static void move(int d) {
        int n = Math.max(0, Math.min(cards.size() - 1, sel + d));
        if (n == sel) return;
        sel = n;
        layout(true);
    }

    /** Coverflow: the chosen card is flat and big, the rest fan out, tilt, shrink and fade. */
    private static void layout(boolean animate) {
        for (int i = 0; i < cards.size(); i++) {
            View c = cards.get(i);
            int d = i - sel;
            int sign = Integer.signum(d);
            float x = d == 0 ? 0 : sign * (dp(330) + (Math.abs(d) - 1) * dp(120));
            float rot = TILT_SIGN * -sign * 52f;
            float sc = d == 0 ? 1.12f : Math.max(0.55f, 0.82f - 0.07f * (Math.abs(d) - 1));
            float al = d == 0 ? 1f : Math.max(0.25f, 0.75f - 0.15f * (Math.abs(d) - 1));
            c.setTranslationZ(-Math.abs(d) * 10);
            if (animate) {
                c.animate().translationX(x).rotationY(rot).scaleX(sc).scaleY(sc).alpha(al).setDuration(300)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else {
                c.setTranslationX(x); c.setRotationY(rot); c.setScaleX(sc); c.setScaleY(sc); c.setAlpha(al);
            }
        }
        if (nameView != null && sel < items.size()) {
            try {
                PackageManager pm = svc.getPackageManager();
                nameView.setText(pm.getApplicationLabel(pm.getApplicationInfo(items.get(sel), 0)));
            } catch (PackageManager.NameNotFoundException e) { nameView.setText(""); }
        }
    }

    private static void removeSelected() {
        if (items.isEmpty()) return;
        String p = items.remove(sel);
        MRU.remove(p);
        new File(dir(svc), p + ".jpg").delete();
        View c = cards.remove(sel);
        root.removeView(c);
        if (sel >= cards.size()) sel = cards.size() - 1;
        if (cards.isEmpty()) { close(); return; }
        layout(true);
    }

    private static void launchSelected() {
        if (items.isEmpty()) { close(); return; }
        String p = items.get(sel);
        PackageManager pm = svc.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(p);
        if (i == null) i = pm.getLaunchIntentForPackage(p);
        close();
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { svc.startActivity(i); } catch (RuntimeException ignored) { }
        }
    }

    static void close() {
        if (root != null && wm != null) {
            try { wm.removeView(root); } catch (RuntimeException ignored) { }
        }
        root = null;
        nameView = null;
        cards = new ArrayList<>();
    }
}
